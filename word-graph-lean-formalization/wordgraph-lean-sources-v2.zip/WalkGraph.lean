import LeanWordgraph.Pilot43
import LeanWordgraph.StepShelf
import LeanWordgraph.Pilot54
import Mathlib.Combinatorics.SimpleGraph.Basic
import Mathlib.Combinatorics.SimpleGraph.Finite
import Mathlib.Combinatorics.SimpleGraph.DegreeSum
import Mathlib.Data.Fintype.Sets

/-!
# The walk as a graph

Continuation of the Word-Graph formalisation. §4 of "The Word-Graph:
Shelves, Walks, and the Receiver's Reading" (Carroll & Willow)
speaks of the walk on a shelf and prints adjacency matrices for the
worked shelves, but never defines a graph in the `SimpleGraph`
sense. This file builds that graph as an artefact of the encoding:
the vertices are the bundled shelf words `ShelfWord s n`, and
adjacency is exactly `Step` on the underlying words — nothing is
added, and nothing is identified beyond the step relation itself.

Contents:

* `walkGraph`: the graph, well-formed by construction — symmetry
  is `Step.symm'` (StepShelf); looplessness is the step's own
  landing condition (a step lands a letter on a slot `y ∉ W`,
  while `y ∈ W'`, so no word steps to itself).
* `step_iff_adj`: adjacency is `Step`, by definition.
* `degree_eq_card_shelfNeighbors`: the degree of a vertex is the
  cardinality of its within-shelf neighbours (`shelfNeighbors`,
  Pilot54).
* `card_edgeFinset54`: shelf `(5, 4)` has exactly **six edges** —
  the paper's "six words, six edges" (§4) as a count of the
  graph's edge set in its own right, via the degree-sum formula
  (`SimpleGraph.sum_degrees_eq_twice_card_edges`) and the degree
  row `1, 3, 2, 2, 3, 1` of Pilot54, which sums to `12 = 2 * 6`.
-/

namespace WordGraph

/-- Equality of shelf words is decidable, through their underlying
words. -/
instance instDecidableEqShelfWord (s n : ℕ) : DecidableEq (ShelfWord s n) :=
  fun a b => decidable_of_iff (a.1 = b.1) Subtype.ext_iff.symm

/-- The bundled shelf words are exactly the members of the finset
`shelfWords s n`. -/
def shelfWordEquiv (s n : ℕ) : ShelfWord s n ≃ ↥(shelfWords s n) where
  toFun W := ⟨W.1, mem_shelfWords.mpr W.2⟩
  invFun W := ⟨W.1, mem_shelfWords.mp W.2⟩
  left_inv _ := Subtype.ext rfl
  right_inv _ := Subtype.ext rfl

/-- There are only finitely many words on a shelf. -/
instance instFintypeShelfWord (s n : ℕ) : Fintype (ShelfWord s n) :=
  Fintype.ofEquiv _ (shelfWordEquiv s n).symm

/-- The walk graph on shelf `(s, n)`: vertices are the shelf's
words, and two words are adjacent exactly when one steps to the
other. Symmetry is `Step.symm'`; looplessness is the step's
landing condition — a step from `W` lands a letter on a slot
`y ∉ W` with `y ∈ W'`, so `W` never steps to itself. -/
def walkGraph (s n : ℕ) : SimpleGraph (ShelfWord s n) where
  Adj a b := Step a.1 b.1
  symm := ⟨fun _ _ h => Step.symm' h⟩
  loopless := ⟨fun a h => by
    obtain ⟨x, y, -, -, -, -, hy, hEq⟩ := h
    have hyW : y ∈ a.1 := by
      rw [hEq]
      exact Finset.mem_insert_self y _
    exact hy hyW⟩

/-- Adjacency in the walk graph is, by construction, exactly the
step relation on the underlying words. (Adjacent words are then
distinct, by `SimpleGraph.ne_of_adj` — the distinctness is the
step's landing condition again.) -/
theorem step_iff_adj {s n : ℕ} {a b : ShelfWord s n} :
    (walkGraph s n).Adj a b ↔ Step a.1 b.1 :=
  Iff.rfl

/-- A step between shelf words is decidable: by `mem_stepTargets`
(Pilot54) it is membership in the computable finset of one-step
targets. -/
instance instDecidableRelWalkGraph (s n : ℕ) :
    DecidableRel (walkGraph s n).Adj :=
  fun a b => decidable_of_iff (b.1 ∈ stepTargets a.1) mem_stepTargets

/-- The degree of a shelf word in the walk graph is the number of
its neighbours within the shelf, as computed in Pilot54. -/
theorem degree_eq_card_shelfNeighbors (s n : ℕ) (a : ShelfWord s n) :
    (walkGraph s n).degree a = (shelfNeighbors s n a.1).card := by
  classical
  rw [← SimpleGraph.card_neighborFinset_eq_degree]
  refine Finset.card_bij' (fun b _ => b.1)
    (fun W hW => ⟨W, mem_shelfWords.mp (mem_shelfNeighbors.mp hW).1⟩)
    ?_ ?_ ?_ ?_
  · intro b hb
    exact mem_shelfNeighbors.mpr ⟨mem_shelfWords.mpr b.2,
      step_iff_adj.mp ((SimpleGraph.mem_neighborFinset (walkGraph s n) a b).mp hb)⟩
  · intro W hW
    exact (SimpleGraph.mem_neighborFinset (walkGraph s n) a ⟨W,
      mem_shelfWords.mp (mem_shelfNeighbors.mp hW).1⟩).mpr
      (step_iff_adj.mpr (mem_shelfNeighbors.mp hW).2)
  · intro b _
    exact Subtype.ext rfl
  · intro W _
    rfl

/-! ## Shelf (5, 4): the six edges as a count -/

/-- The vertices of the walk graph on shelf `(5, 4)` are exactly
`U1, …, U6` of Pilot54. -/
theorem univ_shelfWord54 :
    (Finset.univ : Finset (ShelfWord 5 4)) = {U1, U2, U3, U4, U5, U6} := by
  ext a
  simp only [Finset.mem_univ, true_iff, Finset.mem_insert, Finset.mem_singleton]
  have ha : a.1 ∈ shelfWords 5 4 := mem_shelfWords.mpr a.2
  rw [shelf54_words] at ha
  simp only [Finset.mem_insert, Finset.mem_singleton] at ha
  rcases ha with h | h | h | h | h | h
  · exact Or.inl (Subtype.ext h)
  · exact Or.inr (Or.inl (Subtype.ext h))
  · exact Or.inr (Or.inr (Or.inl (Subtype.ext h)))
  · exact Or.inr (Or.inr (Or.inr (Or.inl (Subtype.ext h))))
  · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inl (Subtype.ext h)))))
  · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr (Subtype.ext h)))))

/-- Degree of `U1` in the walk graph on shelf `(5, 4)` is 1. -/
theorem degree_U1 : (walkGraph 5 4).degree U1 = 1 := by
  rw [degree_eq_card_shelfNeighbors]; exact degree_u1

/-- Degree of `U2` in the walk graph on shelf `(5, 4)` is 3. -/
theorem degree_U2 : (walkGraph 5 4).degree U2 = 3 := by
  rw [degree_eq_card_shelfNeighbors]; exact degree_u2

/-- Degree of `U3` in the walk graph on shelf `(5, 4)` is 2. -/
theorem degree_U3 : (walkGraph 5 4).degree U3 = 2 := by
  rw [degree_eq_card_shelfNeighbors]; exact degree_u3

/-- Degree of `U4` in the walk graph on shelf `(5, 4)` is 2. -/
theorem degree_U4 : (walkGraph 5 4).degree U4 = 2 := by
  rw [degree_eq_card_shelfNeighbors]; exact degree_u4

/-- Degree of `U5` in the walk graph on shelf `(5, 4)` is 3. -/
theorem degree_U5 : (walkGraph 5 4).degree U5 = 3 := by
  rw [degree_eq_card_shelfNeighbors]; exact degree_u5

/-- Degree of `U6` in the walk graph on shelf `(5, 4)` is 1. -/
theorem degree_U6 : (walkGraph 5 4).degree U6 = 1 := by
  rw [degree_eq_card_shelfNeighbors]; exact degree_u6

/-- The degrees of the walk graph on shelf `(5, 4)` sum to 12 —
the degree row `1, 3, 2, 2, 3, 1` of Pilot54, summed over the
graph's vertices. -/
theorem sum_degrees54 :
    ∑ a : ShelfWord 5 4, (walkGraph 5 4).degree a = 12 := by
  rw [univ_shelfWord54,
    Finset.sum_insert (by decide), Finset.sum_insert (by decide),
    Finset.sum_insert (by decide), Finset.sum_insert (by decide),
    Finset.sum_insert (by decide), Finset.sum_singleton,
    degree_U1, degree_U2, degree_U3, degree_U4, degree_U5, degree_U6]
  decide

/-- **Shelf (5, 4) has six edges.** The paper (§4) says "six
words, six edges"; Pilot54 proved the six edges one by one and
the degree row. Here the edge set of the walk graph itself is
counted: by the degree-sum formula the degrees sum to twice the
number of edges, and the degree row sums to 12. -/
theorem card_edgeFinset54 : (walkGraph 5 4).edgeFinset.card = 6 := by
  have h := SimpleGraph.sum_degrees_eq_twice_card_edges (G := walkGraph 5 4)
  rw [sum_degrees54] at h
  omega

end WordGraph
