import LeanWordgraph.Remainders
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Data.Finset.Card

/-!
# The general degree formula

Continuation of `LeanWordgraph.Pilot43`, `LeanWordgraph.Pilot54`
and `LeanWordgraph.Remainders`: the degree of a word within its
shelf, in general.

§4 of "The Word-Graph: Shelves, Walks, and the Receiver's
Reading" (Carroll & Willow) prints the degree *row* of shelf
(5, 4) — `1, 3, 2, 2, 3, 1` — and, for shelf (4, 3), the
adjacency matrix whose row sums are `1, 2, 1`; the word
"degree" appears nowhere in the paper, and **no general degree
formula appears in the paper**.
The formula proved here is therefore a theorem *of the
encoding*, generalising the printed rows; it is not a claim
quoted from the paper. (Flag, in the sense of the fidelity
sheet: the paper's rows are the data; the formula is ours.)

## The formula

Write a shelf word's lit positions in increasing order as
`L₁ = 0 < L₂ < … < Lₙ = s`, with gaps `gᵢ = Lᵢ₊₁ - Lᵢ`
(`i = 1, …, n - 1`) — the gap pattern of C1. An interior letter
`Lⱼ` (`2 ≤ j ≤ n - 1`) moves left exactly when `gⱼ₋₁ ≥ 2` (its
left neighbour is not adjacent: `Lⱼ - 1 ∉ W`) and right exactly
when `gⱼ ≥ 2`. Distinct legal moves give distinct words — the
moved letter is recoverable from the result as the unique
element of `W ∖ W'`, and the landing slot as the unique element
of `W' ∖ W` (`move_target_recovers`) — so the degree is the
number of legal (letter, direction) moves:

  `degree W = #{i ∈ 1..n-2 : gᵢ ≥ 2} + #{i ∈ 2..n-1 : gᵢ ≥ 2}`

In list form, over `gapPattern W` (0-indexed): the count of
entries `≥ 2` in `(gapPattern W).dropLast` plus the count in
`(gapPattern W).tail`.

## Contents

* Part 1 — the counting bridge: `stepTargets_card` counts the
  one-step targets of a word as a sum over its letters, each
  interior letter contributing `[x-1 ∉ W] + [x+1 ∉ W]`;
  `degree_eq_sum` moves this to within-shelf degree.
* Part 2 — the gap formula: the sum is evaluated over the
  sorted list by induction (`listMoveCount_eq_gapCount`), and
  `degree_formula` states the result over `gapPattern W`.
* Part 3 — the two printed rows re-derived from the formula.
-/

namespace WordGraph

/-! ## Part 1 — the counting bridge -/

/-- The number of legal moves from the letter at `x` in `W`:
`0` unless `x` is interior (a lit position strictly below and
one strictly above it), in which case one for each side whose
adjacent slot is unoccupied. -/
def moveCount (W : Word) (x : ℕ) : ℕ :=
  if (∃ a ∈ W, a < x) ∧ (∃ b ∈ W, x < b) then
    (if x - 1 ∈ W then 0 else 1) + (if x + 1 ∈ W then 0 else 1) else 0

/-- Recovery: a one-step target determines the move. If
`insert y (W.erase x) = insert y' (W.erase x')` with
`x, x' ∈ W` and `y, y' ∉ W`, then `x = x'` and `y = y'`:
`x` is the unique element of `W` missing from the target
(it is not the landing slot, which lies outside `W`, and it
does not survive its own erasure), and `y` is the unique
element of the target outside `W`. -/
theorem move_target_recovers {W : Word} {x x' y y' : ℕ}
    (hx : x ∈ W) (hy : y ∉ W) (hx' : x' ∈ W) (hy' : y' ∉ W)
    (h : insert y (W.erase x) = insert y' (W.erase x')) :
    x = x' ∧ y = y' := by
  have hxnot : x ∉ insert y (W.erase x) := by
    rw [Finset.mem_insert, Finset.mem_erase]
    rintro (h1 | ⟨h2, -⟩)
    · exact hy (h1 ▸ hx)
    · exact h2 rfl
  have hxnot' : x ∉ insert y' (W.erase x') := by
    rw [← h]
    exact hxnot
  rw [Finset.mem_insert, Finset.mem_erase] at hxnot'
  push_neg at hxnot'
  obtain ⟨-, hxeq⟩ := hxnot'
  have hxx : x = x' := by
    by_contra hne
    exact hxeq hne hx
  have hyin : y ∈ insert y' (W.erase x') := by
    rw [← h]
    exact Finset.mem_insert_self y _
  rw [Finset.mem_insert, Finset.mem_erase] at hyin
  have hyy : y = y' := by
    rcases hyin with h1 | ⟨-, h2⟩
    · exact h1
    · exact absurd h2 hy
  exact ⟨hxx, hyy⟩

/-- The number of one-step targets of `W` contributed by the
letter at `x` (once `x` is known to be interior): one for each
of the slots `x - 1`, `x + 1` that is unoccupied. The map
`y ↦ insert y (W.erase x)` is injective on slots outside `W`,
so the image has the same cardinality as the set of free
slots. -/
theorem card_image_insert_erase (W : Word) (x : ℕ) :
    (({x - 1, x + 1} \ W).image (fun y => insert y (W.erase x))).card
      = (if x - 1 ∈ W then 0 else 1) + (if x + 1 ∈ W then 0 else 1) := by
  have hinj : Set.InjOn (fun y => insert y (W.erase x))
      ↑({x - 1, x + 1} \ W) := by
    intro y₁ hy₁ y₂ _hy₂ h
    have hy₁W : y₁ ∉ W :=
      (Finset.mem_sdiff.mp (Finset.mem_coe.mp hy₁)).2
    have h' : insert y₁ (W.erase x) = insert y₂ (W.erase x) := h
    have hmem : y₁ ∈ insert y₂ (W.erase x) := by
      rw [← h']
      exact Finset.mem_insert_self y₁ _
    rw [Finset.mem_insert, Finset.mem_erase] at hmem
    rcases hmem with h1 | ⟨-, h2⟩
    · exact h1
    · exact absurd h2 hy₁W
  rw [Finset.card_image_of_injOn hinj, Finset.sdiff_eq_filter]
  have hne : x - 1 ≠ x + 1 := by omega
  rw [Finset.filter_insert, Finset.filter_singleton]
  by_cases h1 : x - 1 ∈ W <;> by_cases h2 : x + 1 ∈ W <;> simp [h1, h2, hne]

/-- **The counting bridge.** The one-step targets of `W` are
counted letter by letter: the pieces of `stepTargets` for
distinct letters are disjoint (a target determines its move,
by `move_target_recovers`), so the cardinality is the sum of
the per-letter move counts `moveCount W x`. -/
theorem stepTargets_card (W : Word) :
    (stepTargets W).card = ∑ x ∈ W, moveCount W x := by
  have hdisj : (↑W : Set ℕ).PairwiseDisjoint
      (fun x => if (∃ a ∈ W, a < x) ∧ (∃ b ∈ W, x < b) then
        ({x - 1, x + 1} \ W).image (fun y => insert y (W.erase x))
        else ∅) := by
    intro x hx x' hx' hne
    simp only [Function.onFun]
    rw [Finset.disjoint_left]
    rintro z hz hz'
    by_cases hcond : (∃ a ∈ W, a < x) ∧ (∃ b ∈ W, x < b)
    · rw [if_pos hcond, Finset.mem_image] at hz
      obtain ⟨y, hy, rfl⟩ := hz
      rw [Finset.mem_sdiff] at hy
      by_cases hcond' : (∃ a ∈ W, a < x') ∧ (∃ b ∈ W, x' < b)
      · rw [if_pos hcond', Finset.mem_image] at hz'
        obtain ⟨y', hy', hzz⟩ := hz'
        rw [Finset.mem_sdiff] at hy'
        have hxW : x ∈ W := Finset.mem_coe.mp hx
        have hx'W : x' ∈ W := Finset.mem_coe.mp hx'
        exact hne (move_target_recovers hxW hy.2 hx'W hy'.2 hzz.symm).1
      · rw [if_neg hcond'] at hz'
        exact absurd hz' (Finset.notMem_empty _)
    · rw [if_neg hcond] at hz
      exact absurd hz (Finset.notMem_empty _)
  rw [stepTargets, Finset.card_biUnion hdisj]
  refine Finset.sum_congr rfl (fun x _ => ?_)
  by_cases hcond : (∃ a ∈ W, a < x) ∧ (∃ b ∈ W, x < b)
  · rw [if_pos hcond, moveCount, if_pos hcond]
    exact card_image_insert_erase W x
  · rw [if_neg hcond, Finset.card_empty, moveCount, if_neg hcond]

/-- On a shelf, the within-shelf neighbours of a word are all
of its one-step targets: a step from a shelf word stays on the
shelf (`Step.onShelf`). -/
theorem shelfNeighbors_eq_stepTargets {s n : ℕ} {W : Word}
    (h : OnShelf s n W) : shelfNeighbors s n W = stepTargets W := by
  ext W'
  rw [mem_shelfNeighbors]
  constructor
  · rintro ⟨-, hstep⟩
    exact mem_stepTargets.mpr hstep
  · intro hmem
    have hstep : Step W W' := mem_stepTargets.mp hmem
    exact ⟨mem_shelfWords.mpr (hstep.onShelf h), hstep⟩

/-- The degree of a shelf word is the total number of legal
moves from its letters. -/
theorem degree_eq_sum {s n : ℕ} {W : Word} (h : OnShelf s n W) :
    (shelfNeighbors s n W).card = ∑ x ∈ W, moveCount W x := by
  rw [shelfNeighbors_eq_stepTargets h, stepTargets_card]

/-! ## Part 2 — the gap formula -/

/-- The move-count term over a list of positions: the list
analogue of `moveCount`, with list membership in place of
finset membership. -/
def listTerm (l : List ℕ) (x : ℕ) : ℕ :=
  if (∃ a ∈ l, a < x) ∧ (∃ b ∈ l, x < b) then
    (if x - 1 ∈ l then 0 else 1) + (if x + 1 ∈ l then 0 else 1) else 0

/-- The total move count of a list of positions. -/
def listMoveCount (l : List ℕ) : ℕ := (l.map (listTerm l)).sum

/-- The consecutive differences of a list of positions —
`gapPattern` at list level: `gapPattern W` is `gapsOf
(sortedList W)` by definition. -/
def gapsOf (l : List ℕ) : List ℕ := l.zipWith (fun a b => b - a) l.tail

/-- The gap count of a list of positions: the entries `≥ 2`
among all but the last gap, plus the entries `≥ 2` among all
but the first gap. -/
def gapCount (l : List ℕ) : ℕ :=
  (gapsOf l).dropLast.countP (fun g => 2 ≤ g)
    + (gapsOf l).tail.countP (fun g => 2 ≤ g)

/-- A finset sum over a nodup list is the sum over the list. -/
theorem list_sum_toFinset (f : ℕ → ℕ) : ∀ (l : List ℕ), l.Nodup →
    ∑ x ∈ l.toFinset, f x = (l.map f).sum := by
  intro l
  induction l with
  | nil =>
    intro _
    simp
  | cons a l ih =>
    intro hl
    rw [List.nodup_cons] at hl
    rw [List.toFinset_cons, Finset.sum_insert, List.map_cons, List.sum_cons,
      ih hl.2]
    · exact fun h => hl.1 (List.mem_toFinset.mp h)

/-- The sorted list of a word is strictly increasing:
pairwise `≤` from the sort, upgraded by nodup. -/
theorem sortedList_pairwise_lt (W : Word) :
    (sortedList W).Pairwise (· < ·) := by
  have hle : (sortedList W).Pairwise (· ≤ ·) := Finset.pairwise_sort W (· ≤ ·)
  have hnd : (sortedList W).Pairwise (· ≠ ·) := Finset.sort_nodup W (· ≤ ·)
  exact (hle.and hnd).imp (fun h => lt_of_le_of_ne h.1 h.2)

/-- The finset move sum over `W` is the list move count of
its sorted list: the two terms agree letter by letter, since
list membership in `sortedList W` is finset membership in
`W`. -/
theorem sum_moveCount_eq_listMoveCount (W : Word) :
    ∑ x ∈ W, moveCount W x = listMoveCount (sortedList W) := by
  have h1 : ∑ x ∈ W, moveCount W x
      = ((sortedList W).map (moveCount W)).sum := by
    have hW : W = (sortedList W).toFinset :=
      (Finset.sort_toFinset W (· ≤ ·)).symm
    nth_rewrite 1 [hW]
    exact list_sum_toFinset _ _ (Finset.sort_nodup W (· ≤ ·))
  rw [h1, listMoveCount]
  congr 1
  refine List.map_congr_left (fun x _ => ?_)
  unfold moveCount listTerm
  simp only [sortedList, Finset.mem_sort]

/-- **The list-level degree formula.** For a strictly
increasing list of positions, the total move count is the
gap count. Induction on the list: peeling off the head `a`
shifts every gap one place. The letter `b` — the head of the
tail — was not interior there, but is interior in the whole
list exactly when a third letter `c` exists, and then it
contributes `[2 ≤ b - a] + [2 ≤ c - b]`: a left move iff the
gap below it is at least 2, a right move iff the gap above
it is. Every later letter keeps its contribution unchanged
(its two neighbouring slots and its above/below witnesses
are the same in both lists), and the gap count grows by
exactly the same two terms. -/
theorem listMoveCount_eq_gapCount : ∀ (l : List ℕ),
    l.Pairwise (· < ·) → listMoveCount l = gapCount l := by
  intro l
  induction l with
  | nil =>
    intro _
    rfl
  | cons a l ih =>
    intro hl
    cases l with
    | nil =>
      -- `[a]`: no interior letter, and no gaps.
      have hterm : listTerm [a] a = 0 := by
        have hcond : ¬ ((∃ z ∈ [a], z < a) ∧ (∃ z ∈ [a], a < z)) := by
          rintro ⟨-, ⟨z, hz, hza⟩⟩
          rw [List.mem_singleton] at hz
          subst hz
          exact lt_irrefl _ hza
        unfold listTerm
        rw [if_neg hcond]
      have hgaps : gapsOf [a] = [] := rfl
      simp [listMoveCount, gapCount, hterm, hgaps]
    | cons b l' =>
      cases l' with
      | nil =>
        -- `[a, b]`: no interior letter; the single gap is
        -- counted in neither range.
        have hab : a < b :=
          (List.pairwise_cons.mp hl).1 b List.mem_cons_self
        have hta : listTerm [a, b] a = 0 := by
          have hcond : ¬ ((∃ z ∈ [a, b], z < a)
              ∧ (∃ z ∈ [a, b], a < z)) := by
            rintro ⟨⟨z, hz, hza⟩, -⟩
            simp only [List.mem_cons, List.mem_singleton, List.not_mem_nil, or_false] at hz
            rcases hz with rfl | rfl
            · exact lt_irrefl _ hza
            · exact absurd hza (not_lt_of_gt hab)
          unfold listTerm
          rw [if_neg hcond]
        have htb : listTerm [a, b] b = 0 := by
          have hcond : ¬ ((∃ z ∈ [a, b], z < b)
              ∧ (∃ z ∈ [a, b], b < z)) := by
            rintro ⟨-, ⟨z, hz, hzb⟩⟩
            simp only [List.mem_cons, List.mem_singleton, List.not_mem_nil, or_false] at hz
            rcases hz with rfl | rfl
            · exact absurd hzb (not_lt_of_gt hab)
            · exact lt_irrefl _ hzb
          unfold listTerm
          rw [if_neg hcond]
        have hgaps : gapsOf [a, b] = [b - a] := rfl
        simp [listMoveCount, gapCount, hta, htb, hgaps]
      | cons c l'' =>
        -- The main step: `L = a :: L'`, `L' = b :: L''`,
        -- `L'' = c :: l''`.
        have hl' : (b :: c :: l'').Pairwise (· < ·) :=
          (List.pairwise_cons.mp hl).2
        have haL : ∀ z ∈ b :: c :: l'', a < z :=
          (List.pairwise_cons.mp hl).1
        have hbL : ∀ z ∈ c :: l'', b < z :=
          (List.pairwise_cons.mp hl').1
        have hl'' : (c :: l'').Pairwise (· < ·) :=
          (List.pairwise_cons.mp hl').2
        have hab : a < b := haL b List.mem_cons_self
        have hbc : b < c := hbL c List.mem_cons_self
        -- The head letter `a` of `L` is not interior.
        have hta : listTerm (a :: b :: c :: l'') a = 0 := by
          have hcond : ¬ ((∃ z ∈ a :: b :: c :: l'', z < a)
              ∧ (∃ z ∈ a :: b :: c :: l'', a < z)) := by
            rintro ⟨⟨z, hz, hza⟩, -⟩
            rcases List.mem_cons.mp hz with rfl | hz
            · exact lt_irrefl _ hza
            · exact absurd hza (not_lt_of_gt (haL z hz))
          unfold listTerm
          rw [if_neg hcond]
        -- The head letter `b` of `L'` is not interior there.
        have htb' : listTerm (b :: c :: l'') b = 0 := by
          have hcond : ¬ ((∃ z ∈ b :: c :: l'', z < b)
              ∧ (∃ z ∈ b :: c :: l'', b < z)) := by
            rintro ⟨⟨z, hz, hzb⟩, -⟩
            rcases List.mem_cons.mp hz with rfl | hz
            · exact lt_irrefl _ hzb
            · exact absurd hzb (not_lt_of_gt (hbL z hz))
          unfold listTerm
          rw [if_neg hcond]
        -- `b - 1` lies in `L` iff it is `a`, iff the gap
        -- below `b` is exactly 1.
        have hm1 : (b - 1 ∈ a :: b :: c :: l'') ↔ b - a = 1 := by
          constructor
          · intro hm
            rcases List.mem_cons.mp hm with h1 | hm
            · omega
            · rcases List.mem_cons.mp hm with h2 | hm
              · omega
              · exfalso
                have hge : c ≤ b - 1 := by
                  rcases List.mem_cons.mp hm with h3 | h3
                  · omega
                  · exact le_of_lt ((List.pairwise_cons.mp hl'').1 _ h3)
                omega
          · intro h
            have hba : b - 1 = a := by omega
            rw [hba]
            exact List.mem_cons_self
        -- `b + 1` lies in `L` iff it is `c`, iff the gap
        -- above `b` is exactly 1.
        have hm2 : (b + 1 ∈ a :: b :: c :: l'') ↔ c - b = 1 := by
          constructor
          · intro hm
            rcases List.mem_cons.mp hm with h1 | hm
            · omega
            · rcases List.mem_cons.mp hm with h2 | hm
              · omega
              · have hge : c ≤ b + 1 := by
                  rcases List.mem_cons.mp hm with h3 | h3
                  · omega
                  · exact le_of_lt ((List.pairwise_cons.mp hl'').1 _ h3)
                omega
          · intro h
            have hcb : b + 1 = c := by omega
            rw [hcb]
            exact List.mem_cons_of_mem _
              (List.mem_cons_of_mem _ List.mem_cons_self)
        -- So in `L`, the letter `b` contributes one move per
        -- adjacent gap that is at least 2.
        have htb : listTerm (a :: b :: c :: l'') b
            = (if 2 ≤ b - a then 1 else 0)
              + (if 2 ≤ c - b then 1 else 0) := by
          have hbelow : (∃ z ∈ a :: b :: c :: l'', z < b) :=
            ⟨a, List.mem_cons_self, hab⟩
          have habove : (∃ z ∈ a :: b :: c :: l'', b < z) :=
            ⟨c, List.mem_cons_of_mem _
              (List.mem_cons_of_mem _ List.mem_cons_self), hbc⟩
          unfold listTerm
          rw [if_pos ⟨hbelow, habove⟩]
          by_cases h1 : b - 1 ∈ a :: b :: c :: l'' <;>
            by_cases h2 : b + 1 ∈ a :: b :: c :: l''
          · have n1 : ¬ 2 ≤ b - a := by
              have e1 : b - a = 1 := hm1.mp h1
              omega
            have n2 : ¬ 2 ≤ c - b := by
              have e2 : c - b = 1 := hm2.mp h2
              omega
            rw [if_pos h1, if_pos h2, if_neg n1, if_neg n2]
          · have n1 : ¬ 2 ≤ b - a := by
              have e1 : b - a = 1 := hm1.mp h1
              omega
            have p2 : 2 ≤ c - b := by
              by_contra hc
              exact h2 (hm2.mpr (by omega))
            rw [if_pos h1, if_neg h2, if_neg n1, if_pos p2]
          · have p1 : 2 ≤ b - a := by
              by_contra hc
              exact h1 (hm1.mpr (by omega))
            have n2 : ¬ 2 ≤ c - b := by
              have e2 : c - b = 1 := hm2.mp h2
              omega
            rw [if_neg h1, if_pos h2, if_pos p1, if_neg n2]
          · have p1 : 2 ≤ b - a := by
              by_contra hc
              exact h1 (hm1.mpr (by omega))
            have p2 : 2 ≤ c - b := by
              by_contra hc
              exact h2 (hm2.mpr (by omega))
            rw [if_neg h1, if_neg h2, if_pos p1, if_pos p2]
        -- Every later letter keeps its contribution: its
        -- below-witness exists in both lists (`a`, resp.
        -- `b`), its above-witnesses and its two neighbouring
        -- slots are the same in both.
        have hTL2 : ∀ x ∈ c :: l'',
            listTerm (a :: b :: c :: l'') x
              = listTerm (b :: c :: l'') x := by
          intro x hx
          have hcx : c ≤ x := by
            rcases List.mem_cons.mp hx with rfl | hx'
            · exact le_refl _
            · exact le_of_lt ((List.pairwise_cons.mp hl'').1 x hx')
          have hbx : b < x := lt_of_lt_of_le hbc hcx
          have hax : a < x := lt_trans hab hbx
          have hbelowL : (∃ z ∈ a :: b :: c :: l'', z < x) :=
            ⟨a, List.mem_cons_self, hax⟩
          have hbelowL' : (∃ z ∈ b :: c :: l'', z < x) :=
            ⟨b, List.mem_cons_self, hbx⟩
          have habove : (∃ z ∈ a :: b :: c :: l'', x < z)
              ↔ (∃ z ∈ b :: c :: l'', x < z) := by
            constructor
            · rintro ⟨z, hz, hxz⟩
              rcases List.mem_cons.mp hz with rfl | hz'
              · exact absurd hxz (not_lt_of_gt hax)
              · exact ⟨z, hz', hxz⟩
            · rintro ⟨z, hz, hxz⟩
              exact ⟨z, List.mem_cons_of_mem a hz, hxz⟩
          have hm1x : (x - 1 ∈ a :: b :: c :: l'')
              ↔ (x - 1 ∈ b :: c :: l'') := by
            constructor
            · intro hm
              rcases List.mem_cons.mp hm with h1 | hm'
              · exfalso; omega
              · exact hm'
            · intro hm
              exact List.mem_cons_of_mem a hm
          have hm2x : (x + 1 ∈ a :: b :: c :: l'')
              ↔ (x + 1 ∈ b :: c :: l'') := by
            constructor
            · intro hm
              rcases List.mem_cons.mp hm with h1 | hm'
              · exfalso; omega
              · exact hm'
            · intro hm
              exact List.mem_cons_of_mem a hm
          unfold listTerm
          by_cases hab : (∃ z ∈ b :: c :: l'', x < z)
          · have habL : (∃ z ∈ a :: b :: c :: l'', x < z) :=
              habove.mpr hab
            have hcondL : (∃ z ∈ a :: b :: c :: l'', z < x)
                ∧ (∃ z ∈ a :: b :: c :: l'', x < z) := ⟨hbelowL, habL⟩
            have hcondL' : (∃ z ∈ b :: c :: l'', z < x)
                ∧ (∃ z ∈ b :: c :: l'', x < z) := ⟨hbelowL', hab⟩
            rw [if_pos hcondL, if_pos hcondL']
            by_cases h1 : x - 1 ∈ b :: c :: l'' <;>
              by_cases h2 : x + 1 ∈ b :: c :: l''
            · rw [if_pos (hm1x.mpr h1), if_pos (hm2x.mpr h2),
                if_pos h1, if_pos h2]
            · rw [if_pos (hm1x.mpr h1),
                if_neg (fun hh => h2 (hm2x.mp hh)), if_pos h1, if_neg h2]
            · rw [if_neg (fun hh => h1 (hm1x.mp hh)),
                if_pos (hm2x.mpr h2), if_neg h1, if_pos h2]
            · rw [if_neg (fun hh => h1 (hm1x.mp hh)),
                if_neg (fun hh => h2 (hm2x.mp hh)), if_neg h1, if_neg h2]
          · have hnL : ¬ (∃ z ∈ a :: b :: c :: l'', x < z) :=
              fun hh => hab (habove.mp hh)
            rw [if_neg (fun hh => hnL hh.2), if_neg (fun hh => hab hh.2)]
        -- Assemble: split both move counts at `b`.
        have hsumL : listMoveCount (a :: b :: c :: l'')
            = listTerm (a :: b :: c :: l'') b
              + ((c :: l'').map (listTerm (a :: b :: c :: l''))).sum := by
          unfold listMoveCount
          rw [List.map_cons, List.sum_cons, hta, List.map_cons,
            List.sum_cons, Nat.zero_add]
        have hsumL' : listMoveCount (b :: c :: l'')
            = ((c :: l'').map (listTerm (b :: c :: l''))).sum := by
          unfold listMoveCount
          rw [List.map_cons, List.sum_cons, htb', Nat.zero_add]
        have hmap : (c :: l'').map (listTerm (a :: b :: c :: l''))
            = (c :: l'').map (listTerm (b :: c :: l'')) :=
          List.map_congr_left hTL2
        -- The gap count grows by the same two terms.
        have hgaps : gapsOf (a :: b :: c :: l'')
            = (b - a) :: gapsOf (b :: c :: l'') := rfl
        have hgaps' : gapsOf (b :: c :: l'')
            = (c - b) :: gapsOf (c :: l'') := rfl
        have hgapL : gapCount (a :: b :: c :: l'')
            = gapCount (b :: c :: l'')
              + (if 2 ≤ b - a then 1 else 0)
              + (if 2 ≤ c - b then 1 else 0) := by
          unfold gapCount
          rw [hgaps, hgaps']
          simp only [List.dropLast_cons_cons, List.tail_cons,
            List.countP_cons, decide_eq_true_eq]
          omega
        calc listMoveCount (a :: b :: c :: l'')
            = listTerm (a :: b :: c :: l'') b
              + ((c :: l'').map (listTerm (b :: c :: l''))).sum := by
              rw [hsumL, hmap]
          _ = ((if 2 ≤ b - a then 1 else 0)
                + (if 2 ≤ c - b then 1 else 0))
              + ((c :: l'').map (listTerm (b :: c :: l''))).sum := by
              rw [htb]
          _ = (if 2 ≤ b - a then 1 else 0)
                + (if 2 ≤ c - b then 1 else 0)
              + listMoveCount (b :: c :: l'') := by
              rw [← hsumL']
          _ = gapCount (b :: c :: l'')
                + (if 2 ≤ b - a then 1 else 0)
                + (if 2 ≤ c - b then 1 else 0) := by
              rw [ih hl']; omega
          _ = gapCount (a :: b :: c :: l'') := hgapL.symm

/-- **The degree formula.** For a word `W` on shelf
`(s, n)`, the degree of `W` within its shelf is determined
by its gap pattern: the number of gaps `≥ 2` among all but
the last gap, plus the number among all but the first —
equivalently, with the gaps numbered `g₁, …, g_{n-1}` as in
the paper, `#{i ∈ 1..n-2 : gᵢ ≥ 2} + #{i ∈ 2..n-1 : gᵢ ≥ 2}`.

**Flag:** §4 prints the degree rows of the two worked
shelves but no general formula; this is the encoding's
theorem generalising those rows, not a claim quoted from
the paper. -/
theorem degree_formula {s n : ℕ} {W : Word} (h : OnShelf s n W) :
    (shelfNeighbors s n W).card
      = (gapPattern W).dropLast.countP (fun g => 2 ≤ g)
        + (gapPattern W).tail.countP (fun g => 2 ≤ g) := by
  rw [degree_eq_sum h, sum_moveCount_eq_listMoveCount]
  exact listMoveCount_eq_gapCount (sortedList W) (sortedList_pairwise_lt W)

/-! ## Part 3 — the printed rows, re-derived from the formula -/

/-- Degree of `w1` within shelf (4, 3), from the formula:
gaps `(1, 3)` give `0 + 1`. -/
theorem degree43_w1_from_formula : (shelfNeighbors 4 3 w1).card = 1 := by
  rw [degree_formula w1_onShelf, gap_w1]
  decide

/-- Degree of `w2` within shelf (4, 3), from the formula:
gaps `(2, 2)` give `1 + 1`. -/
theorem degree43_w2_from_formula : (shelfNeighbors 4 3 w2).card = 2 := by
  rw [degree_formula w2_onShelf, gap_w2]
  decide

/-- Degree of `w3` within shelf (4, 3), from the formula:
gaps `(3, 1)` give `1 + 0`. -/
theorem degree43_w3_from_formula : (shelfNeighbors 4 3 w3).card = 1 := by
  rw [degree_formula w3_onShelf, gap_w3]
  decide

/-- **The degree row of shelf (4, 3), from the formula**
(paper §4: `1, 2, 1` — the row sums of the adjacency matrix,
here produced by `degree_formula` from the gap patterns). -/
theorem degree_row43_from_formula :
    [(shelfNeighbors 4 3 w1).card, (shelfNeighbors 4 3 w2).card,
      (shelfNeighbors 4 3 w3).card] = [1, 2, 1] := by
  rw [degree43_w1_from_formula, degree43_w2_from_formula,
    degree43_w3_from_formula]

/-- Degree of `u1` within shelf (5, 4), from the formula:
gaps `(1, 1, 3)` give `0 + 1`. -/
theorem degree54_u1_from_formula : (shelfNeighbors 5 4 u1).card = 1 := by
  rw [degree_formula u1_onShelf, gap_u1]
  decide

/-- Degree of `u2` within shelf (5, 4), from the formula:
gaps `(1, 2, 2)` give `1 + 2`. -/
theorem degree54_u2_from_formula : (shelfNeighbors 5 4 u2).card = 3 := by
  rw [degree_formula u2_onShelf, gap_u2]
  decide

/-- Degree of `u3` within shelf (5, 4), from the formula:
gaps `(1, 3, 1)` give `1 + 1`. -/
theorem degree54_u3_from_formula : (shelfNeighbors 5 4 u3).card = 2 := by
  rw [degree_formula u3_onShelf, gap_u3]
  decide

/-- Degree of `u4` within shelf (5, 4), from the formula:
gaps `(2, 1, 2)` give `1 + 1`. -/
theorem degree54_u4_from_formula : (shelfNeighbors 5 4 u4).card = 2 := by
  rw [degree_formula u4_onShelf, gap_u4]
  decide

/-- Degree of `u5` within shelf (5, 4), from the formula:
gaps `(2, 2, 1)` give `2 + 1`. -/
theorem degree54_u5_from_formula : (shelfNeighbors 5 4 u5).card = 3 := by
  rw [degree_formula u5_onShelf, gap_u5]
  decide

/-- Degree of `u6` within shelf (5, 4), from the formula:
gaps `(3, 1, 1)` give `1 + 0`. -/
theorem degree54_u6_from_formula : (shelfNeighbors 5 4 u6).card = 1 := by
  rw [degree_formula u6_onShelf, gap_u6]
  decide

/-- **The degree row of shelf (5, 4), from the formula**
(paper §4: `1, 3, 2, 2, 3, 1`, in the design note's word
order, flag A22 — here produced by `degree_formula` from
the gap patterns, agreeing with `Pilot54.degree_row54`,
which was computed from the neighbour sets). -/
theorem degree_row54_from_formula :
    [(shelfNeighbors 5 4 u1).card, (shelfNeighbors 5 4 u2).card,
      (shelfNeighbors 5 4 u3).card, (shelfNeighbors 5 4 u4).card,
      (shelfNeighbors 5 4 u5).card, (shelfNeighbors 5 4 u6).card]
      = [1, 3, 2, 2, 3, 1] := by
  rw [degree54_u1_from_formula, degree54_u2_from_formula,
    degree54_u3_from_formula, degree54_u4_from_formula,
    degree54_u5_from_formula, degree54_u6_from_formula]

end WordGraph
