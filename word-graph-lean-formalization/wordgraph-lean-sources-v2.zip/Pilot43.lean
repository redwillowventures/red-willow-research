import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Powerset
import Mathlib.Data.Finset.Range
import Mathlib.Data.Finset.Sort

/-!
# Pilot formalisation: shelf (4, 3) of the Word-Graph

Source: "The Word-Graph: Shelves, Walks, and the Receiver's Reading"
(Carroll & Willow), §§2–4, as mapped in `DESIGN-definitions.md`.

Scope: the smallest worked shelf of §4 — span `s = 4`, weight `n = 3` —
with its three words, its path of steps, and its gap patterns.

**Pinning (Joe's ruling, 2026-11-20):** a word on a shelf is
*normalised*: its least position is `0`. Hence a word on shelf
`(s, n)` has both endpoints `0` and `s` lit, exactly `n` lit
positions, and no lit position above `s`. This resolves design-note
ambiguity A13 in favour of the normalised reading, which is the
reading under which §4's count `C(s-1, n-2)` is correct.
-/

namespace WordGraph

/-- A word (paper D4): a finite set of lit positions.
Positions are natural numbers (design note §0; the §§2–4 working
choice — see ambiguity A1 there). -/
abbrev Word : Type := Finset ℕ

/-- A word `W` lies on shelf `(s, n)` (paper §4), in the normalised
form of Joe's ruling: weight `n`, endpoints `0` and `s` both lit,
and every lit position in `0, …, s`. For nonempty `W` this says
`min W = 0` and `max W = s`, i.e. span `s`. -/
def OnShelf (s n : ℕ) (W : Word) : Prop :=
  W.card = n ∧ 0 ∈ W ∧ s ∈ W ∧ W ⊆ Finset.range (s + 1)

instance (s n : ℕ) : DecidablePred (OnShelf s n) :=
  fun W => inferInstanceAs
    (Decidable (W.card = n ∧ 0 ∈ W ∧ s ∈ W ∧ W ⊆ Finset.range (s + 1)))

/-- Bundled form: the type of words on shelf `(s, n)`
(design note §7). -/
def ShelfWord (s n : ℕ) : Type :=
  { W : Word // OnShelf s n W }

/-- The finset of all words on shelf `(s, n)`: the subsets of
`{0, …, s}` satisfying `OnShelf`. -/
def shelfWords (s n : ℕ) : Finset Word :=
  (Finset.range (s + 1)).powerset.filter (OnShelf s n)

/-! ## The three words of shelf (4, 3) -/

/-- First word of shelf (4, 3) (paper §4): gaps 1, 3. -/
def w1 : Word := {0, 1, 4}

/-- Second word of shelf (4, 3) (paper §4): gaps 2, 2. -/
def w2 : Word := {0, 2, 4}

/-- Third word of shelf (4, 3) (paper §4): gaps 3, 1. -/
def w3 : Word := {0, 3, 4}

theorem w1_onShelf : OnShelf 4 3 w1 := by decide

theorem w2_onShelf : OnShelf 4 3 w2 := by decide

theorem w3_onShelf : OnShelf 4 3 w3 := by decide

/-- The three words as bundled shelf words. -/
def W1 : ShelfWord 4 3 := ⟨w1, w1_onShelf⟩

/-- The three words as bundled shelf words. -/
def W2 : ShelfWord 4 3 := ⟨w2, w2_onShelf⟩

/-- The three words as bundled shelf words. -/
def W3 : ShelfWord 4 3 := ⟨w3, w3_onShelf⟩

/-! ## Enumeration of shelf (4, 3) -/

/-- The words on shelf (4, 3) are exactly `w1`, `w2`, `w3`
— no more, no fewer (paper §4). -/
theorem shelf43_words : shelfWords 4 3 = {w1, w2, w3} := by decide

/-- Shelf (4, 3) has exactly three words. -/
theorem shelf43_card : (shelfWords 4 3).card = 3 := by
  rw [shelf43_words]
  decide

/-- The count agrees with §4's formula `C(s-1, n-2)` at `(4, 3)`:
`C(3, 1) = 3`, as a checked fact. -/
theorem choose_3_1 : Nat.choose 3 1 = 3 := rfl

/-- The cardinality of shelf (4, 3) is `Nat.choose (4-1) (3-2)`. -/
theorem shelf43_card_eq_choose :
    (shelfWords 4 3).card = Nat.choose (4 - 1) (3 - 2) :=
  shelf43_card.trans choose_3_1.symm

/-! ## The step relation -/

/-- The step relation (paper §4): "move exactly one interior lit
position exactly one slot, all positions remaining distinct;
endpoints and count are fixed."

Here a position `x ∈ W` is *interior* when some lit position lies
strictly below it and some lit position lies strictly above it —
for a finite word, exactly "not an endpoint" (not the least, not
the greatest lit position). The moved letter lands on `y = x ± 1`
with `y ∉ W` (distinctness), and `W'` is `W` with `x` replaced
by `y`. Endpoints and count are then fixed automatically; the
count is recorded as `Step.card_eq` below. -/
def Step (W W' : Word) : Prop :=
  ∃ x y : ℕ,
    x ∈ W ∧
    (∃ a ∈ W, a < x) ∧ (∃ b ∈ W, x < b) ∧
    (y = x + 1 ∨ y = x - 1) ∧
    y ∉ W ∧
    W' = insert y (W.erase x)

/-- A step preserves the count (weight), as §4's rule states. -/
theorem Step.card_eq {W W' : Word} (h : Step W W') : W'.card = W.card := by
  obtain ⟨x, y, hx, -, -, -, hy, rfl⟩ := h
  have hy' : y ∉ W.erase x := fun hmem => hy (Finset.mem_erase.mp hmem).2
  rw [Finset.card_insert_of_notMem hy', Finset.card_erase_of_mem hx]
  have hpos : 0 < W.card := Finset.card_pos.mpr ⟨x, hx⟩
  omega

/-- First step of the (4, 3) path: `{0,1,4}` steps to `{0,2,4}`
(the letter at 1 moves one slot right). -/
theorem step_w1_w2 : Step w1 w2 :=
  ⟨1, 2, by decide, ⟨0, by decide, by decide⟩, ⟨4, by decide, by decide⟩,
   Or.inl rfl, by decide, by decide⟩

/-- Second step of the (4, 3) path: `{0,2,4}` steps to `{0,3,4}`
(the letter at 2 moves one slot right). -/
theorem step_w2_w3 : Step w2 w3 :=
  ⟨2, 3, by decide, ⟨0, by decide, by decide⟩, ⟨4, by decide, by decide⟩,
   Or.inl rfl, by decide, by decide⟩

/-- But `{0,1,4}` does *not* step directly to `{0,3,4}`: the only
interior letter of `{0,1,4}` is at 1, and from 1 a single slot
reaches only 0 or 2, never 3. So the three words form a path,
not a triangle — matching §4's adjacency matrix
(row one `0 1 0`; row two `1 0 1`; row three `0 1 0`). -/
theorem not_step_w1_w3 : ¬ Step w1 w3 := by
  rintro ⟨x, y, hx, ⟨a, -, hax⟩, ⟨b, hb, hxb⟩, hslot, -, hEq⟩
  have hx01 : x = 0 ∨ x = 1 ∨ x = 4 := by
    have h : x ∈ ({0, 1, 4} : Finset ℕ) := hx
    simpa using h
  have hb4 : b ≤ 4 := by
    have h : b = 0 ∨ b = 1 ∨ b = 4 := by
      have hb' : b ∈ ({0, 1, 4} : Finset ℕ) := hb
      simpa using hb'
    omega
  have hx1 : x = 1 := by omega
  subst hx1
  have hy3 : y = 3 := by
    have h3 : (3 : ℕ) ∈ w3 := by decide
    rw [hEq, Finset.mem_insert, Finset.mem_erase] at h3
    rcases h3 with h | ⟨-, h3w⟩
    · exact h.symm
    · exact absurd h3w (by decide)
  omega

/-! ## Gap patterns (C1) -/

/-- The sorted list of a word's positions, increasing
(design note §7). -/
def sortedList (W : Word) : List ℕ := W.sort (· ≤ ·)

/-- C1 — the gap pattern: the sequence of consecutive differences
between lit positions, in increasing position order (design
note §7). The design note's skeleton writes the `zipWith` with
the two lists in the order `(sortedList W, (sortedList W).tail)`;
under ℕ's truncated subtraction that order would compute
`p₀-p₁, p₁-p₂, …` (all zeros here), contradicting the note's own
stated values. The form below implements the note's stated intent
and the paper's worked values: `p₁-p₀, p₂-p₁, …`. -/
def gapPattern (W : Word) : List ℕ :=
  (sortedList W).zipWith (fun a b => b - a) (sortedList W).tail

/-- The sorted list of `{0,1,4}` is `[0, 1, 4]`. Proved by the
`Finset.sort_insert` rewriting route: `Finset.sort` is backed by
merge sort, whose kernel reduction `decide` cannot perform, so
the sorted lists are established by lemma rewriting instead. -/
theorem sortedList_w1 : sortedList w1 = [0, 1, 4] := by
  change Finset.sort w1 (· ≤ ·) = [0, 1, 4]
  rw [show w1 = insert 0 (insert 1 ({4} : Finset ℕ)) from rfl,
    Finset.sort_insert (· ≤ ·) (a := 0) (s := insert 1 ({4} : Finset ℕ))
      (by decide) (by decide),
    Finset.sort_insert (· ≤ ·) (a := 1) (s := ({4} : Finset ℕ))
      (by decide) (by decide),
    Finset.sort_singleton]

/-- The sorted list of `{0,2,4}` is `[0, 2, 4]`. -/
theorem sortedList_w2 : sortedList w2 = [0, 2, 4] := by
  change Finset.sort w2 (· ≤ ·) = [0, 2, 4]
  rw [show w2 = insert 0 (insert 2 ({4} : Finset ℕ)) from rfl,
    Finset.sort_insert (· ≤ ·) (a := 0) (s := insert 2 ({4} : Finset ℕ))
      (by decide) (by decide),
    Finset.sort_insert (· ≤ ·) (a := 2) (s := ({4} : Finset ℕ))
      (by decide) (by decide),
    Finset.sort_singleton]

/-- The sorted list of `{0,3,4}` is `[0, 3, 4]`. -/
theorem sortedList_w3 : sortedList w3 = [0, 3, 4] := by
  change Finset.sort w3 (· ≤ ·) = [0, 3, 4]
  rw [show w3 = insert 0 (insert 3 ({4} : Finset ℕ)) from rfl,
    Finset.sort_insert (· ≤ ·) (a := 0) (s := insert 3 ({4} : Finset ℕ))
      (by decide) (by decide),
    Finset.sort_insert (· ≤ ·) (a := 3) (s := ({4} : Finset ℕ))
      (by decide) (by decide),
    Finset.sort_singleton]

/-- Gap pattern of `{0,1,4}` is `(1, 3)` (paper §4). -/
theorem gap_w1 : gapPattern w1 = [1, 3] := by
  unfold gapPattern
  rw [sortedList_w1]
  decide

/-- Gap pattern of `{0,2,4}` is `(2, 2)` (paper §4). -/
theorem gap_w2 : gapPattern w2 = [2, 2] := by
  unfold gapPattern
  rw [sortedList_w2]
  decide

/-- Gap pattern of `{0,3,4}` is `(3, 1)` (paper §4). -/
theorem gap_w3 : gapPattern w3 = [3, 1] := by
  unfold gapPattern
  rw [sortedList_w3]
  decide

end WordGraph
