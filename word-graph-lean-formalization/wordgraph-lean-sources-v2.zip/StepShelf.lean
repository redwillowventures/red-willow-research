import LeanWordgraph.Pilot43
import Mathlib.Data.Finset.Erase
import Mathlib.Data.Finset.Insert
import Mathlib.Data.Finset.Range

/-!
# Steps stay on the shelf, and steps are reversible

Continuation of `LeanWordgraph.Pilot43`: two structural facts
about the step relation of "The Word-Graph: Shelves, Walks, and
the Receiver's Reading" (Carroll & Willow), §4, whose rule moves
exactly one interior lit position by one slot, with "endpoints
and count fixed".

* `Step.onShelf`: a step from a word on shelf `(s, n)` lands on
  a word on the same shelf — the walk never leaves its shelf.
  The count is `Step.card_eq` of Pilot43. The endpoints `0` and
  `s` stay lit: the moved position `x` is interior — some lit
  position lies strictly below it and one lies strictly above
  it — so `x` is neither `0` nor `s`, and erasing it removes
  neither endpoint. The landing slot `y = x ± 1` stays inside
  `range (s + 1)`: it is at most `x + 1 ≤ b ≤ s`, where `b` is
  the lit position above `x`.

* `Step.symm'`: the step relation is symmetric — the walk is
  undirected. The return move takes the letter at `y` back to
  `x`; `y` is interior in the new word, witnessed by the old
  `a` below and `b` above, neither of which coincides with `y`
  (both lie in `W`, and `y ∉ W`).
-/

namespace WordGraph

/-- A step preserves the shelf: if `W` lies on shelf `(s, n)`
and `W` steps to `W'`, then `W'` lies on the same shelf.
The walk never leaves its shelf. -/
theorem Step.onShelf {s n : ℕ} {W W' : Word} (hstep : Step W W')
    (h : OnShelf s n W) : OnShelf s n W' := by
  obtain ⟨hcard, h0, hs, hsub⟩ := h
  have hcard' : W'.card = n := hstep.card_eq.trans hcard
  obtain ⟨x, y, hx, ⟨a, haW, hax⟩, ⟨b, hbW, hxb⟩, hslot, hy, rfl⟩ := hstep
  have hb_le : b ≤ s := by
    have hb2 := Finset.mem_range.mp (hsub hbW)
    omega
  have hy_le : y ≤ s := by
    rcases hslot with h1 | h1 <;> omega
  refine ⟨hcard', ?_, ?_, ?_⟩
  · -- `0` stays lit: `0 ≠ x` (as `a < x`), so `0` survives the erase.
    exact Finset.mem_insert.mpr
      (Or.inr (Finset.mem_erase.mpr ⟨by omega, h0⟩))
  · -- `s` stays lit: `s ≠ x` (as `x < b ≤ s`), so `s` survives the erase.
    exact Finset.mem_insert.mpr
      (Or.inr (Finset.mem_erase.mpr ⟨by omega, hs⟩))
  · -- Nothing lands outside `range (s + 1)`: `y ≤ s`, and the
    -- erased word is a subset of `W`.
    apply Finset.insert_subset (Finset.mem_range.mpr (by omega))
    intro z hz
    exact hsub (Finset.mem_erase.mp hz).2

/-- The step relation is symmetric: if `W` steps to `W'`, then
`W'` steps back to `W`. The walk is undirected. -/
theorem Step.symm' {W W' : Word} (h : Step W W') : Step W' W := by
  obtain ⟨x, y, hx, ⟨a, haW, hax⟩, ⟨b, hbW, hxb⟩, hslot, hy, rfl⟩ := h
  have hyE : y ∉ W.erase x := fun hm => hy (Finset.mem_erase.mp hm).2
  have ha' : a ∈ insert y (W.erase x) :=
    Finset.mem_insert.mpr (Or.inr (Finset.mem_erase.mpr ⟨by omega, haW⟩))
  have hb' : b ∈ insert y (W.erase x) :=
    Finset.mem_insert.mpr (Or.inr (Finset.mem_erase.mpr ⟨by omega, hbW⟩))
  have hxy : x ≠ y := by
    rintro rfl
    rcases hslot with h1 | h1 <;> omega
  have hay : a ≠ y := by
    rintro rfl
    exact hy haW
  have hby : b ≠ y := by
    rintro rfl
    exact hy hbW
  have hfin : W = insert x ((insert y (W.erase x)).erase y) := by
    rw [Finset.erase_insert hyE]
    exact (Finset.insert_erase hx).symm
  refine ⟨y, x, Finset.mem_insert_self y _, ⟨a, ha', ?_⟩, ⟨b, hb', ?_⟩,
    ?_, ?_, hfin⟩
  · -- Below `y` in the new word: `a`. If `y = x - 1`, use `a ≠ y`.
    rcases hslot with h1 | h1 <;> omega
  · -- Above `y` in the new word: `b`. If `y = x + 1`, use `b ≠ y`.
    rcases hslot with h1 | h1 <;> omega
  · -- The return slot: `x = y + 1` or `x = y - 1`.
    rcases hslot with h1 | h1
    · exact Or.inr (by omega)
    · exact Or.inl (by omega)
  · -- `x` is vacant in the new word: it was erased, and `x ≠ y`.
    intro hm
    rw [Finset.mem_insert, Finset.mem_erase] at hm
    rcases hm with h1 | ⟨hne, -⟩
    · exact hxy h1
    · exact hne rfl

end WordGraph
