import LeanWordgraph.Pilot43
import LeanWordgraph.ShelfCount
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Powerset
import Mathlib.Data.Finset.Range
import Mathlib.Data.Finset.Sort

/-!
# Pilot formalisation: shelf (5, 4) of the Word-Graph

Source: "The Word-Graph: Shelves, Walks, and the Receiver's Reading"
(Carroll & Willow), §4, as mapped in `DESIGN-definitions.md` §9.

Scope: the second worked shelf of §4 — span `s = 5`, weight
`n = 4` — with its six words, its six edges, and its degree row
sums `1, 3, 2, 2, 3, 1`.

**Word order (flag A22).** §4 prints the row sums "in that order"
without printing the order. The order used here is the design
note's (§9 / A22): the six words in lexicographic order,
`{0,1,2,5}, {0,1,3,5}, {0,1,4,5}, {0,2,3,5}, {0,2,4,5},
{0,3,4,5}`, derived there from the shelf definition — it is
**not** quoted from the paper. The degree *multiset* is
order-independent; matching the printed *sequence* to specific
words rests on this order.

**Pinning.** As in `Pilot43`: words are normalised (least
position `0`), per Joe's ruling (design note A13).
-/

namespace WordGraph

/-! ## The six words of shelf (5, 4), in the design note's order -/

/-- First word of shelf (5, 4): gaps 1, 1, 3. -/
def u1 : Word := {0, 1, 2, 5}

/-- Second word of shelf (5, 4): gaps 1, 2, 2. -/
def u2 : Word := {0, 1, 3, 5}

/-- Third word of shelf (5, 4): gaps 1, 3, 1. -/
def u3 : Word := {0, 1, 4, 5}

/-- Fourth word of shelf (5, 4): gaps 2, 1, 2. -/
def u4 : Word := {0, 2, 3, 5}

/-- Fifth word of shelf (5, 4): gaps 2, 2, 1. -/
def u5 : Word := {0, 2, 4, 5}

/-- Sixth word of shelf (5, 4): gaps 3, 1, 1. -/
def u6 : Word := {0, 3, 4, 5}

theorem u1_onShelf : OnShelf 5 4 u1 := by decide

theorem u2_onShelf : OnShelf 5 4 u2 := by decide

theorem u3_onShelf : OnShelf 5 4 u3 := by decide

theorem u4_onShelf : OnShelf 5 4 u4 := by decide

theorem u5_onShelf : OnShelf 5 4 u5 := by decide

theorem u6_onShelf : OnShelf 5 4 u6 := by decide

/-- The six words as bundled shelf words. -/
def U1 : ShelfWord 5 4 := ⟨u1, u1_onShelf⟩

/-- The six words as bundled shelf words. -/
def U2 : ShelfWord 5 4 := ⟨u2, u2_onShelf⟩

/-- The six words as bundled shelf words. -/
def U3 : ShelfWord 5 4 := ⟨u3, u3_onShelf⟩

/-- The six words as bundled shelf words. -/
def U4 : ShelfWord 5 4 := ⟨u4, u4_onShelf⟩

/-- The six words as bundled shelf words. -/
def U5 : ShelfWord 5 4 := ⟨u5, u5_onShelf⟩

/-- The six words as bundled shelf words. -/
def U6 : ShelfWord 5 4 := ⟨u6, u6_onShelf⟩

/-! ## Enumeration of shelf (5, 4) -/

/-- The words on shelf (5, 4) are exactly `u1, …, u6`
— no more, no fewer (paper §4: "six words"). -/
theorem shelf54_words : shelfWords 5 4 = {u1, u2, u3, u4, u5, u6} := by
  decide

/-- `C(4, 2) = 6`, as a checked fact. -/
theorem choose_4_2 : Nat.choose 4 2 = 6 := rfl

/-- Shelf (5, 4) has exactly six words, by the general count
`WordGraph.shelfWords_card`. -/
theorem shelf54_card : (shelfWords 5 4).card = 6 := by
  have h := shelfWords_card (s := 5) (n := 4) (by decide) (by decide)
  rw [h]
  exact choose_4_2

/-- The cardinality of shelf (5, 4) is `Nat.choose (5-1) (4-2)`,
§4's formula at `(5, 4)`. -/
theorem shelf54_card_eq_choose :
    (shelfWords 5 4).card = Nat.choose (5 - 1) (4 - 2) :=
  shelfWords_card (by decide) (by decide)

/-! ## The six edges of shelf (5, 4)

The paper (§4): "six words, six edges … the shelf contains a
4-cycle with tails". In the design note's order the edges are
`u1–u2`, `u2–u3`, `u2–u4`, `u3–u5`, `u4–u5`, `u5–u6`:
the 4-cycle is `u2–u3–u5–u4–u2`, with tail `u1` hanging off
`u2` and tail `u6` hanging off `u5`. Adjacency in §4's matrices
is symmetric, so each edge is proved as a `Step` in both
directions. -/

/-- Edge `u1–u2`: the letter at 2 moves one slot right. -/
theorem step_u1_u2 : Step u1 u2 :=
  ⟨2, 3, by decide, ⟨1, by decide, by decide⟩, ⟨5, by decide, by decide⟩,
   Or.inl rfl, by decide, by decide⟩

/-- Edge `u2–u1`: the letter at 3 moves one slot left. -/
theorem step_u2_u1 : Step u2 u1 :=
  ⟨3, 2, by decide, ⟨1, by decide, by decide⟩, ⟨5, by decide, by decide⟩,
   Or.inr rfl, by decide, by decide⟩

/-- Edge `u2–u3`: the letter at 3 moves one slot right. -/
theorem step_u2_u3 : Step u2 u3 :=
  ⟨3, 4, by decide, ⟨1, by decide, by decide⟩, ⟨5, by decide, by decide⟩,
   Or.inl rfl, by decide, by decide⟩

/-- Edge `u3–u2`: the letter at 4 moves one slot left. -/
theorem step_u3_u2 : Step u3 u2 :=
  ⟨4, 3, by decide, ⟨1, by decide, by decide⟩, ⟨5, by decide, by decide⟩,
   Or.inr rfl, by decide, by decide⟩

/-- Edge `u2–u4`: the letter at 1 moves one slot right. -/
theorem step_u2_u4 : Step u2 u4 :=
  ⟨1, 2, by decide, ⟨0, by decide, by decide⟩, ⟨3, by decide, by decide⟩,
   Or.inl rfl, by decide, by decide⟩

/-- Edge `u4–u2`: the letter at 2 moves one slot left. -/
theorem step_u4_u2 : Step u4 u2 :=
  ⟨2, 1, by decide, ⟨0, by decide, by decide⟩, ⟨3, by decide, by decide⟩,
   Or.inr rfl, by decide, by decide⟩

/-- Edge `u3–u5`: the letter at 1 moves one slot right. -/
theorem step_u3_u5 : Step u3 u5 :=
  ⟨1, 2, by decide, ⟨0, by decide, by decide⟩, ⟨4, by decide, by decide⟩,
   Or.inl rfl, by decide, by decide⟩

/-- Edge `u5–u3`: the letter at 2 moves one slot left. -/
theorem step_u5_u3 : Step u5 u3 :=
  ⟨2, 1, by decide, ⟨0, by decide, by decide⟩, ⟨4, by decide, by decide⟩,
   Or.inr rfl, by decide, by decide⟩

/-- Edge `u4–u5`: the letter at 3 moves one slot right. -/
theorem step_u4_u5 : Step u4 u5 :=
  ⟨3, 4, by decide, ⟨2, by decide, by decide⟩, ⟨5, by decide, by decide⟩,
   Or.inl rfl, by decide, by decide⟩

/-- Edge `u5–u4`: the letter at 4 moves one slot left. -/
theorem step_u5_u4 : Step u5 u4 :=
  ⟨4, 3, by decide, ⟨2, by decide, by decide⟩, ⟨5, by decide, by decide⟩,
   Or.inr rfl, by decide, by decide⟩

/-- Edge `u5–u6`: the letter at 2 moves one slot right. -/
theorem step_u5_u6 : Step u5 u6 :=
  ⟨2, 3, by decide, ⟨0, by decide, by decide⟩, ⟨4, by decide, by decide⟩,
   Or.inl rfl, by decide, by decide⟩

/-- Edge `u6–u5`: the letter at 3 moves one slot left. -/
theorem step_u6_u5 : Step u6 u5 :=
  ⟨3, 2, by decide, ⟨0, by decide, by decide⟩, ⟨4, by decide, by decide⟩,
   Or.inr rfl, by decide, by decide⟩

/-! ## Degrees within the shelf

`Step` is an existential over all of `ℕ`, hence not decidable
as it stands; but in a step the moved letter lies in the word
itself, so the set of possible targets is finite and computable.
`stepTargets` computes exactly that set, and
`mem_stepTargets` ties it back to `Step`. The neighbours of a
word *within* a shelf are then a filter, and degrees are their
cardinalities. -/

/-- The computable set of one-step targets of a word: for each
interior lit position `x` (one with a lit position strictly below
and strictly above it), the words obtained by moving `x` to an
unoccupied slot `x - 1` or `x + 1`. -/
def stepTargets (W : Word) : Finset Word :=
  W.biUnion (fun x =>
    if (∃ a ∈ W, a < x) ∧ (∃ b ∈ W, x < b) then
      ({x - 1, x + 1} \ W).image (fun y => insert y (W.erase x))
    else ∅)

/-- The computable targets are exactly the `Step` targets. -/
theorem mem_stepTargets {W W' : Word} :
    W' ∈ stepTargets W ↔ Step W W' := by
  constructor
  · intro h
    rw [stepTargets, Finset.mem_biUnion] at h
    obtain ⟨x, hxW, hx⟩ := h
    by_cases hcond : (∃ a ∈ W, a < x) ∧ (∃ b ∈ W, x < b)
    · rw [if_pos hcond, Finset.mem_image] at hx
      obtain ⟨y, hy, rfl⟩ := hx
      rw [Finset.mem_sdiff] at hy
      obtain ⟨hy12, hyW⟩ := hy
      have hyv : y = x + 1 ∨ y = x - 1 := by
        simp only [Finset.mem_insert, Finset.mem_singleton] at hy12
        exact hy12.elim Or.inr Or.inl
      exact ⟨x, y, hxW, hcond.1, hcond.2, hyv, hyW, rfl⟩
    · rw [if_neg hcond] at hx
      exact absurd hx (Finset.notMem_empty W')
  · rintro ⟨x, y, hxW, hbelow, habove, hslot, hyW, rfl⟩
    rw [stepTargets, Finset.mem_biUnion]
    refine ⟨x, hxW, ?_⟩
    rw [if_pos ⟨hbelow, habove⟩, Finset.mem_image]
    refine ⟨y, ?_, rfl⟩
    rw [Finset.mem_sdiff]
    refine ⟨?_, hyW⟩
    simp only [Finset.mem_insert, Finset.mem_singleton]
    rcases hslot with h | h
    · exact Or.inr h
    · exact Or.inl h

/-- The neighbours of `W` within shelf `(s, n)`: the words of
the shelf that `W` steps to in one step. -/
def shelfNeighbors (s n : ℕ) (W : Word) : Finset Word :=
  (shelfWords s n).filter (fun W' => W' ∈ stepTargets W)

/-- Membership in the within-shelf neighbours is `OnShelf`
membership plus a step. -/
theorem mem_shelfNeighbors {s n : ℕ} {W W' : Word} :
    W' ∈ shelfNeighbors s n W ↔ W' ∈ shelfWords s n ∧ Step W W' := by
  simp only [shelfNeighbors, Finset.mem_filter, mem_stepTargets]

/-- The neighbours of `u1` within shelf (5, 4): just `u2`. -/
theorem neighbors_u1 : shelfNeighbors 5 4 u1 = {u2} := by decide

/-- The neighbours of `u2` within shelf (5, 4): `u1`, `u3`, `u4`. -/
theorem neighbors_u2 : shelfNeighbors 5 4 u2 = {u1, u3, u4} := by decide

/-- The neighbours of `u3` within shelf (5, 4): `u2`, `u5`. -/
theorem neighbors_u3 : shelfNeighbors 5 4 u3 = {u2, u5} := by decide

/-- The neighbours of `u4` within shelf (5, 4): `u2`, `u5`. -/
theorem neighbors_u4 : shelfNeighbors 5 4 u4 = {u2, u5} := by decide

/-- The neighbours of `u5` within shelf (5, 4): `u3`, `u4`, `u6`. -/
theorem neighbors_u5 : shelfNeighbors 5 4 u5 = {u3, u4, u6} := by decide

/-- The neighbours of `u6` within shelf (5, 4): just `u5`. -/
theorem neighbors_u6 : shelfNeighbors 5 4 u6 = {u5} := by decide

/-- Degree of `u1` within shelf (5, 4) is 1 (§4's row sums). -/
theorem degree_u1 : (shelfNeighbors 5 4 u1).card = 1 := by
  rw [neighbors_u1]; decide

/-- Degree of `u2` within shelf (5, 4) is 3 (§4's row sums). -/
theorem degree_u2 : (shelfNeighbors 5 4 u2).card = 3 := by
  rw [neighbors_u2]; decide

/-- Degree of `u3` within shelf (5, 4) is 2 (§4's row sums). -/
theorem degree_u3 : (shelfNeighbors 5 4 u3).card = 2 := by
  rw [neighbors_u3]; decide

/-- Degree of `u4` within shelf (5, 4) is 2 (§4's row sums). -/
theorem degree_u4 : (shelfNeighbors 5 4 u4).card = 2 := by
  rw [neighbors_u4]; decide

/-- Degree of `u5` within shelf (5, 4) is 3 (§4's row sums). -/
theorem degree_u5 : (shelfNeighbors 5 4 u5).card = 3 := by
  rw [neighbors_u5]; decide

/-- Degree of `u6` within shelf (5, 4) is 1 (§4's row sums). -/
theorem degree_u6 : (shelfNeighbors 5 4 u6).card = 1 := by
  rw [neighbors_u6]; decide

/-- **The degree row of shelf (5, 4)** (paper §4): in the design
note's word order (flag A22), the row sums are
`1, 3, 2, 2, 3, 1`. Their sum is 12 = twice the six edges. -/
theorem degree_row54 :
    [(shelfNeighbors 5 4 u1).card, (shelfNeighbors 5 4 u2).card,
     (shelfNeighbors 5 4 u3).card, (shelfNeighbors 5 4 u4).card,
     (shelfNeighbors 5 4 u5).card, (shelfNeighbors 5 4 u6).card]
      = [1, 3, 2, 2, 3, 1] := by
  rw [degree_u1, degree_u2, degree_u3, degree_u4, degree_u5, degree_u6]

/- Axiom audits: only the three standard axioms may appear. -/
#print axioms shelf54_words
#print axioms shelf54_card
#print axioms shelf54_card_eq_choose
#print axioms step_u1_u2
#print axioms step_u5_u6
#print axioms neighbors_u2
#print axioms degree_row54

end WordGraph
