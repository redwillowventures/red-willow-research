import LeanWordgraph.Pilot43
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Erase
import Mathlib.Data.Finset.Powerset

/-!
# The shelf count: `C(s-1, n-2)` in general

Source: "The Word-Graph: Shelves, Walks, and the Receiver's Reading"
(Carroll & Willow), §4, as mapped in `DESIGN-counting.md` (Route A).

Claim (§4): a shelf `(s, n)` — endpoints fixed `s` apart, `n` lit
positions — has exactly `Nat.choose (s - 1) (n - 2)` words.

The proof follows the design map's bijection: a word on shelf
`(s, n)` is determined by its interior lit positions, an
`(n - 2)`-element subset of the `s - 1` interior slots
`{1, …, s - 1}`; the inverse inserts the endpoints `0` and `s`.
The count itself is Mathlib's `Finset.card_powersetCard`.

Hypotheses (design note §1, pinned there explicitly so that `ℕ`'s
truncated subtraction cannot state the formula silently for
`n < 2`): `2 ≤ n` and `n ≤ s + 1`; `1 ≤ s` is derived.
-/

namespace WordGraph

/-- The interior slots of a shelf of span `s`: positions
`1, …, s - 1`, modelled as `range s` with `0` erased
(design note §3, with the slot finset in its un-reindexed form
`{1, …, s-1}` rather than `range (s-1)`). -/
def interiorSlots (s : ℕ) : Finset ℕ := (Finset.range s).erase 0

/-- The interior of a word: its lit positions with the two
endpoints `0` and `s` removed (design note §2, forward map). -/
def interior (s : ℕ) (W : Word) : Word := (W.erase s).erase 0

/-- Rebuild a word from an interior subset: insert the endpoints
`0` and `s` (design note §2, backward map). -/
def expand (s : ℕ) (T : Word) : Word := insert 0 (insert s T)

theorem mem_interiorSlots {s x : ℕ} :
    x ∈ interiorSlots s ↔ x ≠ 0 ∧ x < s := by
  simp [interiorSlots, Finset.mem_erase, Finset.mem_range]

/-- There are `s - 1` interior slots (design note §3, step 1). -/
theorem interiorSlots_card {s : ℕ} (hs : 1 ≤ s) :
    (interiorSlots s).card = s - 1 := by
  rw [interiorSlots,
    Finset.card_erase_of_mem (Finset.mem_range.mpr (by omega : 0 < s)),
    Finset.card_range]

/-- Membership in `shelfWords` is exactly `OnShelf`. -/
theorem mem_shelfWords {s n : ℕ} {W : Word} :
    W ∈ shelfWords s n ↔ OnShelf s n W := by
  constructor
  · intro h
    rw [shelfWords, Finset.mem_filter] at h
    exact h.2
  · intro h
    rw [shelfWords, Finset.mem_filter, Finset.mem_powerset]
    exact ⟨h.2.2.2, h⟩

/-- The interior of a word on shelf `(s, n)` has `n - 2` elements:
the word has `n` lit positions, exactly two of which are the
endpoints (design note §2, forward map). -/
theorem interior_card {s n : ℕ} {W : Word} (hW : OnShelf s n W)
    (hs : 1 ≤ s) : (interior s W).card = n - 2 := by
  obtain ⟨hcard, h0, hsW, -⟩ := hW
  have h1 : (W.erase s).card = n - 1 := by
    rw [Finset.card_erase_of_mem hsW, hcard]
  have h2 : 0 ∈ W.erase s :=
    Finset.mem_erase.mpr ⟨by omega, h0⟩
  have h3 : (interior s W).card = (n - 1) - 1 := by
    rw [interior, Finset.card_erase_of_mem h2, h1]
  omega

/-- The interior of a word lies among the interior slots
(design note §2, forward map). -/
theorem interior_subset {s n : ℕ} {W : Word} (hW : OnShelf s n W) :
    interior s W ⊆ interiorSlots s := by
  intro x hx
  rw [mem_interiorSlots]
  obtain ⟨-, -, -, hsub⟩ := hW
  have hx0 : x ≠ 0 := (Finset.mem_erase.mp hx).1
  have hxs : x ≠ s := (Finset.mem_erase.mp (Finset.mem_erase.mp hx).2).1
  have hxW : x ∈ W := (Finset.mem_erase.mp (Finset.mem_erase.mp hx).2).2
  have hxlt : x < s + 1 := Finset.mem_range.mp (hsub hxW)
  exact ⟨hx0, by omega⟩

/-- Inserting the endpoints into an `(n - 2)`-subset of the
interior slots gives a word on shelf `(s, n)` (design note §2,
backward map). -/
theorem expand_onShelf {s n : ℕ} (hn : 2 ≤ n) (hs : 1 ≤ s) {T : Word}
    (hT : T ∈ Finset.powersetCard (n - 2) (interiorSlots s)) :
    OnShelf s n (expand s T) := by
  rw [Finset.mem_powersetCard] at hT
  obtain ⟨hsub, hcardT⟩ := hT
  have h0T : 0 ∉ T := fun h => (mem_interiorSlots.mp (hsub h)).1 rfl
  have hsT : s ∉ T := fun h =>
    absurd (mem_interiorSlots.mp (hsub h)).2 (lt_irrefl s)
  refine ⟨?_, Finset.mem_insert_self 0 _, ?_, ?_⟩
  · -- weight: `2 + (n - 2) = n`, the union being disjoint
    have h1 : (insert s T).card = n - 2 + 1 := by
      rw [Finset.card_insert_of_notMem hsT, hcardT]
    have h2 : 0 ∉ insert s T := by
      simp only [Finset.mem_insert, not_or]
      exact ⟨by omega, h0T⟩
    rw [expand, Finset.card_insert_of_notMem h2, h1]
    omega
  · -- the far endpoint `s` is lit
    exact Finset.mem_insert.mpr (Or.inr (Finset.mem_insert_self s T))
  · -- every lit position lies in `0, …, s`
    intro x hx
    rw [expand, Finset.mem_insert, Finset.mem_insert] at hx
    rw [Finset.mem_range]
    rcases hx with rfl | rfl | hxT
    · omega
    · omega
    · have hlt := (mem_interiorSlots.mp (hsub hxT)).2
      omega

/-- The two maps are inverse, word side: expanding the interior
of a word returns the word, since a word is determined by its
lit positions and both endpoints are lit (design note §2). -/
theorem expand_interior {s n : ℕ} {W : Word} (hW : OnShelf s n W)
    (hs : 1 ≤ s) : expand s (interior s W) = W := by
  obtain ⟨-, h0, hsW, -⟩ := hW
  have hcomm : (W.erase s).erase 0 = (W.erase 0).erase s := by
    ext x
    simp only [Finset.mem_erase]
    tauto
  have step1 : insert s ((W.erase s).erase 0) = W.erase 0 := by
    rw [hcomm]
    exact Finset.insert_erase (Finset.mem_erase.mpr ⟨by omega, hsW⟩)
  have hunfold : expand s (interior s W)
      = insert 0 (insert s ((W.erase s).erase 0)) := rfl
  rw [hunfold, step1, Finset.insert_erase h0]

/-- The two maps are inverse, subset side: the interior of the
expansion of an interior subset is the subset itself — the added
endpoints are not interior slots (design note §2). -/
theorem interior_expand {s n : ℕ} (hs : 1 ≤ s) {T : Word}
    (hT : T ∈ Finset.powersetCard (n - 2) (interiorSlots s)) :
    interior s (expand s T) = T := by
  rw [Finset.mem_powersetCard] at hT
  obtain ⟨hsub, -⟩ := hT
  have h0T : 0 ∉ T := fun h => (mem_interiorSlots.mp (hsub h)).1 rfl
  have hsT : s ∉ T := fun h =>
    absurd (mem_interiorSlots.mp (hsub h)).2 (lt_irrefl s)
  have hA : (insert 0 (insert s T)).erase s = insert 0 T := by
    ext x
    simp only [Finset.mem_erase, Finset.mem_insert]
    constructor
    · rintro ⟨hxs, rfl | rfl | hxT⟩
      · exact Or.inl rfl
      · exact absurd rfl hxs
      · exact Or.inr hxT
    · rintro (rfl | hxT)
      · exact ⟨by omega, Or.inl rfl⟩
      · refine ⟨?_, Or.inr (Or.inr hxT)⟩
        intro h
        subst h
        exact hsT hxT
  have hunfold : interior s (expand s T)
      = ((insert 0 (insert s T)).erase s).erase 0 := rfl
  rw [hunfold, hA, Finset.erase_insert h0T]

/-- **The shelf count (paper §4).** For `2 ≤ n ≤ s + 1`, shelf
`(s, n)` has exactly `Nat.choose (s - 1) (n - 2)` words. -/
theorem shelfWords_card {s n : ℕ} (hn : 2 ≤ n) (hns : n ≤ s + 1) :
    (shelfWords s n).card = Nat.choose (s - 1) (n - 2) := by
  have hs : 1 ≤ s := by omega
  have hi : Set.MapsTo (interior s) ↑(shelfWords s n)
      ↑(Finset.powersetCard (n - 2) (interiorSlots s)) := by
    intro W hW
    rw [Finset.mem_coe, Finset.mem_powersetCard]
    exact ⟨interior_subset (mem_shelfWords.mp (Finset.mem_coe.mp hW)),
      interior_card (mem_shelfWords.mp (Finset.mem_coe.mp hW)) hs⟩
  have hj : Set.MapsTo (expand s)
      ↑(Finset.powersetCard (n - 2) (interiorSlots s))
      ↑(shelfWords s n) := by
    intro T hT
    rw [Finset.mem_coe]
    exact mem_shelfWords.mpr
      (expand_onShelf hn hs (Finset.mem_coe.mp hT))
  have hleft : Set.LeftInvOn (expand s) (interior s)
      ↑(shelfWords s n) := by
    intro W hW
    exact expand_interior (mem_shelfWords.mp (Finset.mem_coe.mp hW)) hs
  have hright : Set.RightInvOn (expand s) (interior s)
      ↑(Finset.powersetCard (n - 2) (interiorSlots s)) := by
    intro T hT
    exact interior_expand hs (Finset.mem_coe.mp hT)
  rw [Finset.card_nbij' (interior s) (expand s) hi hj hleft hright,
    Finset.card_powersetCard, interiorSlots_card hs]

/- Axiom audit for the shelf count: only the three standard
axioms may appear. -/
#print axioms shelfWords_card

end WordGraph
