import Mathlib.Basic.NNReal.Basic
import LeanWordgraph.Pilot43

/-!
# Transmission notions: band (D2), lit (D3), signature (D6)

Continuation of the Word-Graph formalisation: §§2–3 of
"The Word-Graph: Shelves, Walks, and the Receiver's Reading"
(Carroll & Willow), as mapped in `DESIGN-definitions.md`.
This file encodes exactly three definitions — **D2 (band)**,
**D3 (lit)**, **D6 (signature)** — in the weakest form that is
faithful to the paper's words. **D5 (received quantity) is not
encoded here** (design flag A8: its formula is not parseable as
written; it awaits the author's ruling), and the kernel `K` is
not encoded either: the design note's companion `Kernel` type
serves D5 and §9, both outside this file. The D1 forks are
likewise untouched: positions are `ℕ` here only because that is
the §§2–4 working choice already made in `Pilot43` (flag A1 —
not decided here, and not decided by anything in this file).

## D2 — Band

Paper, §2, verbatim:

> **D2. Band.** An emission band B or a response band QE:
> a non-negative quantity assigned to positions, a property
> of an end, not of the transit.

Flags this encoding touches (see `DESIGN-definitions.md` §2):

- **A4 (codomain).** "A non-negative quantity" names no number
  system. The design note proposes `ℝ≥0` (`NNReal`) as the
  least-committal typed option, and that proposal is followed
  here; it is not a reading of the paper.
- **A5 (domain / support).** A band is encoded as a *total*
  function on positions, as the design note proposes; the paper
  does not say whether a band is defined at every position or
  only on a finite support.
- **A6 (one type or two).** `B` and `QE` share the single type
  `Band`, distinguished only by role — the design note's
  proposal. The paper distinguishes them only by which end
  they belong to ("a property of an end").

## D3 — Lit

Paper, §2, verbatim:

> **D3. Lit.** A position is lit, relative to a band pair, iff
> QE · B > 0 at that position. Lit is a property of a position
> under a pair, never of a position alone.

Flags this encoding touches (design note §3):

- **A7 (same position).** `QE · B` is read as the pointwise
  product `(QE p) * (B p)`, both bands evaluated at the *same*
  position `p`. This is the reading the paper itself writes in
  §1 point (6), verbatim: "A channel is a set of positions,
  channel = { lambda : QE(lambda) · B(lambda) > 0 }; the
  invariant is lambda, the position on the shared axis;
  emission and response are its two readings."
- **A2 (fork F1).** Whether source and receiver share one axis
  or keep two index sets is *formally open* in the paper
  (§4: "F1 remains formally open and nothing here depends on
  it"). This encoding follows §1 point (6)'s own shared-axis
  formula; under a two-index-set reading, "the same position"
  would need an identification that §§2–4 do not supply.
  Nothing here decides F1.

The band pair is kept as explicit arguments throughout,
honouring "never of a position alone": there is no `Lit p`
with an ambient pair suppressed.

## D6 — Signature

Paper, §2, verbatim:

> **D6. Signature.** A word regarded as a name: the same lit
> set, read as identifying the transmission.

Flag this encoding touches (design note §6):

- **A12 (same type, or a wrapper?).** The design note proposes
  Option 1 — no new type: a signature *is* a word, "signature"
  naming a role, not a distinct object — and that proposal is
  followed here (`Signature` is an `abbrev` for `Word`, and
  `signatureOf` is the identity). Option 2 (a one-field wrapper
  structure) was not chosen. Under Option 1 there is exactly
  one piece of data — the lit set — and no map from words to
  signatures adds, drops, or weights any position, as the
  paper's wording requires.

## The worked instance

The paper gives no band pair in §§2–3. The instance below
(`exB`, `exQE`) is **constructed for this file**: §4 gives the
word `w1 = {0, 1, 4}` on shelf `(4, 3)`, and §10 sets its
`(4, 3)` discussion "with QE positive at every site in play".
`exQE` is the constant band `1` — the simplest band meeting
§10's condition; `exB` assigns `1` exactly at the sites of
`w1` and `0` elsewhere. The values are this file's choice,
not quoted from the paper; what is proved is that the pair's
lit set (§§ D3/D4: "the set of lit positions") is exactly
`w1`, a word on shelf `(4, 3)`.
-/

namespace WordGraph

/-! ## D2 — Band -/

/-- An amplitude: the quantity a band assigns at one position.
Paper D2 says only "a non-negative quantity"; the design note
proposes `ℝ≥0` as the least-committal typed option (flag A4). -/
abbrev Amplitude : Type := NNReal

/-- D2 — a band: "a non-negative quantity assigned to
positions, a property of an end, not of the transit."
An emission band `B` and a response band `QE` are both of
this type, distinguished only by role (flag A6); a band is a
total function on positions (flag A5). Positions are `ℕ`,
the §§2–4 working choice of `Pilot43` (flag A1). -/
abbrev Band : Type := ℕ → Amplitude

/-- The paper's "non-negative quantity", as a fact of the
encoding: whatever a band assigns, at any position, is
non-negative. -/
theorem Band.nonneg (B : Band) (p : ℕ) : 0 ≤ B p := zero_le

/-! ## D3 — Lit -/

/-- D3 — a position is lit relative to a band pair:
"iff QE · B > 0 at that position". The product is pointwise,
both bands evaluated at the same position `p` (flag A7,
following §1 point (6)); the pair `(B, QE)` is explicit,
since lit is "never of a position alone". -/
def Lit (B QE : Band) (p : ℕ) : Prop :=
  QE p * B p > 0

/-- The characterisation the definition yields: a position is
lit iff *both* ends assign a positive quantity there. (The
design note directs that this equivalence be a lemma, not a
substituted definition; the definition above keeps the
paper's product form.) -/
theorem lit_iff {B QE : Band} {p : ℕ} :
    Lit B QE p ↔ 0 < QE p ∧ 0 < B p := by
  constructor
  · intro h
    have hne := mul_ne_zero_iff.mp (ne_of_gt h)
    exact ⟨lt_of_le_of_ne zero_le (Ne.symm hne.1),
           lt_of_le_of_ne zero_le (Ne.symm hne.2)⟩
  · rintro ⟨h1, h2⟩
    exact mul_pos h1 h2

/-- The dark side of D3: a position is unlit iff at least one
end assigns `0` there. -/
theorem not_lit_iff {B QE : Band} {p : ℕ} :
    ¬ Lit B QE p ↔ QE p = 0 ∨ B p = 0 := by
  constructor
  · intro h
    by_contra hcon
    push Not at hcon
    exact h (lit_iff.mpr ⟨lt_of_le_of_ne zero_le (Ne.symm hcon.1),
                          lt_of_le_of_ne zero_le (Ne.symm hcon.2)⟩)
  · rintro (h | h) <;> simp [Lit, h]

/-- §1 point (6), the paper's own set-builder for the channel:
"A channel is a set of positions, channel = { lambda :
QE(lambda) · B(lambda) > 0 }". Encoded as a `Set ℕ` — the
paper writes a set; whether the lit set of a pair is finite
is flag A5 / A10 territory and is not settled here. -/
def channel (B QE : Band) : Set ℕ := {p | Lit B QE p}

/-- Membership in the channel is exactly D3's condition,
by §1 point (6)'s formula. -/
theorem mem_channel {B QE : Band} {p : ℕ} :
    p ∈ channel B QE ↔ Lit B QE p := Iff.rfl

/-! ### §3's rescaling symmetry (T2), at the level of D3

Paper, §3, verbatim: "The trivial symmetries of a word are:
joint translation of both bands along the axis (T1), and
positive amplitude rescaling (T2 — words are blind to
amplitude entirely)." A word is the set of lit positions
(D4), so the D3-level content of T2 is that lit-ness is
unchanged by positive rescaling of either band. (T1, joint
translation, is a statement about words and their positions
together; it is not stated at the level of `Lit` here.) -/

/-- A band rescaled by a constant factor, pointwise. -/
def scaleBand (c : Amplitude) (B : Band) : Band :=
  fun p => c * B p

/-- T2 for the emission band: rescaling `B` by a positive
constant does not change which positions are lit. -/
theorem lit_scaleBand_left {c : Amplitude} (hc : 0 < c)
    {B QE : Band} {p : ℕ} :
    Lit (scaleBand c B) QE p ↔ Lit B QE p := by
  constructor
  · intro h
    have h' := lit_iff.mp h
    exact lit_iff.mpr ⟨h'.1, (mul_pos_iff_of_pos_left hc).mp h'.2⟩
  · intro h
    have h' := lit_iff.mp h
    exact lit_iff.mpr ⟨h'.1, (mul_pos_iff_of_pos_left hc).mpr h'.2⟩

/-- T2 for the response band: rescaling `QE` by a positive
constant does not change which positions are lit. -/
theorem lit_scaleBand_right {c : Amplitude} (hc : 0 < c)
    {B QE : Band} {p : ℕ} :
    Lit B (scaleBand c QE) p ↔ Lit B QE p := by
  constructor
  · intro h
    have h' := lit_iff.mp h
    exact lit_iff.mpr ⟨(mul_pos_iff_of_pos_left hc).mp h'.1, h'.2⟩
  · intro h
    have h' := lit_iff.mp h
    exact lit_iff.mpr ⟨(mul_pos_iff_of_pos_left hc).mpr h'.1, h'.2⟩

/-! ## The worked instance on shelf (4, 3)

Constructed for this file (see the header): `exQE` is
positive at every site, as §10 requires on this shelf;
`exB` is positive exactly at the sites of §4's word
`w1 = {0, 1, 4}`. -/

/-- The instance's response band: the constant band `1`,
positive at every site in play (§10's condition on shelf
`(4, 3)`). -/
def exQE : Band := fun _ => 1

/-- The instance's emission band: `1` at the sites of
`w1 = {0, 1, 4}` (§4), `0` elsewhere. -/
def exB : Band := fun p => if p ∈ w1 then 1 else 0

/-- The lit positions of the instance pair are exactly the
sites of `w1` — by D4 ("the set of lit positions"), the
pair's word is `w1`. -/
theorem lit_ex_iff (p : ℕ) : Lit exB exQE p ↔ p ∈ w1 := by
  rw [lit_iff]
  constructor
  · rintro ⟨-, h2⟩
    by_contra hpw
    have h0 : exB p = 0 := by simp [exB, hpw]
    rw [h0] at h2
    exact lt_irrefl 0 h2
  · intro hpw
    have h1 : exB p = 1 := by simp [exB, hpw]
    exact ⟨zero_lt_one, by rw [h1]; exact zero_lt_one⟩

/-- The instance, point by point: lit at `0`, `1`, `4`;
dark at `2`, `3`. -/
theorem lit_ex_points :
    Lit exB exQE 0 ∧ Lit exB exQE 1 ∧ Lit exB exQE 4 ∧
    ¬ Lit exB exQE 2 ∧ ¬ Lit exB exQE 3 := by
  refine ⟨?_, ?_, ?_, ?_, ?_⟩ <;> rw [lit_ex_iff] <;> decide

/-- The worked instance, assembled: the pair `(exB, exQE)`
has lit set exactly `w1`, and `w1` is a word on shelf
`(4, 3)` (§4, proved in `Pilot43`). -/
theorem ex_pair_word :
    (∀ p, Lit exB exQE p ↔ p ∈ w1) ∧ OnShelf 4 3 w1 :=
  ⟨lit_ex_iff, w1_onShelf⟩

/-! ## D6 — Signature -/

/-- D6 — a signature: "A word regarded as a name: the same
lit set, read as identifying the transmission." Per the
design note's proposed Option 1 (flag A12), a signature is
not a new kind of object: `Signature` is `Word` itself, the
name of a role. -/
abbrev Signature : Type := Word

/-- The signature of a word is the word itself — "the same
lit set", with nothing added, dropped, or weighted. -/
def signatureOf (W : Word) : Signature := W

/-- The signature of `W` is `W`, by D6's "the same lit set". -/
theorem signatureOf_apply (W : Word) : signatureOf W = W := rfl

/-- A position is in the signature of `W` iff it is in `W`:
the name carries exactly the lit set. -/
theorem mem_signatureOf {W : Word} {p : ℕ} :
    p ∈ signatureOf W ↔ p ∈ W := Iff.rfl

/-- D6's "identifying": the name determines the word — no
two distinct words share a signature. -/
theorem signatureOf_injective :
    Function.Injective signatureOf := fun _a _b h => h

/-- On shelf `(4, 3)` (§4): the three words carry three
distinct signatures — within the shelf, the name identifies
the word. -/
theorem signatures43_distinct :
    signatureOf w1 ≠ signatureOf w2 ∧
    signatureOf w2 ≠ signatureOf w3 ∧
    signatureOf w1 ≠ signatureOf w3 := by decide

end WordGraph
