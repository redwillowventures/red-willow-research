# Word-Graph — Lean Fidelity Sheet, v2

**Purpose.** The second rendition of the fidelity sheet for the
Word-Graph Lean formalization. The first sheet
(`FIDELITY-sheet.md`, 18 entries, delivered 2026-11-20 and marked
read by the author) stands **untouched**; this sheet covers what
landed after it — the `Gaps` module and the five modules built
on 2026-11-21 — in the same discipline: the paper's own words,
verified character-for-character, set beside the Lean
statements, matched against the `.lean` files. Discrepancies
are reported, never smoothed over.

**Paper of record.** "The Word-Graph: Shelves, Walks, and the
Receiver's Reading" (Carroll & Willow), published v21 text,
`~/workspace/concepts/word-graph-consolidated-v21-2026-11-18.md`,
Zenodo DOI 10.5281/zenodo.24358578. Every quotation below
marked *verbatim* was checked character-for-character against
that file. Where a formalized claim has no verbatim source
text in the paper, the entry says so explicitly instead of
quoting.

**Lean files of record.** Project `~/workspace/lean-wordgraph`
(Lean 4.36.0, Mathlib rev v4.36.0). Sheet v1 covered
`Pilot43.lean`, `ShelfCount.lean`, `StepShelf.lean`,
`Pilot54.lean`. This sheet covers `Gaps.lean`, `Mirror.lean`,
`WalkGraph.lean`, `Remainders.lean`, `Transmission.lean`,
`DegreeFormula.lean`. Every Lean statement below was copied
from those files and checked against them.

**Design notes.** `DESIGN-definitions.md` (ambiguity flags
A1–A23) and `DESIGN-counting.md`, same directory. Flags below
cite them.

---

## Header

### Joe's pinning ruling (2026-11-20) — carried forward

A word is its shape, **pinned at position 0 (least position
0)**. The paper's §3 defines a shelf by span plus weight alone,
which is translation-invariant — as defined, {5,7,9} would sit
on shelf (4,3) too, slid copies would be infinite, and §4's
count of 3 would be false. Joe ruled (2026-11-20): a word is
pinned at zero. The published v21 paper text is **untouched**;
the pinning is the formalization's reading, recorded on sheet
v1 and carried forward here unchanged. It resolves design-note
ambiguity A13 in favour of the normalised reading, the reading
under which §4's count C(s−1, n−2) is correct. Every module
covered by this sheet works under the ruling: `OnShelf`
carries the endpoints 0 and s as lit positions.

### What changed since v1

- **`Gaps.lean` landed after v1 was delivered.** Sheet v1's
  gap item 9 recorded that no theorem stated the gap pattern's
  length, sum, or injectivity on a shelf; `Gaps` proves all
  three (Entries 19–21) and restates the step-conservation
  corollaries (Entry 22).
- **Five new modules landed 2026-11-21:**
  - `Mirror.lean` — the reversal map and its four theorems
    (Entries 23–25).
  - `WalkGraph.lean` — the walk as a `SimpleGraph`, and the
    (5,4) edge count as a count (Entries 26–28).
  - `Remainders.lean` — the (5,4) gap values, the (4,3)
    adjacency matrix as a whole, and the smallest-shelf
    determination (Entries 29–31).
  - `Transmission.lean` — encodings of D2 (band), D3 (lit),
    D6 (signature), T2 at the level of `Lit`, and a worked
    instance on shelf (4,3) (Entries 32–36).
  - `DegreeFormula.lean` — the general degree formula and the
    re-derivation of both printed degree rows from it
    (Entries 37–38).
- **The gap list is re-struck** at the end of this sheet: each
  of v1's 15 items is marked CLOSED, PARTIALLY CLOSED, or
  OPEN, with the closing theorem named where one exists.

### New global flags (apply across the v2 entries)

- **Three list-level gap presentations now exist.**
  `gapPattern` (Pilot43) is the definition of record.
  `Mirror.lean` defines `gapList l := l.zipWith (fun a b =>
  b - a) l.tail` and proves `gapPattern_eq_gapList`;
  `DegreeFormula.lean` defines `gapsOf` by the same expression
  and uses it as `gapPattern` at list level by definition.
  The expressions agree; the seam is naming only, recorded
  here so no reader mistakes three names for three notions.
- **A discrepancy in a module's own prose, recorded plainly.**
  `DegreeFormula.lean`'s header says §4 "prints the degree
  *rows* of the two worked shelves — `1, 2, 1` for (4, 3)".
  That is loose: §4 does **not** print "1, 2, 1" for (4,3);
  it prints the adjacency matrix (quoted in Entry 30), whose
  row sums are 1, 2, 1. Only the (5,4) row "1, 3, 2, 2, 3, 1"
  is printed as a row in §4. The module's own later docstring
  (`degree_row43_from_formula`) states it correctly — "the
  row sums of the adjacency matrix". The theorems are
  unaffected; the header sentence overstates what the paper
  prints, and this sheet does not repeat the overstatement.
  Relatedly: the paper never uses the word "degree" at all
  (verified by search of the v21 text); "degree" throughout
  the formalization is the encoding's word for the paper's
  adjacency row sums and neighbour counts.
- **The kernel `K` is not encoded anywhere.** The design
  note's companion `Kernel` type serves D5 and §9; both are
  outside every module covered by either sheet. Nothing in
  the v2 entries touches §§5–21 of the paper.

---

## F. Gaps — the gap pattern is the word's name

**Paper, verbatim (§3):** "a shelf is span plus weight
(C3 + C2); the walk moves one interior letter one slot; the
gap pattern becomes each word's name within its shelf."

**Paper, verbatim (§3), C1:** "the gap pattern (C1 — the
sequence of consecutive differences between lit positions;
the word's shape, and the finest invariant the material
supports)".

### Entry 19 — The pattern's length is n − 1

**Lean (Gaps.lean):**

```lean
theorem gaps_length {s n : ℕ} {W : Word} (h : OnShelf s n W) :
    (gapPattern W).length = n - 1 := by
```

**FLAGS:** None. One gap per adjacent pair of lit positions;
stated for every word on every shelf. This closes the first
third of v1's gap item 9.

### Entry 20 — The pattern sums to the span

**Lean (Gaps.lean):**

```lean
theorem gaps_sum {s n : ℕ} {W : Word} (h : OnShelf s n W) :
    (gapPattern W).sum = s := by
```

**FLAGS:** The sum is stated as `s`, not as "last lit
position minus first" — under the pinning the two coincide
(first lit = 0, last lit = s, both clauses of `OnShelf`), and
the proof goes through the telescoping list lemma
`zipWith_sub_sum_add_head` with head 0 and last element s.
The paper's C3, verbatim (§3): "the span (C3 — last lit
position minus first)". No standalone `span` function exists
in the formalization; see gap item 8 in the re-struck list.

### Entry 21 — The name theorem: the pattern determines the word

**Lean (Gaps.lean):**

```lean
theorem gaps_injective {s n : ℕ} {W₁ W₂ : Word} (h₁ : OnShelf s n W₁)
    (h₂ : OnShelf s n W₂) (hg : gapPattern W₁ = gapPattern W₂) : W₁ = W₂ := by
```

**FLAGS:** No hypothesis beyond the two `OnShelf`s and the
pattern equality: same shelf gives same length (n) and same
head (0) for free, which is what the reconstruction lemma
`list_eq_of_zipWith_sub_eq` consumes — a pairwise-≤ list is
determined by its head, its length, and its consecutive
differences, so each word's sorted list is the partial sums
of its pattern starting at 0. This is §3's "the gap pattern
becomes each word's name within its shelf" made into a proved
claim about the encoding (design-note A16). It closes the
last third of v1's gap item 9.

### Entry 22 — Step conservation, restated as corollaries

**Lean (Gaps.lean):**

```lean
theorem Step.weight_conserved {W W' : Word} (h : Step W W') : W'.card = W.card :=
theorem Step.shelf_conserved {s n : ℕ} {W W' : Word} (h : Step W W')
    (hW : OnShelf s n W) : OnShelf s n W' :=
```

**FLAGS:** These are restatements, not new proofs:
`Step.weight_conserved` is v1 Entry 8 (`Step.card_eq`), and
`Step.shelf_conserved` is v1 Entry 13 (`Step.onShelf`). The
shelf corollary is how span conservation appears in the
formalization — the shelf is span plus weight (§3, quoted
above), so conserving the shelf conserves both; there is no
statement about a `span` function, because none exists.
See gap item 8.

---

## G. Mirror — reversal of the gap pattern

**Paper, verbatim (§4):** "Second shelf, (5, 4): six words,
six edges, adjacency row sums 1, 3, 2, 2, 3, 1; the shelf
contains a 4-cycle with tails, and is mirror-symmetric under
reversal of the gap pattern — an echo, recorded as
observation only, of the palindromic coefficients of the
Igusa cusp form in the presented work."

### Entry 23 — The mirror map, the shelf, and the involution

**Lean (Mirror.lean):**

```lean
def mirror (s : ℕ) (W : Word) : Word := W.image (fun x => s - x)

theorem mirror_onShelf {s n : ℕ} {W : Word} (h : OnShelf s n W) :
    OnShelf s n (mirror s W) := by

theorem mirror_involutive {s n : ℕ} {W : Word} (h : OnShelf s n W) :
    mirror s (mirror s W) = W := by
```

**FLAGS:** The mirror is the encoding's construction — the
paper defines no reversal map on words. The endpoints swap
(0 ↦ s, s ↦ 0); the count is preserved because `s - ·` is
injective on a shelf word's positions (`sub_injOn_of_le`).
The one place the encoding's arithmetic shows: positions are
natural numbers, so `s - x` is truncated subtraction; every
use is on positions x ≤ s, where the truncation never bites,
and the side conditions are carried explicitly in the file.

### Entry 24 — The mirror preserves steps

**Lean (Mirror.lean):**

```lean
theorem mirror_step {s n : ℕ} {W W' : Word} (hstep : Step W W')
    (hW : OnShelf s n W) (hW' : OnShelf s n W') :
    Step (mirror s W) (mirror s W') := by
```

**FLAGS:** The mirror is an automorphism of the walk, for
every shelf: the moved letter and its target stay one slot
apart (the direction flips), and the interior witnesses swap
sides. No paper text states this; it is a theorem of the
encoding, proved so that Entry 25's phrasing has its
walk-level content.

### Entry 25 — The mirror reverses the gap pattern

**Lean (Mirror.lean):**

```lean
theorem mirror_gapPattern {s n : ℕ} {W : Word} (h : OnShelf s n W) :
    gapPattern (mirror s W) = (gapPattern W).reverse := by
```

**FLAGS — A23, the observation/theorem line, stated
exactly.** The paper states mirror symmetry **only as an
observation, and only at shelf (5, 4)**: "mirror-symmetric
under reversal of the gap pattern — an echo, recorded as
observation only" (verbatim, above). Nothing in the paper
asserts it as a theorem, at (5, 4) or in general. This entry
proves it as a property of the *encoding*, for **every**
shelf. The theorem is the formalization's; the observation
is the paper's. A reader who accepts the encoding gets the
general statement; nothing here upgrades the paper's own
claim, which remains, in the paper, observation only.

---

## H. WalkGraph — the walk as a graph; the six edges counted

**Paper:** *No verbatim source text defines a graph.* §4
speaks of the walk on a shelf and prints adjacency matrices
for the worked shelves, but never defines a graph in the
`SimpleGraph` sense. The paper's count text, verbatim (§4):
"six words, six edges" — in the sentence quoted at Entry 25's
section head. The graph below is an artefact of the encoding:
vertices are the bundled shelf words `ShelfWord s n`
(v1 Entry 2), and adjacency is exactly `Step` on the
underlying words — nothing added, nothing identified beyond
the step relation itself.

### Entry 26 — The walk graph

**Lean (WalkGraph.lean):**

```lean
def walkGraph (s n : ℕ) : SimpleGraph (ShelfWord s n) where
  Adj a b := Step a.1 b.1
  symm := ⟨fun _ _ h => Step.symm' h⟩
  loopless := ⟨fun a h => by
    obtain ⟨x, y, -, -, -, -, hy, hEq⟩ := h
    have hyW : y ∈ a.1 := by
      rw [hEq]
      exact Finset.mem_insert_self y _
    exact hy hyW⟩

theorem step_iff_adj {s n : ℕ} {a b : ShelfWord s n} :
    (walkGraph s n).Adj a b ↔ Step a.1 b.1 :=
  Iff.rfl
```

**FLAGS:** Well-formedness is discharged by results already
on the sheets: symmetry is v1 Entry 14 (`Step.symm'`);
looplessness is the step's own landing condition (a step
lands a letter on a slot y ∉ W while y ∈ W′, so no word steps
to itself — the same fact `Remainders.step_irrefl`,
Entry 30, states directly). The graph exists for every shelf
(s, n); finiteness of the vertex type is via
`shelfWordEquiv : ShelfWord s n ≃ ↥(shelfWords s n)`.

### Entry 27 — Graph degree is the within-shelf neighbour count

**Lean (WalkGraph.lean):**

```lean
theorem degree_eq_card_shelfNeighbors (s n : ℕ) (a : ShelfWord s n) :
    (walkGraph s n).degree a = (shelfNeighbors s n a.1).card := by
```

**FLAGS:** This is the bridge between the graph object and
v1 Entry 18's computed degrees: the `SimpleGraph` degree of a
vertex is the cardinality of its `shelfNeighbors` finset.
Instantiated on shelf (5, 4) as `degree_U1` … `degree_U6`
(degrees 1, 3, 2, 2, 3, 1, from Pilot54's `degree_u1` …
`degree_u6` through this bridge), and summed in
`sum_degrees54 : ∑ a : ShelfWord 5 4, (walkGraph 5 4).degree a = 12`.

### Entry 28 — Shelf (5, 4) has six edges, as a count

**Paper, verbatim (§4):** "six words, six edges" (in the
sentence quoted at the head of Section G).

**Lean (WalkGraph.lean):**

```lean
theorem card_edgeFinset54 : (walkGraph 5 4).edgeFinset.card = 6 := by
```

**FLAGS:** Sheet v1's Entry 17 flag recorded that no Lean
theorem counted the undirected edges — the 6 was recoverable
from the degree row's sum (12 = 2 × 6), not stated. It is
stated now, in exactly that way: the proof is
`SimpleGraph.sum_degrees_eq_twice_card_edges` with
`sum_degrees54` (Entry 27). The count is of the graph's own
edge set, not of the twelve directed step theorems.

---

## I. Remainders — (5,4) gap values, the (4,3) matrix, the smallest shelf

### Entry 29 — The gap values of shelf (5, 4)

**Paper:** *No verbatim source text in §4.* The paper does
not print the (5, 4) gap patterns; `Pilot54.lean` recorded
them in docstrings only. They are theorems now, each computed
from the word definitions.

**Lean (Remainders.lean):**

```lean
theorem gap_u1 : gapPattern u1 = [1, 1, 3] := by
theorem gap_u2 : gapPattern u2 = [1, 2, 2] := by
theorem gap_u3 : gapPattern u3 = [1, 3, 1] := by
theorem gap_u4 : gapPattern u4 = [2, 1, 2] := by
theorem gap_u5 : gapPattern u5 = [2, 2, 1] := by
theorem gap_u6 : gapPattern u6 = [3, 1, 1] := by
```

(with the sorted lists proved first: `sortedList_u1` …
`sortedList_u6`, via the `Finset.sort_insert` route of the
pilot, `Finset.sort` not being kernel-reducible.)

**FLAGS:** The values agree with Pilot54's docstrings
character-for-character (1,1,3 / 1,2,2 / 1,3,1 / 2,1,2 /
2,2,1 / 3,1,1 — verified against both files for this sheet),
and each has length 3 = n − 1 and sum 5 = s, as Entries 19–20
require. The word order is the design note's (flag A22,
v1 Entry 18): the patterns attach to specific words under
that order. The mirror symmetry of Entry 25 is visible in
the list itself: the patterns pair off as reverses —
[1,1,3]↔[3,1,1], [1,2,2]↔[2,2,1], and [1,3,1], [2,1,2]
self-reverse.

### Entry 30 — The (4, 3) adjacency matrix as a whole

**Paper, verbatim (§4):** "Smallest shelf, (4, 3): the words
{0,1,4} (gaps 1,3), {0,2,4} (2,2), {0,3,4} (3,1) form a path;
adjacency matrix, in that order: row one 0 1 0; row two 1 0 1;
row three 0 1 0."

**Lean (Remainders.lean):**

```lean
theorem neighbors43_w1 : shelfNeighbors 4 3 w1 = {w2} := by decide
theorem neighbors43_w2 : shelfNeighbors 4 3 w2 = {w1, w3} := by decide
theorem neighbors43_w3 : shelfNeighbors 4 3 w3 = {w2} := by decide

theorem step_irrefl (W : Word) : ¬ Step W W := by

theorem not_step_w3_w1 : ¬ Step w3 w1 :=
  fun h => not_step_w1_w3 h.symm'
```

**FLAGS:** Sheet v1's Entries 9–10 stated the two forward
steps and one non-step, and flagged the rest of the matrix as
derivable but unstated. It is stated now: the three neighbour
enumerations are exactly the matrix's rows (0 1 0 / 1 0 1 /
0 1 0 — a word's neighbours within the shelf, in the paper's
own printed word order for this shelf); `not_step_w3_w1`
completes the last unproved off-diagonal entry, from
`not_step_w1_w3` by symmetry (v1 Entry 14); and the zero
diagonal is the general lemma `step_irrefl` — no word steps
to itself, since a step's landing slot lies in the
stepped-to word but, by the rule, not in the word itself.
`step_irrefl` also retires the standing note in v1's
Entry 14 flags ("irreflexivity is not separately stated").

### Entry 31 — The smallest shelf: a determination

**Paper, verbatim (§4):** "Smallest shelf, (4, 3)" — the
sentence quoted in full at Entry 30. **The paper states no
predicate for "smallest."** That absence is the fact this
entry is built around. Two readings were tested against the
encoding; the entry is written so the author can accept or
reject the reading the formalization adopted.

**The broad reading is refuted — by the paper itself.**
Read broadly, "smallest" would mean *no smaller shelf
carries a step*. That is false in the encoding, and the
paper's own later sections exhibit the counterexample:
shelf (3, 3), whose two words step to each other.

**Paper, verbatim (§19):** "The smallest exhibit is {0,1,3}
against {0,2,3} on shelf (3,3), radius 1 — a true single
slide".

**Lean (Remainders.lean):**

```lean
theorem shelf33_words : shelfWords 3 3 = {{0, 1, 3}, {0, 2, 3}} := by
  decide

theorem step_33 : Step ({0, 1, 3} : Word) ({0, 2, 3} : Word) :=
```

**The narrow reading is what is formalized.** The §4
exhibit's own content is the path, and the paper presents
its shelves in (span, weight) order — verbatim (§4): "Second
shelf, (5, 4)". The narrow reading: (4, 3) is the smallest
shelf, in that order, **whose walk contains a word with two
within-shelf neighbours** — the middle of the path, the
`1 0 1` row of the matrix.

**Lean (Remainders.lean):**

```lean
theorem degree43_w2 : (shelfNeighbors 4 3 w2).card = 2 := by

theorem no_degree_two_below_43 {s n : ℕ} (hn : 2 ≤ n) (hns : n ≤ s + 1)
    (hlt : s < 4 ∨ (s = 4 ∧ n < 3)) :
    ∀ W ∈ shelfWords s n, (shelfNeighbors s n W).card ≤ 1 := by

theorem smallest_shelf_43 :
    (shelfNeighbors 4 3 w2).card = 2 ∧
    ∀ s n : ℕ, 2 ≤ n → n ≤ s + 1 → (s < 4 ∨ (s = 4 ∧ n < 3)) →
      ∀ W ∈ shelfWords s n, (shelfNeighbors s n W).card ≤ 1 :=
```

**FLAGS — the determination, for the author's accept or
reject.** (i) The paper never uses the word "degree"; the
predicate *a word with two neighbours* is **read off the
exhibit's adjacency matrix**, not quoted — the middle row
`1 0 1` is the only feature of the (4, 3) exhibit that no
smaller admissible shelf reproduces. (ii) The negative half
is decided case by case over exactly the admissible shelves
below (4, 3) — (1,2), (2,2), (2,3), (3,2), (3,3), (3,4),
(4,2) — on each of which every word has at most one
neighbour: where those walks move at all, they are a single
edge. Note shelf (3, 3) is among them: it carries a step
(the counterexample above) but no path centre, which is
exactly why the broad reading fails and the narrow one
survives. (iii) The determination rests on the broad reading
being refuted by the paper itself, on the path being the
whole content of the §4 exhibit, and on the ordering being
the one §4's "Second shelf" fixes. **If that reading is not
accepted, the paper's sentence as it stands is not
determinable beyond it** — the formalization records the
reading it proved, and the choice between readings is the
author's.

---

## J. Transmission — D2 (band), D3 (lit), D6 (signature), T2 at the level of Lit

**Standing flag for this whole section.** These three
definitions are encoded in the weakest form faithful to the
paper's words — but "faithful" here means: **the encodings
follow the design note's marked proposals at every point
where the paper does not determine the encoding.** The
design note flags those points as NOT RESOLVED (A4, A5, A6,
A7, A12); the proposals are the note's, not readings of the
paper, and the entries below name the proposal followed at
each step. An author who rejects a proposal rejects the
encoding at that point, not the paper. D5 (received
quantity) is **not** encoded in this module or any other —
design flag A8: its formula is not parseable as written; it
awaits the author's ruling (gap item 3). The D1 forks are
untouched: positions are ℕ here only because that is the
§§2–4 working choice already made in Pilot43 (flag A1).

### Entry 32 — D2, Band

**Paper, verbatim (§2):** "**D2. Band.** An emission band B
or a response band QE: a non-negative quantity assigned to
positions, a property of an end, not of the transit."

**Lean (Transmission.lean):**

```lean
abbrev Amplitude : Type := NNReal

abbrev Band : Type := ℕ → Amplitude

theorem Band.nonneg (B : Band) (p : ℕ) : 0 ≤ B p := zero_le
```

**FLAGS — the A-flag basis.** (i) **A4 (codomain):** "a
non-negative quantity" names no number system. The design
note proposes `ℝ≥0` (`NNReal`) as the least-committal typed
option — its words: "least-committal typed option, not as a
reading of the paper". That proposal is followed. (ii) **A5 (domain):** a
band is a *total* function on positions, as the design note
proposes; the paper does not say whether a band is defined
at every position or only on a finite support. (iii)
**A6 (one type or two):** `B` and `QE` share the single type
`Band`, distinguished only by role — the design note's
proposal (a single `Band`, in its words: "type with two
variables is proposed"); the paper distinguishes them only
by which end they belong to. `Band.nonneg` records the paper's
"non-negative" as a fact of the encoding.

### Entry 33 — D3, Lit, and the channel

**Paper, verbatim (§2):** "**D3. Lit.** A position is lit,
relative to a band pair, iff QE · B > 0 at that position.
Lit is a property of a position under a pair, never of a
position alone."

**Paper, verbatim (§1, point 6):** "(6) A channel is a set
of positions, channel = { lambda : QE(lambda) · B(lambda) >
0 }; the invariant is lambda, the position on the shared
axis; emission and response are its two readings."

**Lean (Transmission.lean):**

```lean
def Lit (B QE : Band) (p : ℕ) : Prop :=
  QE p * B p > 0

theorem lit_iff {B QE : Band} {p : ℕ} :
    Lit B QE p ↔ 0 < QE p ∧ 0 < B p := by

theorem not_lit_iff {B QE : Band} {p : ℕ} :
    ¬ Lit B QE p ↔ QE p = 0 ∨ B p = 0 := by

def channel (B QE : Band) : Set ℕ := {p | Lit B QE p}

theorem mem_channel {B QE : Band} {p : ℕ} :
    p ∈ channel B QE ↔ Lit B QE p := Iff.rfl
```

**FLAGS — the A-flag basis.** (i) **A7 (same position):**
`QE · B` is read as the pointwise product `(QE p) * (B p)`,
both bands evaluated at the *same* position p. That reading
is the design note's proposal — and it is also the reading
the paper itself writes in §1 point (6) (quoted above),
which is why the encoding adopts it. (ii) **A2 (fork F1):**
whether source and receiver share one axis or keep two index
sets is formally open in the paper — verbatim (§4): "F1
remains formally open and nothing here depends on it."
Under a two-index-set reading, "the same position" would
need an identification §§2–4 do not supply. This encoding
follows §1 point (6)'s shared-axis formula; **nothing here
decides F1.** (iii) The band pair is kept as explicit
arguments throughout, honouring "never of a position alone":
there is no `Lit p` with an ambient pair suppressed.
(iv) `lit_iff` is a *lemma*, as the design note directs —
the definition keeps the paper's product form; the
equivalence (lit iff both ends positive there) is proved,
not substituted. (v) `channel` is a `Set ℕ`, because §1
point (6) writes a set; whether a pair's lit set is finite
is A5/A10 territory and is not settled here.

### Entry 34 — T2 at the level of Lit

**Paper, verbatim (§3):** "The trivial symmetries of a word
are: joint translation of both bands along the axis (T1),
and positive amplitude rescaling (T2 — words are blind to
amplitude entirely)."

**Lean (Transmission.lean):**

```lean
def scaleBand (c : Amplitude) (B : Band) : Band :=
  fun p => c * B p

theorem lit_scaleBand_left {c : Amplitude} (hc : 0 < c)
    {B QE : Band} {p : ℕ} :
    Lit (scaleBand c B) QE p ↔ Lit B QE p := by

theorem lit_scaleBand_right {c : Amplitude} (hc : 0 < c)
    {B QE : Band} {p : ℕ} :
    Lit B (scaleBand c QE) p ↔ Lit B QE p := by
```

**FLAGS:** This is T2's content **at the level of D3**:
since a word is the set of lit positions (D4), lit-ness
unchanged by positive rescaling of either band is the
D3-level content of "words are blind to amplitude". There
is no separate word-level T2 theorem, and none is needed in
the encoding: a `Word` carries no amplitudes at all (v1
Entry 1), so blindness is definitional there and proved
here, at the one level where amplitudes exist. **T1 (joint
translation) is not stated at the level of `Lit`** — it is a
statement about words and their positions together, and
under the pinning ruling translation is excluded by
construction rather than quotiented; see gap item 6.

### Entry 35 — The worked instance on shelf (4, 3)

**Paper:** *No band pair is given in §§2–3.* The instance is
**constructed for the file**, from two paper materials: §4's
word w1 = {0, 1, 4} on shelf (4, 3), and §10's condition —
verbatim (§10): "with QE positive at every site in play".
`exQE` is the constant band 1, the simplest band meeting
§10's condition; `exB` assigns 1 exactly at the sites of w1
and 0 elsewhere. The values are the file's choice, not
quoted from the paper.

**Lean (Transmission.lean):**

```lean
def exQE : Band := fun _ => 1

def exB : Band := fun p => if p ∈ w1 then 1 else 0

theorem lit_ex_iff (p : ℕ) : Lit exB exQE p ↔ p ∈ w1 := by

theorem lit_ex_points :
    Lit exB exQE 0 ∧ Lit exB exQE 1 ∧ Lit exB exQE 4 ∧
    ¬ Lit exB exQE 2 ∧ ¬ Lit exB exQE 3 := by

theorem ex_pair_word :
    (∀ p, Lit exB exQE p ↔ p ∈ w1) ∧ OnShelf 4 3 w1 :=
  ⟨lit_ex_iff, w1_onShelf⟩
```

**FLAGS:** What is proved is that the pair's lit set — by
D4, verbatim (§2): "the set of lit positions" — is exactly
w1, a word on shelf (4, 3) (`w1_onShelf`, Pilot43). The
instance is an exhibit that the D2/D3 encodings produce the
paper's own first word from a band pair; it is not a claim
that the paper specifies this pair.

### Entry 36 — D6, Signature

**Paper, verbatim (§2):** "**D6. Signature.** A word
regarded as a name: the same lit set, read as identifying
the transmission."

**Lean (Transmission.lean):**

```lean
abbrev Signature : Type := Word

def signatureOf (W : Word) : Signature := W

theorem signatureOf_apply (W : Word) : signatureOf W = W := rfl

theorem mem_signatureOf {W : Word} {p : ℕ} :
    p ∈ signatureOf W ↔ p ∈ W := Iff.rfl

theorem signatureOf_injective :
    Function.Injective signatureOf := fun _a _b h => h

theorem signatures43_distinct :
    signatureOf w1 ≠ signatureOf w2 ∧
    signatureOf w2 ≠ signatureOf w3 ∧
    signatureOf w1 ≠ signatureOf w3 := by decide
```

**FLAGS — the A-flag basis.** **A12 (same type, or a
wrapper?):** the design note proposes Option 1 — no new
type: a signature *is* a word, "signature" naming a role,
not a distinct object — and that proposal is followed
(`Signature` is an `abbrev` for `Word`; `signatureOf` is
the identity). Option 2 (a one-field wrapper structure) was
not chosen. Under Option 1 there is exactly one piece of
data — the lit set — and no map from words to signatures
adds, drops, or weights any position, as the paper's
wording requires. `signatureOf_injective` is D6's
"identifying" in its minimal form: distinct words carry
distinct signatures because the signature *is* the word.
(The shelf-level identification of a word by its *gap
pattern* is the substantive naming theorem — Entry 21.)

---

## K. DegreeFormula — the general degree formula

**Paper:** *No general degree formula appears in the
paper.* §4 prints the (5, 4) row "1, 3, 2, 2, 3, 1"
(verbatim, Entry 25's section head) and the (4, 3) adjacency
matrix (verbatim, Entry 30) whose row sums are 1, 2, 1; the
word "degree" appears nowhere in the paper (global flag,
above). **The formula proved here is a theorem of the
encoding, generalising the printed rows; it is not a claim
quoted from the paper.** The paper's rows are the data; the
formula is ours.

### Entry 37 — The counting bridge and the formula

**Lean (DegreeFormula.lean):**

```lean
def moveCount (W : Word) (x : ℕ) : ℕ :=
  if (∃ a ∈ W, a < x) ∧ (∃ b ∈ W, x < b) then
    (if x - 1 ∈ W then 0 else 1) + (if x + 1 ∈ W then 0 else 1) else 0

theorem stepTargets_card (W : Word) :
    (stepTargets W).card = ∑ x ∈ W, moveCount W x := by

theorem degree_eq_sum {s n : ℕ} {W : Word} (h : OnShelf s n W) :
    (shelfNeighbors s n W).card = ∑ x ∈ W, moveCount W x := by

theorem degree_formula {s n : ℕ} {W : Word} (h : OnShelf s n W) :
    (shelfNeighbors s n W).card
      = (gapPattern W).dropLast.countP (fun g => 2 ≤ g)
        + (gapPattern W).tail.countP (fun g => 2 ≤ g) := by
```

**FLAGS:** In the paper's gap numbering g₁, …, g_{n−1}, the
formula reads: degree W = #{i ∈ 1..n−2 : gᵢ ≥ 2} + #{i ∈
2..n−1 : gᵢ ≥ 2} — an interior letter moves left exactly
when the gap below it is ≥ 2 and right exactly when the gap
above it is ≥ 2. The proof's spine: `stepTargets_card`
counts one-step targets letter by letter (the pieces for
distinct letters are disjoint because a target determines
its move — `move_target_recovers`: the moved letter is the
unique element of W ∖ W′, the landing slot the unique
element of W′ ∖ W); `degree_eq_sum` moves the count to
within-shelf degree via Entry 13 (a step from a shelf word
stays on the shelf, so within-shelf neighbours are all
one-step targets — `shelfNeighbors_eq_stepTargets`); and
`listMoveCount_eq_gapCount` evaluates the sum over the
sorted list by induction. The formula is stated over
`gapPattern W` itself, so it composes with Entries 19–21:
the word's name determines its degree.

### Entry 38 — The two printed rows, re-derived from the formula

**Lean (DegreeFormula.lean):**

```lean
theorem degree_row43_from_formula :
    [(shelfNeighbors 4 3 w1).card, (shelfNeighbors 4 3 w2).card,
      (shelfNeighbors 4 3 w3).card] = [1, 2, 1] := by

theorem degree_row54_from_formula :
    [(shelfNeighbors 5 4 u1).card, (shelfNeighbors 5 4 u2).card,
      (shelfNeighbors 5 4 u3).card, (shelfNeighbors 5 4 u4).card,
      (shelfNeighbors 5 4 u5).card, (shelfNeighbors 5 4 u6).card]
      = [1, 3, 2, 2, 3, 1] := by
```

(with the six (5, 4) degrees and three (4, 3) degrees each
proved individually from the formula: `degree54_u1_from_formula`
… `degree54_u6_from_formula`, `degree43_w1_from_formula` …
`degree43_w3_from_formula` — e.g. u2's gaps (1, 2, 2) give
1 + 2 = 3; w2's gaps (2, 2) give 1 + 1 = 2.)

**FLAGS:** These are *consistency* theorems, and their
direction matters: the rows were first computed from the
neighbour sets (v1 Entry 18; Entry 30), and are here produced
again from the gap patterns by the general formula — two
independent routes in the encoding agreeing on the paper's
printed data. The (5, 4) row is the paper's verbatim row,
in the design note's word order (flag A22 stands, as on
v1). The (4, 3) row [1, 2, 1] is the row-sum form of the
paper's printed matrix (see the global flag on the
DegreeFormula header's looser phrasing). Neither row's
re-derivation adds a paper claim; both check the formula
against the only degree data the paper prints.

---

## Gap list — RE-STRUCK (v1's 15 items, as they now stand)

Each item keeps v1's numbering and wording of the gap; the
status line is new. **CLOSED** = a Lean statement now exists
and is named. **PARTIALLY CLOSED** = part of the item has a
Lean counterpart; the remainder is named exactly. **OPEN** =
no Lean counterpart, with the reason.

1. **D2 — Band.** **CLOSED** — `Transmission.lean`:
   `Amplitude`, `Band`, `Band.nonneg` (Entry 32). The
   closure is of the *existence* gap: an encoding now
   exists. Its basis is the design note's marked proposals
   (A4: `ℝ≥0` codomain; A5: total function; A6: one type,
   two roles), which remain unresolved as questions about
   the paper.
2. **D3 — Lit.** **CLOSED** — `Transmission.lean`: `Lit`,
   `lit_iff`, `not_lit_iff`, `channel`, `mem_channel`
   (Entry 33). Basis flags: A7's pointwise reading (which
   §1 point (6) itself writes) and A2/F1 untouched — the
   encoding follows the shared-axis formula and decides
   nothing about F1.
3. **D5 — Received quantity Q(j).** **OPEN** — no `Q`
   exists in any module. The paper's formula remains
   unparseable as written (A8: QE's placement, QE's
   argument, and the sum's range are all unspecified).
   Closure requires **the author's ruling**; no faithful
   encoding will be attempted without it.
4. **D6 — Signature.** **CLOSED** — `Transmission.lean`:
   `Signature`, `signatureOf`, `signatureOf_apply`,
   `mem_signatureOf`, `signatureOf_injective`,
   `signatures43_distinct` (Entry 36). Basis: the design
   note's proposed Option 1 (A12) — signature is the word
   itself, a role, not a wrapper.
5. **D1 — Position, beyond the ℕ choice; forks F1 and
   F3.** **OPEN** — unchanged. "Indexed on a shared axis",
   the i/j source–receiver distinction, and F1 have no Lean
   counterpart; nesting (F3) likewise. F1 is formally open
   in the paper itself (§4, verbatim: "F1 remains formally
   open and nothing here depends on it"), and the design
   note carries it open (A2). Closure requires **the
   author's ruling** on the forks; the ℕ choice (A1) stands
   as the §§2–4 working choice, not a settlement.
6. **T1 — joint translation symmetry.** **OPEN** — no Lean
   statement. Under the pinning ruling, translation is
   excluded by construction rather than quotiented, and
   `Transmission.lean` states T2 at the level of `Lit` but
   expressly not T1, which is a statement about words and
   their positions together. Stating T1 would require
   either un-pinning the words or a quotient the
   formalization does not build; either is **the author's
   ruling** to make, not the encoding's.
7. **T2 — amplitude rescaling / blindness.** **PARTIALLY
   CLOSED** — the D3-level content is proved:
   `lit_scaleBand_left`, `lit_scaleBand_right`
   (`Transmission.lean`, Entry 34): rescaling either band by
   a positive constant changes no position's lit-ness. What
   remains without a separate Lean form is a *word-level*
   T2 statement — and it has none because in the encoding a
   word is a bare set of lit positions (v1 Entry 1): there
   are no amplitudes in a word to be blind to. The partial
   strike records exactly that split.
8. **§3 conservation claims for C1 and C3.** **PARTIALLY
   CLOSED** — the step-conservation content is now fully
   stated: C2 (weight) by v1 Entry 8 and its corollary
   `Step.weight_conserved`; C3 (span) by `gaps_sum` (the
   pattern sums to s, Entry 20) together with shelf
   conservation, `Step.onShelf` (v1 Entry 13) restated as
   `Step.shelf_conserved` (Entry 22) — the shelf being span
   plus weight. What remains open: there is still **no
   standalone `span` function** and no theorem about a span
   *value* (span is carried by `OnShelf`'s endpoints), and
   the paper's sentence itself — verbatim (§3): "No
   counterexample to their conservation appears in the
   closed set" — is a closed-set empirical claim, which as
   such has no Lean counterpart and needs none.
9. **Gap pattern as the word's name.** **CLOSED** —
   `Gaps.lean`: `gaps_length`, `gaps_sum`, `gaps_injective`
   (Entries 19–21), and the (5, 4) values by
   `Remainders.lean`: `gap_u1` … `gap_u6` (Entry 29). All
   three parts v1 named — length n − 1, sum = span,
   injectivity on a pinned shelf — plus the (5, 4) values
   v1 noted as missing.
10. **"Smallest shelf" (4,3).** **PARTIALLY CLOSED** — the
    determination is complete on the encoding's side and
    conditional on the author's side (Entry 31): the broad
    reading ("no smaller shelf carries a step") is
    **refuted**, by `shelf33_words` and `step_33`, matching
    the paper's own §19 exhibit; the narrow reading (the
    smallest shelf, in §4's (span, weight) order, whose
    walk contains a word with two within-shelf neighbours)
    is **proved**, as `smallest_shelf_43`. The strike stays
    partial because the paper states no predicate for
    "smallest": the narrow reading is read off the exhibit,
    and **accepting or rejecting that reading is the
    author's**. If it is rejected, the sentence is not
    determinable beyond the refutation.
11. **The (4,3) adjacency matrix as a whole.** **CLOSED** —
    `Remainders.lean`: `neighbors43_w1`, `neighbors43_w2`,
    `neighbors43_w3` (the three rows), `not_step_w3_w1`
    (the last off-diagonal 0), and `step_irrefl` (the zero
    diagonal, in general) (Entry 30).
12. **(5,4) — "six edges" as a count.** **CLOSED** —
    `WalkGraph.lean`: `card_edgeFinset54` (Entry 28), via
    `degree_eq_card_shelfNeighbors` and the degree-sum
    formula.
13. **(5,4) — mirror symmetry.** **CLOSED** —
    `Mirror.lean`: `mirror_onShelf`, `mirror_involutive`,
    `mirror_step`, `mirror_gapPattern` (Entries 23–25).
    Closed as a property of the encoding, proved for every
    shelf; the A23 flag stands — in the paper it remains
    observation only, at (5, 4) only.
14. **"No composition law exists at this stage"** (§4).
    **OPEN** — a negative, meta-level claim about the stage
    of the work; no Lean counterpart, and none expected.
    Open **by design**: a formalization can exhibit a
    composition law or fail to, but the paper's sentence is
    about the paper's stage, not about the encoding.
15. **The walk as a graph object.** **PARTIALLY CLOSED** —
    the graph now exists for every shelf: `walkGraph`,
    `step_iff_adj`, `degree_eq_card_shelfNeighbors`
    (`WalkGraph.lean`, Entries 26–27), and general degree
    counts exist: `degree_formula` (`DegreeFormula.lean`,
    Entry 37). What remains open: per-shelf *shape* exhibits
    beyond (4, 3) and (5, 4), and any dedicated statement
    about shelves of weight n = 2 (one word, no steps —
    consistent with v1 Entry 12's formula, C(s−1, 0) = 1,
    and with Entry 37's formula, which gives such a word
    degree 0, but nowhere exhibited as a shelf statement).

**Tally: CLOSED 7 (items 1, 2, 4, 9, 11, 12, 13) ·
PARTIALLY CLOSED 4 (items 7, 8, 10, 15) · OPEN 4
(items 3, 5, 6, 14).** Of the open items: item 3 (D5) and
items 5–6 (the D1/F1 forks, T1) wait on the author's
rulings; item 14 is open by design. §5's certification
question was never on this list and is untouched by every
module on either sheet — by design.

---

## Closing summary

**Entries.** Sheet v1: 18 (Entries 1–18). This sheet: 20
(Entries 19–38) — 3 for Gaps (plus the conservation
corollaries), 3 for Mirror, 3 for WalkGraph, 3 for
Remainders, 5 for Transmission, 2 for DegreeFormula, and
Entry 22's corollaries counted with Gaps. Total across both
sheets: **38 entries**.

**Theorems by module** (top-level `theorem` declarations,
counted from the files): Pilot43 — 17 · ShelfCount — 9 ·
StepShelf — 2 · Pilot54 — 37 · Gaps — 9 · Mirror — 13 ·
WalkGraph — 11 · Remainders — 22 · Transmission — 13 ·
DegreeFormula — 21. Total across the ten content modules:
**154 theorems**, alongside the definitions the entries
quote.

**Correction tag (2026-11-21).** As first issued, this
summary read DegreeFormula — 22 and **155 theorems**. Both
figures were one too high: the count took in the word
"theorem" inside a doc comment at DegreeFormula.lean
line 548 ("theorem generalising those rows"), which is
not a declaration. The module holds 21 theorems; the ten
modules hold 154. Corrected above, in place, with this
tag as the record of the change.

**Axiom audit.** Standing unchanged from v1 and extended
over the new modules: every theorem audited with
`#print axioms` depends only on the three standard axioms
**[propext, Classical.choice, Quot.sound]** — no others.
There is **no `sorry` anywhere** in the ten files (verified
by search for this sheet).

**Build state.** Full project build green: **18,276 jobs**
(per the latest module report), all ten content modules
wired into the root module `LeanWordgraph.lean`.

## Verification note

Compiled 2026-11-21 against the sources above; the
automated verification pass was run after writing, with these
results:

- **Paper quotations:** 20 passages marked *verbatim* in
  this sheet were checked character-for-character against
  `word-graph-consolidated-v21-2026-11-18.md` — **20 of 20
  present exactly**. Two further quotations from
  `DESIGN-definitions.md` likewise verified.
- **Lean names:** 106 theorem, definition, and abbreviation
  names cited in this sheet were checked against the ten
  `.lean` files — **106 of 106 exist**.
- **Lean statements:** 45 headline statements quoted in the
  entries were checked (whitespace-normalised) against both
  this sheet and the `.lean` files — **45 of 45 match in
  both**.
- **One failure was found and fixed in this sheet (never in
  a source):** the first draft of Entry 32 quoted two
  design-note sentences across the note's own line breaks;
  the wrapped lines do not contain the joined strings
  character-for-character. Both quotations were re-cut to
  fragments contiguous in the note ("least-committal typed
  option, not as a reading of the paper"; "type with two
  variables is proposed") and re-verified.
- **One discrepancy between a module's prose and the paper
  is recorded, not smoothed:** `DegreeFormula.lean`'s header
  says §4 prints the degree row "1, 2, 1" for (4, 3); §4
  prints the adjacency matrix whose row sums those are.
  See the global flag in this sheet's header and Entry 38.
- Cross-checks run for this sheet: Pilot54's docstring gap
  patterns against Entry 29's theorems (agree, all six);
  the word "degree" searched in the v21 paper (absent);
  `sorry` searched in all ten files (absent); theorem counts
  in the closing summary counted from the files.
