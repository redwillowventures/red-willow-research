import LeanWordgraph.Pilot43
import LeanWordgraph.StepShelf
import LeanWordgraph.Gaps
import Mathlib.Data.Finset.Image
import Mathlib.Data.List.Sort
import Mathlib.Data.List.Pairwise

/-!
# Mirror symmetry of the walk

Continuation of `LeanWordgraph.Pilot43`: the mirror symmetry
of the Word-Graph ("The Word-Graph: Shelves, Walks, and the
Receiver's Reading", Carroll & Willow), §4.

**Fidelity flag (design note A23).** The paper states mirror
symmetry only as an *observation*, and only at shelf `(5, 4)`:
the shelf "is mirror-symmetric under reversal of the gap
pattern — an echo, recorded as observation only, of the
palindromic coefficients of the Igusa cusp form in the
presented work." Nothing in the paper asserts it as a theorem,
at `(5, 4)` or in general. This file proves it as a property
of the *encoding*, for every shelf: the reversal map
`x ↦ s - x` preserves the shelf (`mirror_onShelf`), is an
involution on shelf words (`mirror_involutive`), preserves
the step relation (`mirror_step` — the mirror is an
automorphism of the walk), and reverses the gap pattern
(`mirror_gapPattern`) — the last being exactly the paper's
observed phrasing, "reversal of the gap pattern", now proved
of the encoding. These are theorems about the formalisation,
not claims the paper made in theorem form.

The one place the encoding's arithmetic shows: positions are
natural numbers, so `s - x` is truncated subtraction. Every
use below is on positions `x ≤ s` (a shelf word's positions
lie in `range (s + 1)`), where the truncation never bites and
`s - x` is a genuine involution; the side conditions are
carried explicitly.
-/

namespace WordGraph

/-- The mirror of a word on span `s`: each lit position `x`
is sent to `s - x` — the word read from the other end. -/
def mirror (s : ℕ) (W : Word) : Word := W.image (fun x => s - x)

/-- A lit position of a shelf word is at most the span. -/
theorem OnShelf.le_of_mem {s n : ℕ} {W : Word} (h : OnShelf s n W)
    {x : ℕ} (hx : x ∈ W) : x ≤ s := by
  have hlt := Finset.mem_range.mp (h.2.2.2 hx)
  omega

/-- Truncated subtraction `s - ·` is injective on positions
bounded by `s`: there it is a genuine reflection. -/
theorem sub_injOn_of_le {s : ℕ} {W : Word} (hW : ∀ x ∈ W, x ≤ s) :
    Set.InjOn (fun x => s - x) W := by
  intro x hx y hy hxy
  have hx' := hW x (Finset.mem_coe.mp hx)
  have hy' := hW y (Finset.mem_coe.mp hy)
  have hxy' : s - x = s - y := hxy
  omega

/-- Image commutes with erase under an `InjOn` hypothesis
(Mathlib's `Finset.image_erase` asks for global injectivity,
which `s - ·` on `ℕ` does not have; on a shelf word the
`InjOn` form suffices). -/
theorem image_erase_of_injOn {s : ℕ} {W : Word} {x : ℕ}
    (hinj : Set.InjOn (fun y => s - y) W) (hx : x ∈ W) :
    (W.erase x).image (fun y => s - y)
      = (W.image (fun y => s - y)).erase (s - x) := by
  ext z
  simp only [Finset.mem_image, Finset.mem_erase]
  constructor
  · rintro ⟨w, ⟨hwne, hwW⟩, rfl⟩
    refine ⟨?_, ⟨w, hwW, rfl⟩⟩
    intro hcon
    exact hwne (hinj (Finset.mem_coe.mpr hwW) (Finset.mem_coe.mpr hx) hcon)
  · rintro ⟨hne, ⟨w, hwW, rfl⟩⟩
    refine ⟨w, ⟨?_, hwW⟩, rfl⟩
    intro hwx
    apply hne
    rw [hwx]

/-! ## The mirror preserves the shelf -/

/-- The mirror of a word on shelf `(s, n)` lies on the same
shelf: the endpoints swap (`0 ↦ s`, `s ↦ 0`), the count is
preserved since `s - ·` is injective on the word's positions,
and no position leaves `range (s + 1)`. -/
theorem mirror_onShelf {s n : ℕ} {W : Word} (h : OnShelf s n W) :
    OnShelf s n (mirror s W) := by
  have hinj : Set.InjOn (fun x => s - x) W :=
    sub_injOn_of_le (fun x hx => h.le_of_mem hx)
  refine ⟨?_, ?_, ?_, ?_⟩
  · rw [mirror, Finset.card_image_of_injOn hinj, h.1]
  · -- `0` is lit in the mirror: it is the image of `s`.
    rw [mirror, Finset.mem_image]
    exact ⟨s, h.2.2.1, Nat.sub_self s⟩
  · -- `s` is lit in the mirror: it is the image of `0`.
    rw [mirror, Finset.mem_image]
    exact ⟨0, h.2.1, Nat.sub_zero s⟩
  · intro z hz
    rw [mirror, Finset.mem_image] at hz
    obtain ⟨x, -, rfl⟩ := hz
    exact Finset.mem_range.mpr (Nat.lt_succ_of_le (Nat.sub_le s x))

/-! ## The mirror is an involution -/

/-- Mirroring twice returns the word: on positions `x ≤ s`,
`s - (s - x) = x`. -/
theorem mirror_involutive {s n : ℕ} {W : Word} (h : OnShelf s n W) :
    mirror s (mirror s W) = W := by
  ext z
  simp only [mirror, Finset.mem_image]
  constructor
  · rintro ⟨y, ⟨x, hxW, rfl⟩, hyz⟩
    have hxle : x ≤ s := h.le_of_mem hxW
    have hxx : s - (s - x) = x := by omega
    rw [hxx] at hyz
    exact hyz ▸ hxW
  · intro hzW
    have hzle : z ≤ s := h.le_of_mem hzW
    refine ⟨s - z, ⟨z, hzW, rfl⟩, ?_⟩
    show s - (s - z) = z
    omega

/-! ## The mirror preserves steps -/

/-- The mirror is an automorphism of the walk: if `W` steps
to `W'` on shelf `(s, n)`, then `mirror s W` steps to
`mirror s W'`. The moved letter `x ↦ s - x` and its target
`y ↦ s - y` are again one slot apart (the direction flips:
`x + 1` mirrors to `(s - x) - 1` and vice versa); the
interior witnesses swap sides — the position above `x`
witnesses below `s - x`, and conversely. -/
theorem mirror_step {s n : ℕ} {W W' : Word} (hstep : Step W W')
    (hW : OnShelf s n W) (hW' : OnShelf s n W') :
    Step (mirror s W) (mirror s W') := by
  obtain ⟨x, y, hxW, ⟨a, haW, hax⟩, ⟨b, hbW, hxb⟩, hslot, hyW, hWW'⟩ := hstep
  have hxle : x ≤ s := hW.le_of_mem hxW
  have hble : b ≤ s := hW.le_of_mem hbW
  have hyW' : y ∈ W' := by
    rw [hWW']
    exact Finset.mem_insert_self y (W.erase x)
  have hyle : y ≤ s := hW'.le_of_mem hyW'
  have hinj : Set.InjOn (fun z => s - z) W :=
    sub_injOn_of_le (fun z hz => hW.le_of_mem hz)
  refine ⟨s - x, s - y, Finset.mem_image.mpr ⟨x, hxW, rfl⟩,
    ⟨s - b, Finset.mem_image.mpr ⟨b, hbW, rfl⟩, by omega⟩,
    ⟨s - a, Finset.mem_image.mpr ⟨a, haW, rfl⟩, by omega⟩, ?_, ?_, ?_⟩
  · -- One slot apart, direction flipped.
    rcases hslot with h1 | h1
    · exact Or.inr (by omega)
    · exact Or.inl (by omega)
  · -- The target slot `s - y` is vacant in the mirror word:
    -- a preimage would be a position of `W` mapping to it,
    -- and injectivity on the shelf forces it to be `y` itself.
    intro hmem
    rw [mirror, Finset.mem_image] at hmem
    obtain ⟨z, hzW, hzy⟩ := hmem
    have hzle : z ≤ s := hW.le_of_mem hzW
    have hzy' : s - z = s - y := hzy
    have hzeq : z = y := by omega
    exact hyW (hzeq ▸ hzW)
  · -- The mirrored target word is the mirrored source with
    -- the letter moved.
    show mirror s W' = insert (s - y) ((mirror s W).erase (s - x))
    rw [hWW']
    show (insert y (W.erase x)).image (fun z => s - z)
        = insert (s - y) ((W.image (fun z => s - z)).erase (s - x))
    rw [Finset.image_insert, image_erase_of_injOn hinj hxW]

/-! ## The mirror reverses the gap pattern -/

/-- The gap list of a list of positions: consecutive
differences. `gapPattern W` is this applied to `sortedList W`,
by definition. -/
def gapList (l : List ℕ) : List ℕ := l.zipWith (fun a b => b - a) l.tail

theorem gapPattern_eq_gapList (W : Word) :
    gapPattern W = gapList (sortedList W) := rfl

/-- Appending one position at the end appends one gap: the
difference from the previous last position. -/
theorem gapList_append_singleton : ∀ (u : List ℕ) (v : ℕ) (hu : u ≠ []),
    gapList (u ++ [v]) = gapList u ++ [v - u.getLast hu] := by
  intro u
  induction u with
  | nil => intro v hu; exact absurd rfl hu
  | cons w u ih =>
      intro v hu
      cases u with
      | nil => rfl
      | cons w' u' =>
          have ih' := ih v (List.cons_ne_nil w' u')
          show (w' - w) :: gapList ((w' :: u') ++ [v])
              = (w' - w) :: (gapList (w' :: u')
                ++ [v - (w' :: u').getLast (List.cons_ne_nil w' u')])
          rw [ih']

/-- The gap list of the mirrored list is the reverse of the
gap list: mirroring a strictly increasing list of positions
(all `≤ s`) reverses the order of its consecutive
differences, and each difference is preserved, since for
`a ≤ b ≤ s`, `(s - a) - (s - b) = b - a`. -/
theorem gapList_mirror_reverse {s : ℕ} : ∀ (l : List ℕ),
    List.Pairwise (· < ·) l → (∀ x ∈ l, x ≤ s) →
    gapList ((l.map (fun x => s - x)).reverse) = (gapList l).reverse := by
  intro l
  induction l with
  | nil => intro _ _; rfl
  | cons a l ih =>
      intro hpair hbound
      cases l with
      | nil => rfl
      | cons b l' =>
          have hab : a < b := (List.pairwise_cons.mp hpair).1 b List.mem_cons_self
          have hpair' : List.Pairwise (· < ·) (b :: l') :=
            (List.pairwise_cons.mp hpair).2
          have hbound' : ∀ x ∈ (b :: l'), x ≤ s :=
            fun x hx => hbound x (List.mem_cons_of_mem a hx)
          have ih' := ih hpair' hbound'
          have hale : a ≤ s := hbound a List.mem_cons_self
          have hble : b ≤ s := hbound' b List.mem_cons_self
          have hne : ((b :: l').map (fun x => s - x)).reverse ≠ [] := by
            simp
          have hlast : (((b :: l').map (fun x => s - x)).reverse).getLast hne
              = s - b := by
            have hopt : (((b :: l').map (fun x => s - x)).reverse).getLast?
                = some (s - b) := by
              simp
            rw [List.getLast?_eq_some_getLast hne] at hopt
            exact Option.some.inj hopt
          have hdiff : s - a - (s - b) = b - a := by omega
          calc gapList (((a :: b :: l').map (fun x => s - x)).reverse)
              = gapList (((b :: l').map (fun x => s - x)).reverse ++ [s - a]) := by
                rw [List.map_cons, List.reverse_cons]
            _ = gapList ((b :: l').map (fun x => s - x)).reverse
                  ++ [s - a - (((b :: l').map (fun x => s - x)).reverse).getLast hne] :=
                gapList_append_singleton _ _ hne
            _ = (gapList (b :: l')).reverse ++ [b - a] := by
                rw [ih', hlast, hdiff]
            _ = (gapList (a :: b :: l')).reverse := by
                show (gapList (b :: l')).reverse ++ [b - a]
                    = ((b - a) :: gapList (b :: l')).reverse
                rw [List.reverse_cons]

/-- The sorted list of any word is strictly increasing:
pairwise `≤` (what `Finset.sort` gives) plus no duplicates. -/
theorem sortedList_pairwise_lt (W : Word) :
    List.Pairwise (· < ·) (sortedList W) :=
  List.sortedLT_iff_pairwise.mp
    ((Finset.pairwise_sort W (· ≤ ·)).sortedLE.sortedLT_of_nodup
      (Finset.sort_nodup W (· ≤ ·)))

/-- The mirrored sorted list is strictly increasing: by
induction — mirroring the tail and appending the mirrored
head at the end keeps every earlier element below every
later one, since the head was below everything in the
original list and `s - ·` reverses order on positions
`≤ s`. -/
theorem pairwise_lt_mirrorList {s : ℕ} : ∀ (l : List ℕ),
    List.Pairwise (· < ·) l → (∀ x ∈ l, x ≤ s) →
    List.Pairwise (· < ·) ((l.map (fun x => s - x)).reverse) := by
  intro l
  induction l with
  | nil => intro _ _; exact List.Pairwise.nil
  | cons a l ih =>
      intro hpair hbound
      have ih' := ih (List.pairwise_cons.mp hpair).2
        (fun x hx => hbound x (List.mem_cons_of_mem a hx))
      rw [List.map_cons, List.reverse_cons, List.pairwise_append]
      refine ⟨ih', List.pairwise_singleton _ _, ?_⟩
      intro x hx y hy
      rw [List.mem_singleton] at hy
      subst hy
      rw [List.mem_reverse, List.mem_map] at hx
      obtain ⟨z, hz, hzx⟩ := hx
      have hzx' : s - z = x := hzx
      have haz : a < z := (List.pairwise_cons.mp hpair).1 z hz
      have hzle : z ≤ s := hbound z (List.mem_cons_of_mem a hz)
      omega

/-- The mirror word's sorted list is the mirrored sorted
list, reversed: the two lists are both strictly increasing
and have the same elements, so they are equal
(`List.SortedLT.eq_of_mem_iff`). -/
theorem sortedList_mirror {s n : ℕ} {W : Word} (h : OnShelf s n W) :
    sortedList (mirror s W)
      = ((sortedList W).map (fun x => s - x)).reverse := by
  have hLT₁ : (sortedList (mirror s W)).SortedLT :=
    (Finset.pairwise_sort (mirror s W) (· ≤ ·)).sortedLE.sortedLT_of_nodup
      (Finset.sort_nodup (mirror s W) (· ≤ ·))
  have hLT₂ : (((sortedList W).map (fun x => s - x)).reverse).SortedLT :=
    List.sortedLT_iff_pairwise.mpr
      (pairwise_lt_mirrorList (sortedList W) (sortedList_pairwise_lt W)
        (fun x hx => h.le_of_mem ((Finset.mem_sort (· ≤ ·)).mp hx)))
  apply hLT₁.eq_of_mem_iff hLT₂
  intro z
  constructor
  · intro hz
    have hzW : z ∈ mirror s W := (Finset.mem_sort (· ≤ ·)).mp hz
    rw [mirror, Finset.mem_image] at hzW
    obtain ⟨x, hxW, hxz⟩ := hzW
    exact List.mem_reverse.mpr
      (List.mem_map.mpr ⟨x, (Finset.mem_sort (· ≤ ·)).mpr hxW, hxz⟩)
  · intro hz
    rw [List.mem_reverse, List.mem_map] at hz
    obtain ⟨x, hxL, hxz⟩ := hz
    apply (Finset.mem_sort (· ≤ ·)).mpr
    rw [mirror, Finset.mem_image]
    exact ⟨x, (Finset.mem_sort (· ≤ ·)).mp hxL, hxz⟩

/-- The mirror reverses the gap pattern — the paper's §4
observation ("mirror-symmetric under reversal of the gap
pattern", recorded there as observation only, flag A23),
proved here as a property of the encoding, for every shelf. -/
theorem mirror_gapPattern {s n : ℕ} {W : Word} (h : OnShelf s n W) :
    gapPattern (mirror s W) = (gapPattern W).reverse := by
  rw [gapPattern_eq_gapList, gapPattern_eq_gapList, sortedList_mirror h]
  exact gapList_mirror_reverse (sortedList W) (sortedList_pairwise_lt W)
    (fun x hx => h.le_of_mem ((Finset.mem_sort (· ≤ ·)).mp hx))

end WordGraph
