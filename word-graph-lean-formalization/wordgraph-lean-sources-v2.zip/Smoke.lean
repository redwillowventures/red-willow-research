import Mathlib

/-- Smoke test 1: basic arithmetic by reflexivity. -/
theorem smoke1 : 1 + 1 = 2 := rfl

/-- Smoke test 2: a Mathlib definition (`Nat.choose`) computes correctly. -/
theorem smoke2 : Nat.choose 3 1 = 3 := rfl
