import LeanWordgraph.Pilot43
import LeanWordgraph.Pilot54
import LeanWordgraph.StepShelf
import LeanWordgraph.Gaps
import Mathlib.Data.Finset.Card
import Mathlib.Data.Finset.Sort

/-!
# The small remainders of §4: (5, 4) gap values, the (4, 3)
adjacency matrix, and the smallest shelf

Continuation of `LeanWordgraph.Pilot43`, `LeanWordgraph.Pilot54`
and `LeanWordgraph.Gaps`: three independent remainders from
§4 of "The Word-Graph: Shelves, Walks, and the Receiver's
Reading" (Carroll & Willow).

## Part 1 — the gap values of shelf (5, 4)

`Pilot54` records the six words' gap patterns only in
docstrings. Here they are theorems, each computed from the
word definitions (via the `Finset.sort_insert` route of the
pilot, `Finset.sort` not being kernel-reducible): the patterns
are `[1,1,3]`, `[1,2,2]`, `[1,3,1]`, `[2,1,2]`, `[2,2,1]`,
`[3,1,1]` — each of length `3 = n - 1` and sum `5 = s`, as
`Gaps.gaps_length` and `Gaps.gaps_sum` require.

## Part 2 — the (4, 3) adjacency matrix as a whole

§4: "adjacency matrix, in that order: row one 0 1 0; row two
1 0 1; row three 0 1 0." The within-shelf neighbour sets below
are exactly those rows; the zero diagonal is the general lemma
`step_irrefl` (no word steps to itself — a step's landing slot
`y` lies in the stepped-to word but, by the rule, not in the
word itself); and `not_step_w3_w1` completes the matrix's last
unproved entry, from `Pilot43.not_step_w1_w3` by symmetry of
the step relation (`Step.symm'`).

## Part 3 — the smallest shelf: a determination

§4's words, verbatim: "**Smallest shelf, (4, 3):** the words
{0,1,4} (gaps 1,3), {0,2,4} (2,2), {0,3,4} (3,1) form a path;
adjacency matrix, in that order: row one 0 1 0; row two 1 0 1;
row three 0 1 0. Second shelf, (5, 4): …". The paper states
no predicate for "smallest". Two readings were tested against
the encoding:

* *Broad reading* — "no smaller shelf carries a step":
  **false**, and the paper's own later sections refute it —
  shelf (3, 3) is exhibited there carrying "a true single
  slide" ({0,1,3} against {0,2,3}). The counterexample is
  recorded below as `shelf33_words` and `step_33`, so the
  broad reading is *not* formalised.

* *Narrow reading* — the exhibit's own content is the path:
  (4, 3) is the smallest shelf, in the (span, weight) order in
  which §4 presents its shelves ("Second shelf, (5, 4)"),
  whose walk contains a word with two within-shelf neighbours
  — the middle of the path, the `1 0 1` row. That claim is
  formalised exactly, as `smallest_shelf_43`: positively, the
  middle word `w2` of (4, 3) has exactly two neighbours;
  negatively, every admissible shelf (`2 ≤ n ≤ s + 1`) strictly
  below (4, 3) in that order has all within-shelf degrees
  `≤ 1` — its walk, where it moves at all, is a single edge.

**Flag.** The paper never uses the word "degree"; the
predicate (a word with two neighbours) is read off the
exhibit's adjacency matrix, not quoted. The determination
rests on: (i) the broad reading is refuted by the paper
itself; (ii) the path — whose centre is the degree-two word —
is the whole content of the §4 exhibit; (iii) the ordering is
the one §4's "Second shelf" fixes. If that reading is not
accepted, the paper's sentence as it stands is not
determinable beyond it.
-/

namespace WordGraph

/-! ## Part 1 — gap values of shelf (5, 4) -/

/-- The sorted list of `{0,1,2,5}` is `[0, 1, 2, 5]`. -/
theorem sortedList_u1 : sortedList u1 = [0, 1, 2, 5] := by
  change Finset.sort u1 (· ≤ ·) = [0, 1, 2, 5]
  rw [show u1 = insert 0 (insert 1 (insert 2 ({5} : Finset ℕ))) from rfl,
    Finset.sort_insert (· ≤ ·) (a := 0)
      (s := insert 1 (insert 2 ({5} : Finset ℕ))) (by decide) (by decide),
    Finset.sort_insert (· ≤ ·) (a := 1)
      (s := insert 2 ({5} : Finset ℕ)) (by decide) (by decide),
    Finset.sort_insert (· ≤ ·) (a := 2) (s := ({5} : Finset ℕ))
      (by decide) (by decide),
    Finset.sort_singleton]

/-- The sorted list of `{0,1,3,5}` is `[0, 1, 3, 5]`. -/
theorem sortedList_u2 : sortedList u2 = [0, 1, 3, 5] := by
  change Finset.sort u2 (· ≤ ·) = [0, 1, 3, 5]
  rw [show u2 = insert 0 (insert 1 (insert 3 ({5} : Finset ℕ))) from rfl,
    Finset.sort_insert (· ≤ ·) (a := 0)
      (s := insert 1 (insert 3 ({5} : Finset ℕ))) (by decide) (by decide),
    Finset.sort_insert (· ≤ ·) (a := 1)
      (s := insert 3 ({5} : Finset ℕ)) (by decide) (by decide),
    Finset.sort_insert (· ≤ ·) (a := 3) (s := ({5} : Finset ℕ))
      (by decide) (by decide),
    Finset.sort_singleton]

/-- The sorted list of `{0,1,4,5}` is `[0, 1, 4, 5]`. -/
theorem sortedList_u3 : sortedList u3 = [0, 1, 4, 5] := by
  change Finset.sort u3 (· ≤ ·) = [0, 1, 4, 5]
  rw [show u3 = insert 0 (insert 1 (insert 4 ({5} : Finset ℕ))) from rfl,
    Finset.sort_insert (· ≤ ·) (a := 0)
      (s := insert 1 (insert 4 ({5} : Finset ℕ))) (by decide) (by decide),
    Finset.sort_insert (· ≤ ·) (a := 1)
      (s := insert 4 ({5} : Finset ℕ)) (by decide) (by decide),
    Finset.sort_insert (· ≤ ·) (a := 4) (s := ({5} : Finset ℕ))
      (by decide) (by decide),
    Finset.sort_singleton]

/-- The sorted list of `{0,2,3,5}` is `[0, 2, 3, 5]`. -/
theorem sortedList_u4 : sortedList u4 = [0, 2, 3, 5] := by
  change Finset.sort u4 (· ≤ ·) = [0, 2, 3, 5]
  rw [show u4 = insert 0 (insert 2 (insert 3 ({5} : Finset ℕ))) from rfl,
    Finset.sort_insert (· ≤ ·) (a := 0)
      (s := insert 2 (insert 3 ({5} : Finset ℕ))) (by decide) (by decide),
    Finset.sort_insert (· ≤ ·) (a := 2)
      (s := insert 3 ({5} : Finset ℕ)) (by decide) (by decide),
    Finset.sort_insert (· ≤ ·) (a := 3) (s := ({5} : Finset ℕ))
      (by decide) (by decide),
    Finset.sort_singleton]

/-- The sorted list of `{0,2,4,5}` is `[0, 2, 4, 5]`. -/
theorem sortedList_u5 : sortedList u5 = [0, 2, 4, 5] := by
  change Finset.sort u5 (· ≤ ·) = [0, 2, 4, 5]
  rw [show u5 = insert 0 (insert 2 (insert 4 ({5} : Finset ℕ))) from rfl,
    Finset.sort_insert (· ≤ ·) (a := 0)
      (s := insert 2 (insert 4 ({5} : Finset ℕ))) (by decide) (by decide),
    Finset.sort_insert (· ≤ ·) (a := 2)
      (s := insert 4 ({5} : Finset ℕ)) (by decide) (by decide),
    Finset.sort_insert (· ≤ ·) (a := 4) (s := ({5} : Finset ℕ))
      (by decide) (by decide),
    Finset.sort_singleton]

/-- The sorted list of `{0,3,4,5}` is `[0, 3, 4, 5]`. -/
theorem sortedList_u6 : sortedList u6 = [0, 3, 4, 5] := by
  change Finset.sort u6 (· ≤ ·) = [0, 3, 4, 5]
  rw [show u6 = insert 0 (insert 3 (insert 4 ({5} : Finset ℕ))) from rfl,
    Finset.sort_insert (· ≤ ·) (a := 0)
      (s := insert 3 (insert 4 ({5} : Finset ℕ))) (by decide) (by decide),
    Finset.sort_insert (· ≤ ·) (a := 3)
      (s := insert 4 ({5} : Finset ℕ)) (by decide) (by decide),
    Finset.sort_insert (· ≤ ·) (a := 4) (s := ({5} : Finset ℕ))
      (by decide) (by decide),
    Finset.sort_singleton]

/-- Gap pattern of `u1 = {0,1,2,5}` is `(1, 1, 3)` (paper §4,
via `Pilot54`'s docstring, here a theorem). -/
theorem gap_u1 : gapPattern u1 = [1, 1, 3] := by
  unfold gapPattern
  rw [sortedList_u1]
  decide

/-- Gap pattern of `u2 = {0,1,3,5}` is `(1, 2, 2)`. -/
theorem gap_u2 : gapPattern u2 = [1, 2, 2] := by
  unfold gapPattern
  rw [sortedList_u2]
  decide

/-- Gap pattern of `u3 = {0,1,4,5}` is `(1, 3, 1)`. -/
theorem gap_u3 : gapPattern u3 = [1, 3, 1] := by
  unfold gapPattern
  rw [sortedList_u3]
  decide

/-- Gap pattern of `u4 = {0,2,3,5}` is `(2, 1, 2)`. -/
theorem gap_u4 : gapPattern u4 = [2, 1, 2] := by
  unfold gapPattern
  rw [sortedList_u4]
  decide

/-- Gap pattern of `u5 = {0,2,4,5}` is `(2, 2, 1)`. -/
theorem gap_u5 : gapPattern u5 = [2, 2, 1] := by
  unfold gapPattern
  rw [sortedList_u5]
  decide

/-- Gap pattern of `u6 = {0,3,4,5}` is `(3, 1, 1)`. -/
theorem gap_u6 : gapPattern u6 = [3, 1, 1] := by
  unfold gapPattern
  rw [sortedList_u6]
  decide

/-! ## Part 2 — the (4, 3) adjacency matrix as a whole -/

/-- The neighbours of `w1` within shelf (4, 3): just `w2`
— row one of §4's matrix, `0 1 0`. -/
theorem neighbors43_w1 : shelfNeighbors 4 3 w1 = {w2} := by decide

/-- The neighbours of `w2` within shelf (4, 3): `w1`, `w3`
— row two of §4's matrix, `1 0 1`. -/
theorem neighbors43_w2 : shelfNeighbors 4 3 w2 = {w1, w3} := by decide

/-- The neighbours of `w3` within shelf (4, 3): just `w2`
— row three of §4's matrix, `0 1 0`. -/
theorem neighbors43_w3 : shelfNeighbors 4 3 w3 = {w2} := by decide

/-- The zero diagonal, in general: no word steps to itself.
A step's landing slot `y` lies in the stepped-to word by
construction, but the step rule requires `y ∉ W`; if the two
words were equal, both would hold at once. -/
theorem step_irrefl (W : Word) : ¬ Step W W := by
  rintro ⟨x, y, -, -, -, -, hy, hEq⟩
  apply hy
  rw [hEq]
  exact Finset.mem_insert_self y _

/-- The last unproved entry of the (4, 3) matrix: `w3` does
not step to `w1` either (the `0` at row three, column one).
From `Pilot43.not_step_w1_w3` by symmetry of the step. -/
theorem not_step_w3_w1 : ¬ Step w3 w1 :=
  fun h => not_step_w1_w3 h.symm'

/-! ## Part 3 — the smallest shelf -/

/-- The counterexample to the broad reading of "smallest":
shelf (3, 3) has exactly two words, `{0,1,3}` and `{0,2,3}`. -/
theorem shelf33_words : shelfWords 3 3 = {{0, 1, 3}, {0, 2, 3}} := by
  decide

/-- …and it carries a step: the letter at 1 slides to 2.
So "no smaller shelf carries a step" is false — as the
paper's own later sections record ("a true single slide").
The broad reading of §4's "Smallest shelf" is therefore not
the paper's meaning, and is not formalised. -/
theorem step_33 : Step ({0, 1, 3} : Word) ({0, 2, 3} : Word) :=
  ⟨1, 2, by decide, ⟨0, by decide, by decide⟩, ⟨3, by decide, by decide⟩,
   Or.inl rfl, by decide, by decide⟩

/-- Positive half of the narrow reading: the middle word of
shelf (4, 3) has exactly two within-shelf neighbours — it is
the centre of the path, the `1 0 1` row of the matrix. -/
theorem degree43_w2 : (shelfNeighbors 4 3 w2).card = 2 := by
  rw [neighbors43_w2]
  decide

/-- Negative half of the narrow reading: on every admissible
shelf (`2 ≤ n`, `n ≤ s + 1`) strictly below `(4, 3)` in the
(span, weight) order — span `< 4`, or span `4` with weight
`< 3` — every word has at most one within-shelf neighbour:
no shelf below (4, 3) contains the centre of a path. The
admissible shelves below (4, 3) are exactly
`(1,2), (2,2), (2,3), (3,2), (3,3), (3,4), (4,2)`, and each
case is decided outright. -/
theorem no_degree_two_below_43 {s n : ℕ} (hn : 2 ≤ n) (hns : n ≤ s + 1)
    (hlt : s < 4 ∨ (s = 4 ∧ n < 3)) :
    ∀ W ∈ shelfWords s n, (shelfNeighbors s n W).card ≤ 1 := by
  have hcases : (s = 1 ∧ n = 2) ∨ (s = 2 ∧ n = 2) ∨ (s = 2 ∧ n = 3) ∨
      (s = 3 ∧ n = 2) ∨ (s = 3 ∧ n = 3) ∨ (s = 3 ∧ n = 4) ∨
      (s = 4 ∧ n = 2) := by
    rcases hlt with h | ⟨h, hn3⟩ <;> omega
  rcases hcases with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ |
    ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ <;> decide

/-- **The smallest shelf, narrow reading** (§4): shelf
`(4, 3)` contains a word with exactly two within-shelf
neighbours (the middle of its path), and no admissible shelf
strictly below it in the (span, weight) order does. See the
file header for the determination and its flags. -/
theorem smallest_shelf_43 :
    (shelfNeighbors 4 3 w2).card = 2 ∧
    ∀ s n : ℕ, 2 ≤ n → n ≤ s + 1 → (s < 4 ∨ (s = 4 ∧ n < 3)) →
      ∀ W ∈ shelfWords s n, (shelfNeighbors s n W).card ≤ 1 :=
  ⟨degree43_w2, fun _ _ hn hns hlt => no_degree_two_below_43 hn hns hlt⟩

end WordGraph
