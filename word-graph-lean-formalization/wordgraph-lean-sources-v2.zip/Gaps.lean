import LeanWordgraph.Pilot43
import LeanWordgraph.StepShelf

/-!
# The gap pattern is the word's name

Continuation of `LeanWordgraph.Pilot43`: the general facts about
the gap pattern (paper §3, C1 — "the sequence of consecutive
differences between lit positions; the word's shape, and the
finest invariant the material supports") that the pilot stated
only at shelf (4, 3). The paper's §3, as re-levelled: "a shelf is
span plus weight (C3 + C2); the walk moves one interior letter
one slot; the gap pattern becomes each word's name within its
shelf." This file proves, for a word `W` on an arbitrary shelf
`(s, n)`:

* `gaps_length`: the pattern has length `n - 1` — one gap per
  adjacent pair of lit positions;
* `gaps_sum`: the pattern sums to `s` — the gaps telescope from
  the first lit position `0` to the last, `s` (the span, C3);
* `gaps_injective`: the name theorem — two words on the same
  shelf with the same gap pattern are the same word. The
  sorted list of positions is the partial sums of the gaps
  starting at `0`, so the pattern determines the word.

It also records the step-conservation corollaries of
`StepShelf`: a step conserves the weight (C2, `Step.card_eq` of
the pilot) and conserves the shelf itself — span (C3) and
weight together, the shelf being span plus weight. There is no
standalone `span` function in the formalisation (the shelf
predicate carries the span, as the endpoints `0` and `s`), so
span conservation is stated as shelf conservation.

The gap function is the pilot's `gapPattern`, already general:
`gapPattern W = (sortedList W).zipWith (fun a b => b - a)
(sortedList W).tail`. The three list lemmas below are that same
`zipWith` over an arbitrary list with head `a`, proved once and
applied to `sortedList W`. Sortedness is carried as
`List.Pairwise (· ≤ ·)` — what `Finset.pairwise_sort` gives for
`sortedList W`.
-/

namespace WordGraph

/-! ## List lemmas: telescoping and reconstruction -/

/-- Telescoping: for a pairwise-`≤` list with head `a`, the sum
of the consecutive differences plus `a` is the last element.
Sortedness is what makes the ℕ-subtractions genuine, so the
sum telescopes. -/
theorem zipWith_sub_sum_add_head : ∀ (l : List ℕ) (a : ℕ) (h : (a :: l) ≠ []),
    List.Pairwise (· ≤ ·) (a :: l) →
    ((a :: l).zipWith (fun x y => y - x) (a :: l).tail).sum + a
      = (a :: l).getLast h := by
  intro l
  induction l with
  | nil =>
      intro a h _
      simp [List.getLast_singleton]
  | cons b l ih =>
      intro a h hpair
      have hab : a ≤ b := (List.pairwise_cons.mp hpair).1 b List.mem_cons_self
      have hpair' : List.Pairwise (· ≤ ·) (b :: l) := (List.pairwise_cons.mp hpair).2
      have ih' := ih b (List.cons_ne_nil b l) hpair'
      rw [List.tail_cons, List.zipWith_cons_cons, List.sum_cons]
      rw [List.tail_cons] at ih'
      have hgl : (a :: b :: l).getLast h = (b :: l).getLast (List.cons_ne_nil b l) := rfl
      rw [hgl]
      omega

/-- In a pairwise-`≤` list, every element is at most the last
element. -/
theorem le_getLast_of_pairwise : ∀ (l : List ℕ) (a x : ℕ) (h : (a :: l) ≠ []),
    List.Pairwise (· ≤ ·) (a :: l) → x ∈ a :: l → x ≤ (a :: l).getLast h := by
  intro l
  induction l with
  | nil =>
      intro a x h _ hx
      have hx2 : x = a := by simpa using hx
      rw [hx2, List.getLast_singleton]
  | cons b l ih =>
      intro a x h hpair hx
      have hab : a ≤ b := (List.pairwise_cons.mp hpair).1 b List.mem_cons_self
      have hpair' : List.Pairwise (· ≤ ·) (b :: l) := (List.pairwise_cons.mp hpair).2
      have hgl : (a :: b :: l).getLast h = (b :: l).getLast (List.cons_ne_nil b l) := rfl
      rw [hgl]
      rcases List.mem_cons.mp hx with rfl | hx'
      · exact le_trans hab (ih b b _ hpair' List.mem_cons_self)
      · exact ih b x _ hpair' hx'

/-- Reconstruction at list level: a pairwise-`≤` list of
naturals is determined by its head, its length, and its list
of consecutive differences. Induction on the first list: the
first difference and the two heads fix the second element
(sortedness turns `b - a = d - c` with `a = c` into `b = d`),
and the tails are then equal by the induction hypothesis. -/
theorem list_eq_of_zipWith_sub_eq : ∀ (l₁ l₂ : List ℕ),
    List.Pairwise (· ≤ ·) l₁ → List.Pairwise (· ≤ ·) l₂ →
    l₁.length = l₂.length → l₁.head? = l₂.head? →
    l₁.zipWith (fun x y => y - x) l₁.tail
      = l₂.zipWith (fun x y => y - x) l₂.tail →
    l₁ = l₂ := by
  intro l₁
  induction l₁ with
  | nil =>
      intro l₂ _ _ hlen _ _
      cases l₂ with
      | nil => rfl
      | cons b l₂' =>
          simp only [List.length_nil, List.length_cons] at hlen
          omega
  | cons a r₁ ih =>
      intro l₂ hs₁ hs₂ hlen hhead hgaps
      cases r₁ with
      | nil =>
          cases l₂ with
          | nil =>
              simp only [List.length_nil, List.length_cons] at hlen
              omega
          | cons b l₂' =>
              cases l₂' with
              | nil =>
                  have hab : a = b := by simpa using hhead
                  rw [hab]
              | cons c l₂'' =>
                  simp only [List.length_cons, List.length_nil] at hlen
                  omega
      | cons b r₁' =>
          cases l₂ with
          | nil =>
              simp only [List.length_nil, List.length_cons] at hlen
              omega
          | cons c r₂ =>
              cases r₂ with
              | nil =>
                  simp only [List.length_cons, List.length_nil] at hlen
                  omega
              | cons d r₂' =>
                  have hac : a = c := by simpa using hhead
                  have hab : a ≤ b :=
                    (List.pairwise_cons.mp hs₁).1 b List.mem_cons_self
                  have hcd : c ≤ d :=
                    (List.pairwise_cons.mp hs₂).1 d List.mem_cons_self
                  have hs₁' : List.Pairwise (· ≤ ·) (b :: r₁') :=
                    (List.pairwise_cons.mp hs₁).2
                  have hs₂' : List.Pairwise (· ≤ ·) (d :: r₂') :=
                    (List.pairwise_cons.mp hs₂).2
                  simp only [List.tail_cons, List.zipWith_cons_cons] at hgaps
                  injection hgaps with hgap1 hgap2
                  have hbd : b = d := by omega
                  have hlen' : (b :: r₁').length = (d :: r₂').length := by
                    simp only [List.length_cons] at hlen ⊢
                    omega
                  have hhead' : (b :: r₁').head? = (d :: r₂').head? := by
                    simp [hbd]
                  have htail : b :: r₁' = d :: r₂' :=
                    ih _ hs₁' hs₂' hlen' hhead' hgap2
                  rw [hac, htail]

/-! ## The sorted list of a shelf word starts at 0 -/

/-- The sorted list of a word on a shelf begins at `0`: the
pinning endpoint is lit, and sortedness puts the least lit
position first — and no position is below `0`. -/
theorem sortedList_eq_cons_zero {s n : ℕ} {W : Word} (h : OnShelf s n W) :
    ∃ l : List ℕ, sortedList W = 0 :: l := by
  have h0L : 0 ∈ sortedList W := (Finset.mem_sort (· ≤ ·)).mpr h.2.1
  obtain ⟨a, l, hl⟩ := List.exists_cons_of_ne_nil (List.ne_nil_of_mem h0L)
  refine ⟨l, ?_⟩
  have hpair : List.Pairwise (· ≤ ·) (a :: l) := by
    rw [← hl]; exact Finset.pairwise_sort W (· ≤ ·)
  rw [hl] at h0L
  have ha : a = 0 := by
    rcases List.mem_cons.mp h0L with h0 | h0
    · exact h0.symm
    · have hle : a ≤ 0 := (List.pairwise_cons.mp hpair).1 0 h0
      omega
  rw [ha] at hl
  exact hl

/-! ## The three gap theorems -/

/-- The gap pattern of a word on shelf `(s, n)` has length
`n - 1`: one gap per adjacent pair of lit positions. -/
theorem gaps_length {s n : ℕ} {W : Word} (h : OnShelf s n W) :
    (gapPattern W).length = n - 1 := by
  change ((Finset.sort W (· ≤ ·)).zipWith (fun a b => b - a)
    (Finset.sort W (· ≤ ·)).tail).length = n - 1
  rw [List.length_zipWith, List.length_tail, Finset.length_sort, h.1]
  exact Nat.min_eq_right (Nat.sub_le n 1)

/-- The gap pattern of a word on shelf `(s, n)` sums to `s`:
the gaps telescope from the first lit position `0` to the
last, `s` — the span (C3). -/
theorem gaps_sum {s n : ℕ} {W : Word} (h : OnShelf s n W) :
    (gapPattern W).sum = s := by
  obtain ⟨l, hl⟩ := sortedList_eq_cons_zero h
  have hpair : List.Pairwise (· ≤ ·) (0 :: l) := by
    rw [← hl]; exact Finset.pairwise_sort W (· ≤ ·)
  have hne : (0 :: l) ≠ [] := List.cons_ne_nil 0 l
  have hsum := zipWith_sub_sum_add_head l 0 hne hpair
  have hgl : (0 :: l).getLast hne = s := by
    apply le_antisymm
    · -- The last lit position is a position of `W`, hence ≤ s.
      have hmem : (0 :: l).getLast hne ∈ sortedList W := by
        rw [hl]; exact List.getLast_mem hne
      have hmemW : (0 :: l).getLast hne ∈ W := (Finset.mem_sort (· ≤ ·)).mp hmem
      have hlt := Finset.mem_range.mp (h.2.2.2 hmemW)
      omega
    · -- And `s` itself is lit, hence ≤ the last lit position.
      have hsL : s ∈ 0 :: l := by
        rw [← hl]; exact (Finset.mem_sort (· ≤ ·)).mpr h.2.2.1
      exact le_getLast_of_pairwise l 0 s hne hpair hsL
  have hgoal : (gapPattern W).sum
      = ((0 :: l).zipWith (fun x y => y - x) (0 :: l).tail).sum := by
    change ((sortedList W).zipWith (fun a b => b - a) (sortedList W).tail).sum = _
    rw [hl]
  rw [Nat.add_zero] at hsum
  rw [hgoal]
  exact hsum.trans hgl

/-- The name theorem: on a pinned shelf, the gap pattern
determines the word. Two words on the same shelf `(s, n)`
with equal gap patterns are equal — each sorted list is the
partial sums of the pattern starting at `0`, and a word is
its sorted list. -/
theorem gaps_injective {s n : ℕ} {W₁ W₂ : Word} (h₁ : OnShelf s n W₁)
    (h₂ : OnShelf s n W₂) (hg : gapPattern W₁ = gapPattern W₂) : W₁ = W₂ := by
  obtain ⟨l₁, hl₁⟩ := sortedList_eq_cons_zero h₁
  obtain ⟨l₂, hl₂⟩ := sortedList_eq_cons_zero h₂
  have hpair₁ : List.Pairwise (· ≤ ·) (0 :: l₁) := by
    rw [← hl₁]; exact Finset.pairwise_sort W₁ (· ≤ ·)
  have hpair₂ : List.Pairwise (· ≤ ·) (0 :: l₂) := by
    rw [← hl₂]; exact Finset.pairwise_sort W₂ (· ≤ ·)
  have hlen : (0 :: l₁).length = (0 :: l₂).length := by
    have e₁ : (sortedList W₁).length = n := by
      change (Finset.sort W₁ (· ≤ ·)).length = n
      rw [Finset.length_sort, h₁.1]
    have e₂ : (sortedList W₂).length = n := by
      change (Finset.sort W₂ (· ≤ ·)).length = n
      rw [Finset.length_sort, h₂.1]
    rw [← hl₁, ← hl₂]
    exact e₁.trans e₂.symm
  have hg' : (0 :: l₁).zipWith (fun x y => y - x) (0 :: l₁).tail
      = (0 :: l₂).zipWith (fun x y => y - x) (0 :: l₂).tail := by
    have hgg : (sortedList W₁).zipWith (fun a b => b - a) (sortedList W₁).tail
        = (sortedList W₂).zipWith (fun a b => b - a) (sortedList W₂).tail := hg
    rw [hl₁, hl₂] at hgg
    exact hgg
  have hEq : (0 : ℕ) :: l₁ = 0 :: l₂ :=
    list_eq_of_zipWith_sub_eq _ _ hpair₁ hpair₂ hlen (by simp) hg'
  have hsort : sortedList W₁ = sortedList W₂ := by rw [hl₁, hl₂, hEq]
  calc W₁ = (sortedList W₁).toFinset := (Finset.sort_toFinset W₁ (· ≤ ·)).symm
    _ = (sortedList W₂).toFinset := by rw [hsort]
    _ = W₂ := Finset.sort_toFinset W₂ (· ≤ ·)

/-! ## Step conservation corollaries -/

/-- A step conserves the weight (C2): the stepped-to word has
the same number of lit positions. This is `Step.card_eq` of
the pilot, restated as the conservation corollary. -/
theorem Step.weight_conserved {W W' : Word} (h : Step W W') : W'.card = W.card :=
  h.card_eq

/-- A step conserves the shelf: if `W` lies on shelf `(s, n)`
and steps to `W'`, then `W'` lies on the same shelf — span
(C3) and weight (C2) together, the shelf being span plus
weight. This is `Step.onShelf` of StepShelf, restated as the
conservation corollary. -/
theorem Step.shelf_conserved {s n : ℕ} {W W' : Word} (h : Step W W')
    (hW : OnShelf s n W) : OnShelf s n W' :=
  h.onShelf hW

end WordGraph
