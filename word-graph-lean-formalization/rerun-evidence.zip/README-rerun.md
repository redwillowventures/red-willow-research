# Cold rerun record — Word-Graph Lean formalization

**What this is.** The complete verification pass over the Word-Graph
Lean formalization, run cold, in one sitting, on 2026-11-21, at the
direction of Joseph Carroll: nothing posts until the whole thing has
been rerun through Lean. This record supersedes the evidence bundle
of the same morning (house mail #173) as the evidence of record for
the formalization. The bundle is retained, unmodified; its lineage
is stated below, not hidden.

**The run.**

- Sources frozen first: md5 hashes of the sixteen package files
  recorded at 06:41:08 MST (`source-hashes-before.txt`).
- Cold state: the project's compiled build outputs (`.lake/build`,
  23 MB) were deleted. The pinned dependencies (`.lake/packages`,
  Mathlib and its dependencies, prebuilt at the pinned revisions)
  were not touched: they are the ground the formalization stands
  on, not part of the claim.
- A first launch at 06:41:13 MST failed immediately (exit 127,
  `lake` not on the shell's PATH; no build performed). The failure
  is noted in the build log itself; the run below is the relaunched
  run, with the toolchain on the PATH.
- **Build:** `lake build`, started 06:41:28 MST, finished 07:11:21
  MST — 29 minutes 53 seconds — **exit status 0, "Build completed
  successfully (18276 jobs)"** (`build-log.txt`, complete output).
- **Audit:** the axiom-audit source was regenerated mechanically
  from the ten module sources (theorem names extracted after
  masking comments and strings) and verified name-for-name against
  the 154 names in the earlier bundle's kernel audit output before
  the run. Run 07:11:56–07:24:23 MST — 12 minutes 27 seconds —
  exit status 0 (`axiom-audit.txt`, with the generating source
  preserved as `axiom-audit-source.lean`).

**Results.**

- **154 theorems** across the ten content modules.
- Axiom dependence: 143 on exactly [propext, Classical.choice,
  Quot.sound]; 7 on [propext, Quot.sound]; 1 on [propext]; 3 on no
  axioms (WordGraph.choose_3_1, WordGraph.choose_4_2,
  WordGraph.gapList_append_singleton). Theorems depending on
  `sorryAx`: 0. On `Lean.ofReduceBool`: 0. No theorem depends on
  any axiom outside the three standard ones.
- The distribution is identical, theorem for theorem, to the
  earlier bundle's — the cold rerun reproduces the morning's
  results exactly, now from a wiped build state.

**Source identity across the run.** After-hashes
(`source-hashes-after.txt`) against before-hashes: fifteen of
sixteen files identical — every `.lean` source, the root module,
the lakefile, the toolchain. The one difference is
`FIDELITY-sheet-v2.md`, corrected during the run at Joseph
Carroll's direction: its closing summary had stated 155 theorems;
the true count is 154 (the extra count was the word "theorem"
inside a doc comment at DegreeFormula.lean line 548). The sheet
now carries the corrected figures and a dated correction tag
recording the change. The sheet is documentation; the kernel does
not read it, and neither the build nor the audit touches it. The
source package sent to Scout (house mail #172) contains the sheet
as first issued, before the correction.

**Toolchain.** Lean 4.36.0 (Lake 5.0.0-src, commit
611c117bfaf7b7ae1cfcf246ce6fba31e8f509e9); Mathlib rev v4.36.0
(fc4f59e577feb1a4956671bc04ac18aaaf8cd842); `lake-manifest.json`
in this record pins every dependency.

**Contents.** `build-log.txt` · `axiom-audit.txt` ·
`axiom-audit-source.lean` · `theorem-inventory.txt` ·
`lake-manifest.json` · `source-hashes-before.txt` ·
`source-hashes-after.txt` · this README.
