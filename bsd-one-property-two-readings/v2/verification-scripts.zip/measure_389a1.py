# Step 1 measurement: BSD transfer quotient for 389a1, Pip's own computation (PARI via cypari2).
# Curve: y^2 + y = x^3 + x^2 - 2x   [a-invariants 0,1,1,-2,0], conductor 389.
# Quotient Q = (L^(r)(E,1)/r!) * |tors|^2 / (Reg * Omega * prod c_p)  ==  |Sha| predicted by BSD.
# Rank gap Delta_rank = r_analytic - r_algebraic.  Both measured independently below.
from cypari2 import Pari
pari = Pari()

def measure(prec):
    pari(f"default(realprecision,{prec})")
    E = pari("ellinit([0,1,1,-2,0])")
    # algebraic side
    r_bounds = pari(f"ellrank({E})")          # [lower, upper] bounds on Mordell-Weil rank
    gens = pari("[[0,0],[1,0]]")
    on_curve = [bool(pari(f"ellisoncurve({E},{g})")) for g in ["[0,0]", "[1,0]"]]
    H = pari(f"ellheightmatrix({E},{gens})")  # canonical-height pairing matrix, standard (NT) normalization
    Reg = pari(f"matdet({H})")
    tors = int(pari(f"elltors({E})[1]"))
    gr = pari(f"ellglobalred({E})")
    N = int(pari(f"{gr}[1]"))
    tam = pari(f"prod(i=1,matsize({gr}[5])[1], {gr}[5][i][4])")  # product of Tamagawa numbers
    Omega = pari(f"if({E}.disc>0,2,1)*{E}.omega[1]")             # real period (disc=389>0)
    # analytic side, two independent routes
    ar = pari(f"ellanalyticrank({E})")        # [r_an, L^(r)(1)] — PARI returns the raw derivative (verified: exactly 2x route 2)
    r_an = int(pari(f"{ar}[1]"))
    Lr_route1 = pari(f"({ar}[2])/2!")          # normalize to L^(r)(1)/r!
    Lr_route2 = pari(f"lfun({E},1,2)/2!")     # second derivative at s=1, divided by 2!
    Q = pari(f"({Lr_route1})*{tors}^2/(({Reg})*({Omega})*({tam}))")
    return dict(prec=prec, N=N, r_bounds=[int(pari(f"{r_bounds}[1]")), int(pari(f"{r_bounds}[2]"))],
                on_curve=on_curve, H=[[float(pari(f"{H}[{i},{j}]")) for j in (1,2)] for i in (1,2)],
                Reg=float(Reg), tors=tors, tam=int(tam), Omega=float(Omega),
                r_an=r_an, Lr1=float(Lr_route1), Lr2=float(Lr_route2),
                Q=float(Q), resid=float(pari(f"abs({Q}-1)")))

for prec in (38, 60):
    m = measure(prec)
    print(f"--- realprecision {prec} ---")
    print(f"conductor N            = {m['N']}")
    print(f"gens on curve          = {m['on_curve']}")
    print(f"algebraic rank bounds  = {m['r_bounds']}  (ellrank lower/upper)")
    print(f"height matrix          = [[{m['H'][0][0]:.15f}, {m['H'][0][1]:.15f}], [{m['H'][1][0]:.15f}, {m['H'][1][1]:.15f}]]")
    print(f"Regulator Reg          = {m['Reg']:.15f}")
    print(f"Omega (real period)    = {m['Omega']:.15f}")
    print(f"Tamagawa product       = {m['tam']}")
    print(f"torsion order          = {m['tors']}")
    print(f"analytic rank r_an     = {m['r_an']}")
    print(f"L''(E,1)/2! route 1    = {m['Lr1']:.15f}   (ellanalyticrank)")
    print(f"L''(E,1)/2! route 2    = {m['Lr2']:.15f}   (lfun derivative)")
    print(f"BSD quotient Q         = {m['Q']:.15f}")
    print(f"|Q - 1| residual       = {m['resid']:.3e}")
    print(f"Delta_rank             = {m['r_an'] - m['r_bounds'][0]}")
