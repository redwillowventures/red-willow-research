# Verification scripts

These scripts recompute, from public inputs, the numbers stated in the
consolidated record "One Property, Two Readings — A Pre-Registered Attempt
to Separate BSD and Riemann" (Red Willow Ventures LLC). Each script checks
finished numbers using standard published machinery (PARI/GP; LMFDB-tabulated
curve data). Nothing in this folder constructs the objects under study;
a reader can verify every figure in the record from this folder and public
data alone.

- `measure_panel.py` — BSD transfer quotient Q for six panel curves
  (rank, regulator, real period, Tamagawa product, torsion) via PARI.
- `measure_389a1.py` — The same quotient for curve 389a1, with
  L''(E,1)/2! computed by two independent PARI routes.
- `panel_run.py` — The panel itself: Column 1, the BSD identity per curve
  cross-checked against LMFDB values; Column 2, on-line zero counts via
  `lfunzeros` with an independent Hardy-Z sign-change scan.
- `li_probe.py` — Li-criterion coefficients lambda_n for the Riemann zeta
  function, by a zero sum and by Cauchy/DFT derivatives, against published
  checkpoint constants.
- `liE_probe.py` — lambda_n(E) for 389a1 by the Bombieri–Lagarias
  definition, two routes, with functional-equation checks.
- `liE_sequence.py` — lambda_n(E) for the 17 panel curves by three
  adjudicating routes; verifies the record's 85 lambda coefficients and
  their positivity.
- `riemann_r1_extension.py` — Segmented-sieve pi(x) and Schoenfeld-envelope
  ratios; reproduces pi(10^9) = 50,847,534 exactly.

## Scope

This deposit contains the verification scripts for the numbers stated in
the record. Other working code — test construction and exploratory
apparatus — exists and is being held pending independent verification of
the record; it will be released after that verification. None of it is
needed to check any number in the record.
