#!/usr/bin/env python
"""
lambda_n(E), n = 1..5, for the 17 curves of the BSD failure-hunt panel,
plus the residual-vs-regulator statistics. Methods pinned BEFORE
computing in liE-sequence-methods.md (read it). Pilot: liE_probe.py /
liE-pilot-results.md (389a1); defect D1's broken sigma^(n-1) form is NOT
used anywhere here.

Per curve, three route-B evaluation paths (pilot's validated stack):
  * derivnum  -- GP-assembled log xi_E, nested PARI derivnum at s = 1,
                 c_k = g^(k)(1)/k!, lambda_n by the (B1) binom formula.
  * B1-GP     -- Cauchy/DFT at s = 1, R = 0.4, M = 512, samples of xi_E
                 assembled ENTIRELY inside GP (pilot's "B1-repaired").
  * B2        -- corrected sigma form lambda_n = n * f_n,
                 F(sigma) = log xi_E(1/(1-sigma)), Cauchy/DFT on
                 |sigma| = 0.5, M = 256, probe sample assembly
                 (mpmath archimedean factor x PARI lfun, 110-digit args).
Headline lambda_n = derivnum value if B2 and B1-GP both agree with it
to <= 1e-8 for all n; else the B2/B1-GP consensus (their mean, if they
agree to <= 1e-8); else B1-GP, with the disagreement in the JSON record
(and in the results file's defect ledger). All three paths recorded.

Decomposition (per curve, per n):
  (a)_n = analytic_rank * (1 - (-1)^n)         [built-in, by construction]
  A_n   = archimedean term, closed form (polygamma at 3/2; conductor
          enters only a_1 = (ln N)/2 - ln(2pi) + psi(3/2))
  R_n   = lambda_n(headline) - (a)_n - A_n     [test observable]

Route-A spot checks (methods sec. 5) on 571.b1 (rank 0), 37.a1 (rank 1),
5077.a1 (rank 3): lfunzeros to T = 300, partials at 100/300, tail
estimate with the curve's own conductor in the smooth RvM density.

Driver mode: runs the 389a1 REGRESSION CHECKPOINT first (must match the
pilot headline to <= 1e-9 per n; aborts otherwise), then every curve as
a subprocess (--curve LABEL), then the pre-registered statistics.
Output: liE_sequence_output.json (+ per-curve liE_seq_<label>.json).
"""

import json
import os
import re
import subprocess
import sys
import time
from math import factorial

HERE = os.path.dirname(os.path.abspath(__file__))
NMAX = 5
PILOT_389 = [4.40227074120749249379, 1.59043606127028778101,
             7.51034676045006699509, 6.07752861062463609674,
             13.18517619431236255095]
CHECKPOINT_TOL = 1e-9
AGREE_TOL = 1e-8
SPOT = {"571.b1": 300, "37.a1": 300, "5077.a1": 300}  # label -> T

# label, ainvs, conductor, panel analytic rank, regulator (LMFDB tab.;
# rank 0 -> 1 by convention), period, Tamagawa product, torsion, Sha tab.
CURVES = [
    ("11.a2",       [0, -1, 1, -10, -20],        11,       0, 1.0,
     1.2692093042795534, 5, 5, 1),
    ("37.a1",       [0, 0, 1, -1, 0],            37,       1, 0.05111140823996884,
     5.986917292463919, 1, 1, 1),
    ("389.a1",      [0, 1, 1, -2, 0],            389,      2, 0.152460177943144,
     4.98042512171011, 1, 1, 1),
    ("5077.a1",     [0, 0, 1, -7, 6],            5077,     3, 0.417143558758384,
     4.151687983086933, 1, 1, 1),
    ("571.b1",      [0, -1, 1, -929, -10595],    571,      0, 1.0,
     0.432341256271861, 1, 1, 4),
    ("571.a1",      [0, 1, 1, -4, 2],            571,      2, 0.177253140262005,
     5.095314619739131, 1, 1, 1),
    ("12480.bf1",   [0, -1, 0, 38875, 1928445],  12480,    0, 1.0,
     0.2776114680289072, 1, 1, 9),
    ("133584.bt1",  [0, -1, 0, -36824, -3515664], 133584,  0, 1.0,
     0.1690215245576774, 2, 1, 9),
    ("234446.a1",   [1, -1, 0, -79, 289],        234446,   4, 1.504344888275284,
     2.9726718472633355, 2, 1, 1),
    ("234446.b1",   [1, 1, 0, -696, 6784],       234446,   3, 2.159011019974552,
     2.2808923095622077, 2, 1, 1),
    ("234446.c1",   [1, 1, 1, -949, -7845],      234446,   3, 1.211626824727663,
     0.8824185921743611, 18, 1, 1),
    ("19047851.a1", [0, 0, 1, -79, 342],         19047851, 5, 14.790527570131128,
     2.0476407897055164, 1, 1, 1),
    ("19047851.b1", [1, 1, 1, -244, -1584],      19047851, 2, 16.924145001099767,
     0.6035402706258764, 1, 1, 1),
    ("57.a1",       [0, -1, 1, -2, 2],           57,       1, 0.037574592736824,
     5.555504521372504, 2, 1, 1),
    ("44.a1",       [0, 1, 0, -77, -289],        44,       0, 1.0,
     0.8046462875746519, 1, 1, 1),
    ("12144.a1",    [0, -1, 0, -1380, -19044],   12144,    0, 1.0,
     0.783904990578769, 4, 2, 1),
    ("697691.a1",   [0, -1, 1, -7117, 233485],   697691,   2, 1.179562268249869,
     2.04902719259762, 1, 1, 4),
]
BY_LABEL = {c[0]: c for c in CURVES}


# ---------------------------------------------------------------------------
# parsing helpers (same conventions as liE_probe.py)
# ---------------------------------------------------------------------------
def _mpf_pari(tok):
    from mpmath import mpf
    tok = tok.strip().replace(".E", ".0E").replace(".e", ".0e")
    if tok.endswith("."):
        tok += "0"
    return mpf(tok)


def parse_pari_complex(txt):
    from mpmath import mpc
    txt = txt.strip()
    m = re.match(r"^\s*(.+?)\s+([+-])\s+(.+?)\*I\s*$", txt)
    if m:
        return mpc(_mpf_pari(m.group(1)),
                   _mpf_pari(m.group(3)) * (1 if m.group(2) == "+" else -1))
    return mpc(_mpf_pari(txt), 0)


def coeffs_from_values(vals, R, kmax):
    """Taylor coeffs of log f about the sample circle's center from values
    of f on the circle (phase-unwrapped log + DFT), as in liE_probe."""
    from mpmath import mp, mpf, mpc, pi, log, exp
    logs = []
    prev = None
    acc = mpf(0)
    M = len(vals)
    for val in vals:
        if prev is None:
            lv = log(val)
        else:
            lv = acc + log(val / prev)
        logs.append(lv)
        acc = lv
        prev = val
    winding = (acc + log(vals[0] / prev) - logs[0]) / (2 * pi)
    coeffs = []
    for k in range(kmax + 1):
        tot = mpc(0)
        for j in range(M):
            theta = 2 * pi * j / M
            tot += logs[j] * exp(mpc(0, -k * theta))
        coeffs.append(tot / M / R ** k)
    return coeffs, winding


def lam_from_coeffs(coeffs, nmax):
    from mpmath import mpf, binomial
    lam = [None] * (nmax + 1)
    for n in range(1, nmax + 1):
        s_ = mpf(0)
        for k in range(1, n + 1):
            s_ += binomial(n - 1, n - k) * coeffs[k]
        lam[n] = n * s_
    return lam


# ---------------------------------------------------------------------------
# per-curve worker
# ---------------------------------------------------------------------------
def compute_curve(label):
    from cypari2 import Pari
    from mpmath import mp, mpf, mpc, pi, log, polygamma, nstr
    import liE_probe as probe

    _, ainvs, N, rank_panel, reg, period, tam, tors, sha = BY_LABEL[label]
    rec = {"label": label, "ainvs": ainvs, "conductor_panel": N,
           "rank_panel": rank_panel, "regulator": reg, "period": period,
           "tamagawa_product": tam, "torsion_order": tors, "sha_tab": sha}
    ainvs_s = "[" + ",".join(str(a) for a in ainvs) + "]"

    pari = Pari()
    pari.allocatemem(2 ** 30)  # nested derivnum at large N overflows the
    # default 8 MB PARI stack (found in pre-run timing tests, methods
    # amendment A1); 1 GB after the first run's worker was OOM-killed
    # on a nearly full, swapless machine (defect ledger D3)
    deriv_rp = 38 if N > 10 ** 6 else 60  # methods amendment A1
    rec["derivnum_realprecision"] = deriv_rp
    pari.set_real_precision(60)
    pari(f"myE = ellinit({ainvs_s})")
    pari(f"myN = {N}")
    pari("myXi = (z) -> myN^((z+1/2)/2) * (2*Pi)^(-(z+1/2)) "
         "* gamma(z+1/2) * lfun(myE, z+1/2)")
    pari("myg = (s) -> log(myXi(s))")
    pari("d1 = (s) -> derivnum(u=s, myg(u))")
    pari("d2 = (s) -> derivnum(u=s, d1(u))")
    pari("d3 = (s) -> derivnum(u=s, d2(u))")
    pari("d4 = (s) -> derivnum(u=s, d3(u))")

    # verification artifacts
    rec["conductor_gp"] = int(pari("ellglobalred(myE)[1]"))
    rec["root_number"] = int(pari("ellrootno(myE)"))
    try:
        rec["analytic_rank_gp"] = int(pari("ellanalyticrank(myE)[1]"))
    except Exception as e:  # recorded, not hidden
        rec["analytic_rank_gp"] = None
        rec["analytic_rank_gp_error"] = str(e)[:200]

    # ---- derivnum path -----------------------------------------------------
    pari.set_real_precision(deriv_rp)
    t0 = time.time()
    gexpr = ["derivnum(s=1, myg(s))", "derivnum(s=1, d1(s))",
             "derivnum(s=1, d2(s))", "derivnum(s=1, d3(s))",
             "derivnum(s=1, d4(s))"]
    gder = [None] + [_mpf_pari(str(pari(e))) for e in gexpr]
    mp.dps = 100
    c_der = [mpf(0)] + [gder[k] / factorial(k) for k in range(1, NMAX + 1)]
    lam_der = lam_from_coeffs(c_der, NMAX)
    rec["derivnum_seconds"] = round(time.time() - t0, 2)
    rec["lambda_derivnum"] = [nstr(mp.re(lam_der[n]), 25)
                              for n in range(1, NMAX + 1)]

    # ---- B1-GP path ----------------------------------------------------------
    pari.set_real_precision(60)
    t0 = time.time()
    M1 = 512
    v = pari(f"vector({M1}, j, myXi(1 + 0.4*exp(2*Pi*I*(j-1)/{M1})))")
    vals = [parse_pari_complex(str(v[j])) for j in range(M1)]
    coeffs1, wind1 = coeffs_from_values(vals, mpf("0.4"), NMAX + 15)
    lam_b1 = lam_from_coeffs(coeffs1, NMAX)
    rec["b1gp_seconds"] = round(time.time() - t0, 2)
    rec["b1gp_winding"] = nstr(wind1, 3)
    rec["lambda_b1gp"] = [nstr(mp.re(lam_b1[n]), 25)
                          for n in range(1, NMAX + 1)]

    # ---- B2 path (probe assembly, corrected sigma form) ----------------------
    t0 = time.time()
    probe.pari.allocatemem(2 ** 30)
    probe.pari.set_real_precision(60)
    probe.E = probe.pari(f"ellinit({ainvs_s})")
    probe.COND = N

    def F_of_sigma(sig):
        return probe.xi_E(1 / (1 - sig))

    coeffsF, windF = probe.cauchy_coeffs(F_of_sigma, mpf(0), mpf("0.5"),
                                         256, NMAX + 3)
    lam_b2 = [None] + [n * mp.re(coeffsF[n]) for n in range(1, NMAX + 1)]
    rec["b2_seconds"] = round(time.time() - t0, 2)
    rec["b2_winding"] = nstr(windF, 3)
    rec["lambda_b2"] = [nstr(lam_b2[n], 25) for n in range(1, NMAX + 1)]

    # ---- headline selection (methods sec. 3, as completed by amendment A2) ----
    lam_d = [mp.re(lam_der[n]) for n in range(1, NMAX + 1)]
    lam_1 = [mp.re(lam_b1[n]) for n in range(1, NMAX + 1)]
    lam_2 = [mp.re(lam_b2[n]) for n in range(1, NMAX + 1)]
    dev_d2 = max(abs(a - b) for a, b in zip(lam_d, lam_2))
    dev_d1 = max(abs(a - b) for a, b in zip(lam_d, lam_1))
    dev_21 = max(abs(a - b) for a, b in zip(lam_2, lam_1))
    rec["max_dev_b2_vs_derivnum"] = nstr(dev_d2, 4)
    rec["max_dev_b1gp_vs_derivnum"] = nstr(dev_d1, 4)
    rec["max_dev_b2_vs_b1gp"] = nstr(dev_21, 4)
    tol = mpf("1e-8")
    if dev_d2 <= tol:
        head = lam_d
        rec["headline_source"] = "derivnum (corroborated by B2)"
    elif dev_d1 <= tol:
        head = lam_d
        rec["headline_source"] = "derivnum (corroborated by B1-GP)"
    elif dev_21 <= tol:
        head = [(a + b) / 2 for a, b in zip(lam_2, lam_1)]
        rec["headline_source"] = "B2/B1-GP consensus (derivnum outlier)"
    else:
        pairs = [(dev_d2, lam_d, lam_2, "derivnum/B2"),
                 (dev_d1, lam_d, lam_1, "derivnum/B1-GP"),
                 (dev_21, lam_2, lam_1, "B2/B1-GP")]
        pairs.sort(key=lambda t: t[0])
        _, pa, pb, pname = pairs[0]
        head = [(a + b) / 2 for a, b in zip(pa, pb)]
        rec["headline_source"] = (f"closest-pair mean ({pname}); "
                                  "three-way disagreement, see ledger")
    rec["lambda_headline"] = [nstr(x, 25) for x in head]
    head_f = [float(x) for x in head]

    # ---- decomposition ---------------------------------------------------------
    acoef = [None] * (NMAX + 16)
    acoef[1] = log(mpf(N)) / 2 - log(2 * pi) + polygamma(0, mpf(3) / 2)
    for k in range(2, NMAX + 16):
        acoef[k] = polygamma(k - 1, mpf(3) / 2) / factorial(k)
    lam_arch = lam_from_coeffs([mpf(0)] + [mp.re(x) for x in acoef[1:]], NMAX)
    rec["archimedean_A"] = [float(mp.re(lam_arch[n])) for n in range(1, NMAX + 1)]
    rec["central_a"] = [rank_panel * (1 - (-1) ** n) for n in range(1, NMAX + 1)]
    rec["residual_R"] = [head_f[n - 1] - rec["central_a"][n - 1]
                         - rec["archimedean_A"][n - 1]
                         for n in range(1, NMAX + 1)]

    # ---- route-A spot check ------------------------------------------------------
    if label in SPOT:
        T = SPOT[label]
        pari.set_real_precision(50)
        t0 = time.time()
        z = pari(f"lfunzeros(myE, {T})")
        gammas = [mpf(str(z[i])) for i in range(len(z))]
        rec["routeA_seconds"] = round(time.time() - t0, 2)
        mp.dps = 80
        from mpmath import quad, arg, cos
        counts = {H: sum(1 for g in gammas if g <= H) for H in (100, T)}
        partials = {}
        running = [mpf(0)] * (NMAX + 1)
        central = 0
        for gi, g in enumerate(gammas, start=1):
            if g < mpf("1e-30"):
                central += 1
                for n in range(1, NMAX + 1):
                    running[n] += 1 - (-1) ** n
            else:
                rho = mpc(mpf(1) / 2, g)
                w = 1 - 1 / rho
                wpow = mpc(1)
                for n in range(1, NMAX + 1):
                    wpow *= w
                    running[n] += 2 * (1 - wpow).real
            for H in (100, T):
                if gi == counts[H]:
                    partials[H] = running[:]
        partials[T] = running[:]

        def tail_est(n):
            def integrand(t):
                rho = mpc(mpf(1) / 2, t)
                theta = arg(1 - 1 / rho)
                dens = log(mpf(N) ** mpf("0.5") * t / (2 * pi)) / pi
                return dens * 2 * (1 - cos(n * theta))
            return quad(integrand, [T, mp.inf])

        mp.dps = 50
        tails = [float(tail_est(n)) for n in range(1, NMAX + 1)]
        pT = [float(partials[T][n]) for n in range(1, NMAX + 1)]
        p100 = [float(partials[100][n]) for n in range(1, NMAX + 1)]
        rec["routeA"] = {
            "T": T, "zero_count": len(gammas), "central_count": central,
            "partial_100": p100, "partial_T": pT, "tail_estimates": tails,
            "gap_vs_headline": [head_f[n - 1] - pT[n - 1] for n in range(1, NMAX + 1)],
            "scale": [tails[n - 1] + (pT[n - 1] - p100[n - 1])
                      for n in range(1, NMAX + 1)],
        }
        rec["routeA"]["within_scale"] = [
            0 <= rec["routeA"]["gap_vs_headline"][n - 1]
            <= rec["routeA"]["scale"][n - 1] for n in range(1, NMAX + 1)]

    out = os.path.join(HERE, f"liE_seq_{label}.json")
    with open(out, "w") as f:
        json.dump(rec, f, indent=1)
    print(f"{label}: headline={['%.12f' % x for x in head_f]} "
          f"src={rec['headline_source']} devs: b2={rec['max_dev_b2_vs_derivnum']} "
          f"b1={rec['max_dev_b1gp_vs_derivnum']}")
    return rec


# ---------------------------------------------------------------------------
# statistics (pre-registered, methods sec. 6)
# ---------------------------------------------------------------------------
def midranks(xs):
    order = sorted(range(len(xs)), key=lambda i: xs[i])
    ranks = [0.0] * len(xs)
    i = 0
    while i < len(xs):
        j = i
        while j + 1 < len(xs) and xs[order[j + 1]] == xs[order[i]]:
            j += 1
        avg = (i + j) / 2.0 + 1.0
        for k in range(i, j + 1):
            ranks[order[k]] = avg
        i = j + 1
    return ranks


def spearman(xs, ys):
    rx, ry = midranks(xs), midranks(ys)
    n = len(xs)
    mx = sum(rx) / n
    my = sum(ry) / n
    num = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    den = (sum((a - mx) ** 2 for a in rx) * sum((b - my) ** 2 for b in ry)) ** 0.5
    return num / den if den > 0 else 0.0


def perm_p(xs, ys, rho_obs, perms=10000, seed=20261101):
    import random
    rng = random.Random(seed)
    ys = list(ys)
    cnt = 0
    for _ in range(perms):
        rng.shuffle(ys)
        if abs(spearman(xs, ys)) >= abs(rho_obs) - 1e-15:
            cnt += 1
    return (cnt + 1) / (perms + 1)


def run_stats(records):
    from math import log as flog
    labels = [r["label"] for r in records]
    logreg = [flog(r["regulator"]) for r in records]
    ranks = [r["rank_panel"] for r in records]
    logN = [flog(r["conductor_panel"]) for r in records]
    idx_all = list(range(len(records)))
    idx_ge1 = [i for i in idx_all if records[i]["rank_panel"] >= 1]
    stats = {}
    for n in range(1, NMAX + 1):
        Rn = [r["residual_R"][n - 1] for r in records]
        d = {}
        d["rho_R_logreg_all17"] = spearman([Rn[i] for i in idx_all],
                                           [logreg[i] for i in idx_all])
        d["p_R_logreg_all17"] = perm_p([Rn[i] for i in idx_all],
                                       [logreg[i] for i in idx_all],
                                       d["rho_R_logreg_all17"])
        d["rho_R_logreg_rankge1"] = spearman([Rn[i] for i in idx_ge1],
                                             [logreg[i] for i in idx_ge1])
        d["p_R_logreg_rankge1"] = perm_p([Rn[i] for i in idx_ge1],
                                         [logreg[i] for i in idx_ge1],
                                         d["rho_R_logreg_rankge1"])
        d["rho_R_rank_all17"] = spearman([Rn[i] for i in idx_all],
                                         [ranks[i] for i in idx_all])
        d["rho_R_rank_rankge1"] = spearman([Rn[i] for i in idx_ge1],
                                           [ranks[i] for i in idx_ge1])
        d["rho_R_logN_all17"] = spearman([Rn[i] for i in idx_all],
                                         [logN[i] for i in idx_all])
        # Companion observable (methods note sec. 2, corrected gloss):
        # (c)_n = lambda_n - (a)_n = R_n + A_n, the off-center-zero
        # content in the zero-sum frame (the pilot's (c) column).
        Cn = [r["residual_R"][n - 1] + r["archimedean_A"][n - 1]
              for r in records]
        d["rho_c_logreg_all17"] = spearman([Cn[i] for i in idx_all],
                                           [logreg[i] for i in idx_all])
        d["rho_c_logreg_rankge1"] = spearman([Cn[i] for i in idx_ge1],
                                             [logreg[i] for i in idx_ge1])
        d["rho_c_rank_all17"] = spearman([Cn[i] for i in idx_all],
                                         [ranks[i] for i in idx_all])
        stats[f"n={n}"] = d
        print(f"n={n}: rho(R,logreg) all17={d['rho_R_logreg_all17']:+.3f} "
              f"(p~{d['p_R_logreg_all17']:.3f})  rank>=1="
              f"{d['rho_R_logreg_rankge1']:+.3f} (p~{d['p_R_logreg_rankge1']:.3f})  "
              f"ctrl rank all17={d['rho_R_rank_all17']:+.3f} "
              f"rank>=1={d['rho_R_rank_rankge1']:+.3f}  "
              f"logN={d['rho_R_logN_all17']:+.3f}")
    return {"labels": labels, "stats": stats}


# ---------------------------------------------------------------------------
def load_or_run(label, timeout=7200):
    """Resume support (defect D3): a curve whose per-curve JSON already
    exists is loaded, not recomputed."""
    path = os.path.join(HERE, f"liE_seq_{label}.json")
    if os.path.exists(path):
        with open(path) as f:
            rec = json.load(f)
        print(f"{label}: loaded from existing {os.path.basename(path)}")
        return rec, True
    r = subprocess.run([sys.executable, os.path.abspath(__file__),
                        "--curve", label],
                       capture_output=True, text=True, timeout=timeout)
    if r.returncode != 0:
        print(f"WORKER FAILED for {label}:\n", r.stderr[-3000:])
        return None, False
    print(r.stdout.strip())
    with open(path) as f:
        return json.load(f), False


def main():
    if len(sys.argv) == 3 and sys.argv[1] == "--curve":
        compute_curve(sys.argv[2])
        return
    t0 = time.time()
    # regression checkpoint first (computed fresh, or verified from the
    # stored record on a resumed run)
    rec389, _ = load_or_run("389.a1", timeout=3600)
    if rec389 is None:
        sys.exit(1)
    diffs = [abs(float(rec389["lambda_headline"][n]) - PILOT_389[n])
             for n in range(NMAX)]
    print(f"checkpoint diffs vs pilot: {['%.2e' % d for d in diffs]}")
    if max(diffs) > CHECKPOINT_TOL:
        print("REGRESSION CHECKPOINT FAILED -- sequence aborted before "
              "any other curve was computed.")
        with open(os.path.join(HERE, "liE_sequence_output.json"), "w") as f:
            json.dump({"checkpoint_pass": False,
                       "checkpoint_diffs": diffs,
                       "record_389": rec389}, f, indent=1)
        sys.exit(2)
    print("REGRESSION CHECKPOINT: PASS")

    records = [rec389]
    for label, *_ in CURVES:
        if label == "389.a1":
            continue
        t1 = time.time()
        rec, was_loaded = load_or_run(label)
        if rec is None:
            with open(os.path.join(HERE, "liE_sequence_output.json"), "w") as f:
                json.dump({"checkpoint_pass": True,
                           "failed_curve": label,
                           "records": records}, f, indent=1)
            sys.exit(1)
        if not was_loaded:
            print(f"[{time.time()-t1:.0f}s] {label} done")
        records.append(rec)

    order = {c[0]: i for i, c in enumerate(CURVES)}
    records.sort(key=lambda r: order[r["label"]])
    stats = run_stats(records)
    with open(os.path.join(HERE, "liE_sequence_output.json"), "w") as f:
        json.dump({"checkpoint_pass": True, "checkpoint_diffs": diffs,
                   "records": records, "statistics": stats}, f, indent=1)
    print(f"\nDONE in {time.time()-t0:.0f}s -> liE_sequence_output.json")


if __name__ == "__main__":
    main()
