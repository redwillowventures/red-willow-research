# Panel measurement: BSD transfer quotient across ranks 0,1,2,3 + a nontrivial-Sha curve.
# Same instrument as Step 1 (measure_389a1.py): two routes for L^(r)(1)/r!, own height matrices.
# Q = (L^(r)/r!) * |tors|^2 / (Reg * Omega * prod c_p)  == analytic |Sha|.
from cypari2 import Pari
import math
pari = Pari()
pari("default(realprecision,50)")

CURVES = [
    ("11a1",   [0,-1,1,-10,-20],      []),
    ("37a1",   [0,0,1,-1,0],          [[0,0]]),
    ("389a1",  [0,1,1,-2,0],          [[0,0],[1,0]]),
    ("571a1*", [0,-1,1,-929,-10595],  []),          # Cremona 571a1 = LMFDB 571.b1, rank 0, Sha_an = 4
    ("571b1",  [0,1,1,-4,2],          [[1,0],[0,1]]),
    ("5077a1", [0,0,1,-7,6],          [[1,0],[2,0],[0,2]]),
]

def measure(label, ainvs, gens):
    E = pari(f"ellinit({ainvs})")
    gr = pari(f"ellglobalred({E})")
    N = int(pari(f"{gr}[1]"))
    tam = int(pari(f"prod(i=1,matsize({gr}[5])[1], {gr}[5][i][4])"))
    tors = int(pari(f"elltors({E})[1]"))
    rb = pari(f"ellrank({E})")
    r_lo, r_hi = int(pari(f"{rb}[1]")), int(pari(f"{rb}[2]"))
    if gens:
        G = pari(str(gens).replace(" ", ""))
        Reg = float(pari(f"matdet(ellheightmatrix({E},{G}))"))
    else:
        Reg = 1.0
    Omega = float(pari(f"if({E}.disc>0,2,1)*{E}.omega[1]"))
    ar = pari(f"ellanalyticrank({E})")
    r_an = int(pari(f"{ar}[1]"))
    Lr1 = float(pari(f"({ar}[2])/{r_an}!"))
    Lr2 = float(pari(f"lfun({E},1,{r_an})/{r_an}!"))
    Q = Lr1 * tors**2 / (Reg * Omega * tam)
    return dict(label=label, N=N, r_lo=r_lo, r_hi=r_hi, r_an=r_an, Reg=Reg, Omega=Omega,
                tam=tam, tors=tors, Lr1=Lr1, Lr2=Lr2, Q=Q,
                Q_nearest=round(Q), Q_resid=abs(Q-round(Q)), drank=r_an-r_lo)

print(f"{'curve':8} {'N':>6} {'r_alg':>5} {'r_an':>4} {'Reg':>12} {'Omega':>10} {'tam':>3} {'tor':>3} {'L^(r)/r!':>14} {'routes agree':>12} {'Q (=Sha_an)':>16} {'|Q-round|':>10}")
for label, ainvs, gens in CURVES:
    m = measure(label, ainvs, gens)
    agree = abs(m['Lr1']-m['Lr2'])
    print(f"{m['label']:8} {m['N']:>6} {m['r_lo']:>5} {m['r_an']:>4} {m['Reg']:>12.9f} {m['Omega']:>10.6f} {m['tam']:>3} {m['tors']:>3} {m['Lr1']:>14.9f} {agree:>12.2e} {m['Q']:>16.12f} {m['Q_resid']:>10.2e}  Drank={m['drank']}")
