#!/usr/bin/env python
"""
Li positivity probe -- one narrow slice.

Li's criterion: RH holds iff lambda_n >= 0 for ALL n >= 1, where

    lambda_n = sum_rho [ 1 - (1 - 1/rho)^n ]            (sum over nontrivial zeros,
                                                          paired rho / conjugate-rho)
             = (1/(n-1)!) * d^n/ds^n [ s^(n-1) log xi(s) ] at s = 1,

    xi(s) = (1/2) s (s-1) pi^(-s/2) Gamma(s/2) zeta(s).

This probe computes lambda_n, n = 1..30, by TWO INDEPENDENT ROUTES, plus an
independent-stack adjudication (PARI/GP derivnum) for n <= 10:

  Route 1 (zero sum):  zeros of zeta on the critical line from PARI lfunzeros
      (realprecision 50), summed in conjugate pairs with mpmath at 80 dps.
      Partial sums are reported at cutoffs K = 250, 500, 1000 and at the full
      Kmax, so the truncation drift is visible per n. The remaining tail after
      the top zero is estimated with the smooth zero density (Riemann-von
      Mangoldt) against the exact paired summand -- for n = 1 the paired term
      is exactly 1/(1/4+gamma^2), for n = 2 exactly 4 gamma^2/(gamma^2+1/4)^2.
      Nothing is extrapolated into the reported values or dropped.

  Route 2 (derivatives at s = 1):  Taylor coefficients c_k of log xi(s) about
      s = 1 are extracted by a Cauchy integral on the circle |s-1| = 4
      (1024-point trapezoid / DFT, phase-unwrapped log, mpmath at 100 dps).
      log xi is analytic and zero-free in that disk (nearest singularity of
      log xi is the first zero, at distance ~14.14 from s = 1), so the
      trapezoid rule is spectrally accurate. Then, with u = s - 1,

          lambda_n = n * [u^n] ( (1+u)^(n-1) * sum_k c_k u^k )
                   = n * sum_{k=1..n} binom(n-1, n-k) c_k.

      Internal cross-check: c_1..c_3 also by mpmath.diff on the regularized
      (s-1) zeta(s) = 1 + (s-1)(zeta(s) - 1/(s-1)) form.

  Adjudication: PARI/GP derivnum (a separate software stack with its own
      zeta/gamma) evaluates the same derivative definition for n = 1..10,
      using the regularized xi form (the raw product is 0 * pole at s = 1,
      which the even-order stencils sample).

CHECKPOINT (must pass before the table means anything):
  lambda_1 = 0.02309570896612103381...  (= sum_rho 1/rho = 1 + gamma_E/2 - ln(4 pi)/2)
  lambda_2 = 0.092345735188332...       (constant as supplied in the brief)
Both routes must reproduce these to >= 8 correct decimals
(route 1: within its stated truncation drift).

  *** CHECKPOINT FINDING (this run): the brief's lambda_2 constant is itself
  defective. Route 2, the mpmath power-sum identities (lambda_2 = 2 lambda_1
  - sum_rho rho^-2, sum_rho rho^-2 = -g''(1) = -2 c_2), and PARI/GP derivnum
  -- three independent computations from the brief's own definitions -- agree
  that lambda_2 = 0.092345735228046670..., differing from the supplied
  constant by 3.97e-11. lambda_1's supplied constant is confirmed exact.
  The probe therefore passes the lambda_2 checkpoint against the corrected
  constant (agreement ~1e-25) and flags the supplied one. See li_results.md.

PROTOCOL: any lambda_n < 0 is presumed a defect of this probe until BOTH
routes independently agree on the negative value beyond their error scales.
Drop/round rule: drift- or conditioning-dominated digits are flagged, never
silently dropped or rounded.

Scope: finite-n corroboration only. The criterion quantifies over all n;
no finite table proves RH.
"""

import json
import os
import time
from math import factorial

from cypari2 import Pari
from mpmath import (mp, mpf, mpc, pi, gamma, zeta, log, exp,
                    binomial, nstr, diff)

HERE = os.path.dirname(os.path.abspath(__file__))
ZERO_CACHE = os.path.join(HERE, "li_zeros_cache.json")
OUT_JSON = os.path.join(HERE, "li_probe_output.json")

NMAX = 30
CUTOFFS = (250, 500, 1000)
ZERO_HEIGHT = 1450          # yields 1026 zeros (> 1000 pairs required)
BRIEF_KNOWN = {1: mpf("0.02309570896612103381"),
               2: mpf("0.092345735188332")}


# --------------------------------------------------------------------------
# Zeros (input for route 1 only; route 2 never touches zero locations)
# --------------------------------------------------------------------------
def get_zeros():
    if os.path.exists(ZERO_CACHE):
        with open(ZERO_CACHE) as f:
            return [mpf(s) for s in json.load(f)]
    pari = Pari()
    pari.set_real_precision(50)
    z = pari("lfunzeros(1, %d)" % ZERO_HEIGHT)
    strs = [str(z[i]) for i in range(len(z))]
    with open(ZERO_CACHE, "w") as f:
        json.dump(strs, f)
    return [mpf(s) for s in strs]


# --------------------------------------------------------------------------
# Route 1 -- zero sum
# --------------------------------------------------------------------------
def route1(gammas):
    """lambda_n^(K) for K in CUTOFFS + (Kmax,), n = 1..NMAX."""
    kmax = len(gammas)
    marks = sorted(set(CUTOFFS + (kmax,)))
    table = {K: [mpf(0)] * (NMAX + 1) for K in marks}
    running = [mpf(0)] * (NMAX + 1)
    half = mpf(1) / 2
    for idx, g in enumerate(gammas, start=1):
        rho = mpc(half, g)
        w = 1 - 1 / rho                 # base of the power
        wpow = mpc(1)
        for n in range(1, NMAX + 1):
            wpow *= w                   # w^n, iterated (no pow() calls)
            running[n] += 2 * (1 - wpow).real   # conjugate pair -> real
        if idx in marks:
            table[idx] = running[:]
    return table, marks


def tail_estimate(n, T):
    """Smooth-density estimate of the route-1 tail beyond height T, for n=1,2.
    tail = int_T^inf (1/2pi) ln(t/2pi) * pairterm_n(t) dt with the exact
    large-t paired summands 1/(1/4+t^2) (n=1) and 4t^2/(t^2+1/4)^2 (n=2);
    both integrate to coeff * (ln(T/2pi)+1)/T / (2pi) to leading order."""
    base = (log(T / (2 * pi)) + 1) / (2 * pi * T)
    return base if n == 1 else 4 * base


# --------------------------------------------------------------------------
# Route 2 -- derivatives of log xi at s = 1 via Cauchy/DFT
# --------------------------------------------------------------------------
def xi(s):
    return (mpf(1) / 2) * s * (s - 1) * pi ** (-s / 2) * gamma(s / 2) * zeta(s)


def route2(nmax):
    """Return (lambda list, c_k list, diagnostics dict). Caller sets mp.dps=100."""
    R = mpf(4)
    M = 1024
    KMAXC = nmax + 15
    logs = []
    prev_val = None
    acc = mpf(0)
    for j in range(M):
        theta = 2 * pi * j / M
        s = 1 + R * exp(mpc(0, theta))
        val = xi(s)
        if prev_val is None:
            lv = log(val)               # s = 5: xi > 0 real, principal log is the branch
        else:
            lv = acc + log(val / prev_val)   # small step -> principal log of ratio is safe
        logs.append(lv)
        acc = lv
        prev_val = val
    coeffs = []
    for k in range(KMAXC + 1):
        tot = mpc(0)
        for j in range(M):
            theta = 2 * pi * j / M
            tot += logs[j] * exp(mpc(0, -k * theta))
        coeffs.append(tot / M / R ** k)
    lam = [None] * (nmax + 1)
    for n in range(1, nmax + 1):
        s_ = mpf(0)
        for k in range(1, n + 1):
            s_ += binomial(n - 1, n - k) * coeffs[k]
        lam[n] = n * s_
    diag = {
        "c0": coeffs[0],
        "c0_expected": -log(2),
        "max_imag_c": max(abs(mp.im(c)) for c in coeffs[:nmax + 1]),
        "max_imag_lambda": max(abs(mp.im(lam[n])) for n in range(1, nmax + 1)),
    }
    return lam, coeffs, diag


def logxi_reg(s):
    """log xi(s) in the regularized form, safe at s = 1 (for mpmath.diff)."""
    if s == 1:
        G = mpf(1)
    else:
        G = 1 + (s - 1) * (zeta(s) - 1 / (s - 1))
    return log((mpf(1) / 2) * s * G * pi ** (-s / 2) * gamma(s / 2))


# --------------------------------------------------------------------------
# Adjudication -- PARI/GP derivnum, independent stack
# --------------------------------------------------------------------------
def pari_derivnum(nmax):
    pari = Pari()
    pari.set_real_precision(100)
    pari("G(s) = if(s==1, 1, 1 + (s-1)*(zeta(s) - 1/(s-1)))")
    pari("xi(s) = (1/2)*s*G(s)*Pi^(-s/2)*gamma(s/2)")
    out = {}
    for n in range(1, nmax + 1):
        pari(f"H{sfx(n)}(s) = s^{n-1}*log(xi(s))")
        val = pari(f"derivnum(s=1, H{sfx(n)}(s), {n})") / factorial(n - 1)
        out[n] = str(val)
    return out


def sfx(n):
    return str(n)


# --------------------------------------------------------------------------
def main():
    t0 = time.time()
    report = {}

    gammas = get_zeros()
    kmax = len(gammas)
    T = gammas[-1]
    report["zeros"] = {"count": kmax, "top_height": nstr(T, 12),
                       "height_requested": ZERO_HEIGHT}
    print(f"zeros: {kmax} pairs, top gamma = {nstr(T, 12)}")

    # ---- route 1 ---------------------------------------------------------
    mp.dps = 80
    t1 = time.time()
    r1_table, marks = route1(gammas)
    report["route1_seconds"] = round(time.time() - t1, 2)
    print(f"route 1 done in {report['route1_seconds']}s; cutoffs {marks}")

    # ---- route 2 ---------------------------------------------------------
    mp.dps = 100
    t2 = time.time()
    lam2_c, coeffs, diag = route2(NMAX)
    report["route2_seconds"] = round(time.time() - t2, 2)
    lam2 = [None] + [mp.re(lam2_c[n]) for n in range(1, NMAX + 1)]
    print(f"route 2 done in {report['route2_seconds']}s")
    print(f"  c0 = {nstr(diag['c0'], 25)}   expected -ln2 = {nstr(diag['c0_expected'], 25)}")
    print(f"  max |Im c_k| (k<=30) = {nstr(diag['max_imag_c'], 3)}, "
          f"max |Im lambda_n| = {nstr(diag['max_imag_lambda'], 3)}")
    report["route2_diag"] = {
        "c0_err": nstr(abs(diag["c0"] - diag["c0_expected"]), 3),
        "max_imag_c": nstr(diag["max_imag_c"], 3),
        "max_imag_lambda": nstr(diag["max_imag_lambda"], 3),
    }

    # internal route-2 cross-check: c_1..c_3 by mpmath.diff (regularized form)
    mp.dps = 80
    diffcheck = {}
    for k in (1, 2, 3):
        d = diff(logxi_reg, mpf(1), k) / mp.factorial(k)
        diffcheck[k] = {"cauchy": nstr(coeffs[k], 20), "diff": nstr(d, 20),
                        "absdiff": nstr(abs(coeffs[k] - d), 3)}
    report["route2_c_coeff_diffcheck"] = diffcheck
    mp.dps = 100

    # Hadamard power-sum identity check for lambda_2 (independent algebra):
    # lambda_2 = 2*lambda_1 - sum_rho rho^-2 and sum_rho rho^-2 = -g''(1) = -2 c_2.
    lam2_powersum = 2 * lam2[1] + 2 * mp.re(coeffs[2])
    report["lambda2_powersum_identity"] = nstr(lam2_powersum, 25)

    # ---- adjudication: PARI derivnum -------------------------------------
    t3 = time.time()
    pari_vals = pari_derivnum(10)
    report["pari_derivnum_seconds"] = round(time.time() - t3, 2)
    pari_agree = {}
    for n in range(1, 11):
        pv = mpf(pari_vals[n])
        pari_agree[n] = {"pari": pari_vals[n], "route2": nstr(lam2[n], 25),
                         "absdiff": nstr(abs(pv - lam2[n]), 3)}
    report["pari_adjudication"] = pari_agree
    for n in (1, 2, 3, 4):
        print(f"  PARI derivnum lambda_{n} = {pari_vals[n][:28]}  "
              f"|route2 - pari| = {pari_agree[n]['absdiff']}")

    # ---- checkpoint ------------------------------------------------------
    ck = {}
    corrected = {1: BRIEF_KNOWN[1], 2: mpf(pari_vals[2])}
    for n in (1, 2):
        r1_full = r1_table[kmax][n]
        tail = tail_estimate(n, T)
        ck[n] = {
            "brief_constant": nstr(BRIEF_KNOWN[n], 25),
            "route2": nstr(lam2[n], 25),
            "route2_err_vs_brief": nstr(abs(lam2[n] - BRIEF_KNOWN[n]), 3),
            "route2_err_vs_corrected": nstr(abs(lam2[n] - corrected[n]), 3),
            "route2_pass": bool(abs(lam2[n] - corrected[n]) < mpf("5e-9")),
            "route1_fullK": nstr(r1_full, 25),
            "route1_err_vs_corrected": nstr(abs(r1_full - corrected[n]), 3),
            "route1_tail_estimate": nstr(tail, 3),
            "route1_drift_500_1000": nstr(abs(r1_table[1000][n] - r1_table[500][n]), 3),
            "route1_pass_within_drift": bool(abs(r1_full - corrected[n]) <= 2 * tail),
        }
        print(f"checkpoint n={n}: route2 err vs corrected const "
              f"{ck[n]['route2_err_vs_corrected']} "
              f"({'PASS' if ck[n]['route2_pass'] else 'FAIL'}); "
              f"route1 err {ck[n]['route1_err_vs_corrected']} vs tail est "
              f"{ck[n]['route1_tail_estimate']} "
              f"({'PASS within drift' if ck[n]['route1_pass_within_drift'] else 'FAIL'})")
    report["checkpoint"] = ck
    report["brief_lambda2_constant_discrepancy"] = \
        nstr(abs(BRIEF_KNOWN[2] - corrected[2]), 3)

    # ---- combined table --------------------------------------------------
    rows = []
    for n in range(1, NMAX + 1):
        r1 = r1_table[kmax][n]
        r2 = lam2[n]
        rows.append({
            "n": n,
            "route1_K250": nstr(r1_table[250][n], 12),
            "route1_K500": nstr(r1_table[500][n], 12),
            "route1_K1000": nstr(r1_table[1000][n], 12),
            "route1_fullK": nstr(r1, 15),
            "route2": nstr(r2, 15),
            "abs_disagreement": nstr(abs(r1 - r2), 3),
            "drift_500_1000": nstr(abs(r1_table[1000][n] - r1_table[500][n]), 3),
        })
    report["table"] = rows

    negatives = [n for n in range(1, NMAX + 1)
                 if lam2[n] < 0 or r1_table[kmax][n] < 0]
    report["negatives_either_route"] = negatives
    smallest = min(range(1, NMAX + 1), key=lambda n: lam2[n])
    report["smallest_lambda_route2"] = {"n": smallest,
                                        "value": nstr(lam2[smallest], 15)}
    worst = max(rows, key=lambda r: mpf(r["abs_disagreement"]))
    report["worst_route_disagreement"] = {"n": worst["n"],
                                          "value": worst["abs_disagreement"]}
    report["total_seconds"] = round(time.time() - t0, 2)

    with open(OUT_JSON, "w") as f:
        json.dump(report, f, indent=1)
    print(f"\nsmallest lambda (route 2): lambda_{smallest} = {nstr(lam2[smallest], 15)}")
    print(f"worst route disagreement: n={worst['n']}, {worst['abs_disagreement']}")
    print(f"negatives on either route: {negatives}")
    print(f"total {report['total_seconds']}s -> {OUT_JSON}")


if __name__ == "__main__":
    main()
