#!/usr/bin/env python
"""
Li-type coefficients lambda_n(E) for E = 389a1 -- PILOT slice (n = 1..5).

Definitions, theorem citation, pairing, decomposition and checkpoint are
pinned in liE-methods-note.md (written before these numbers). Summary:

  Lambda(E,s) = N^(s/2) (2pi)^(-s) Gamma(s) L(E,s),  N = 389,  w = +1
  xi_E(s)     = Lambda(E, s + 1/2),   xi_E(s) = xi_E(1 - s)
  lambda_n(E) = sum_rho [ 1 - (1 - 1/rho)^n ]   over zeros rho of xi_E,
                paired as in Bombieri-Lagarias (JNT 77 (1999), Thm 1 Cor.).

TWO ROUTES (plus an adjudication path):

  Route A (zero sum): PARI lfunzeros(E, 600) ordinates gamma >= 0 of the
      zeros 1 + i*gamma of L(E,.). gamma = 0 occurs twice (central double
      zero, analytic rank 2) and contributes 1 - (-1)^n per occurrence.
      gamma > 0 pairs contribute 2*Re[1 - (1 - 1/rho)^n], rho = 1/2 + i*gamma.
      Partial sums reported at heights 100 / 300 / 600; the tail beyond 600
      is estimated (never added) by integrating the exact paired summand
      against the smooth RvM density (1/pi) log(sqrt(389) t / (2pi)).

  Route B1 (derivatives at s = 1, Li/BL form): c_k = Taylor coefficients of
      log xi_E about s = 1 by Cauchy/DFT on |s-1| = 0.4 (radius < 1/2, the
      distance to the central double zero), 512 points, phase-unwrapped log;
      lambda_n = n * sum_{k=1}^n binom(n-1, n-k) c_k. L-values from PARI
      lfun (realprecision 60); the archimedean factor from mpmath.

  Route B2 (sigma form, adjudication of the brief's transmitted formula):
      F(sigma) = log xi_E(1/(1-sigma)); coefficients f_m by Cauchy/DFT on
      |sigma| = 0.5. The CORRECT transported identity is
      lambda_n = F^(n)(0)/(n-1)! = n * f_n  (methods note sec. 7).
      The brief's literal form evaluates to n * f_1 for every n; both are
      computed and reported -- numbers adjudicate, as with the zeta probe's
      defective brief constant for lambda_2.

  Archimedean split (methods note sec. 5(b)): A(s) = ((s+1/2)/2) ln N
      - (s+1/2) ln(2pi) + ln Gamma(s+1/2); a_1 = (ln N)/2 - ln(2pi) + psi(3/2),
      a_k = polygamma(k-1, 3/2)/k! (k>=2); A_n by the B1 binom formula;
      residual R_n = lambda_n(B1) - A_n.

CHECKPOINT: route A (full height, no tail added) vs route B1 must agree
within route A's truncation scale (tail estimate + 300->600 drift).
Any lambda_n < 0 or disagreement beyond scale is presumed a probe defect
until both routes independently agree beyond their error scales.
Drop/round rule: drift-dominated digits flagged, never silently rounded.

Scope: pilot, n <= 5, finite height. Corroboration only (methods note sec. 0).

POST-RUN NOTES (2026-11-01; full account in liE-pilot-results.md):
  * Route B values in the results file are the B2 / PARI-derivnum /
    B1-repaired values (mutual agreement ~1e-12 to ~1e-21), NOT raw B1.
  * DEFECT (B1 sample assembly): the B1 Cauchy path at R=0.4, M=512 with
    THIS module's sample assembly (mpmath factor x literal-argument PARI
    lfun) is contaminated at the 5.5e-6 .. 8.2e-5 level in lambda_n.
    The DFT machinery is exonerated: identical code on GP-assembled
    samples (GP XiE function) reproduces PARI derivnum to ~1e-21 for all
    n (see liE_adjudication.json). Contamination localizes to a few
    contour points nearest the central double zero (j=184, 228, 284, 328;
    cross-assembly phase disagreements ~5e-4 in log xi_E there). An
    R=0.3 replica of B1 is clean (c_1 err 9e-17). Mechanism below the
    assembly level not isolated in this slice.
  * DEFECT (diff cross-check): mpmath.diff on logxi_E returned the
    archimedean-only coefficients a_k -- its finest steps fall below
    lfun_E's argument formatting (40 digits at the time), freezing the
    L-factor. Superseded by the derivnum adjudication; lfun_E now
    formats arguments at 110 digits.
  * The brief's literal sigma-form (sigma^(n-1) prefactor) is defective
    as transmitted (methods note sec. 7): it evaluates to n*f_1 for all
    n. The corrected form (B2) is what was used.
"""

import json
import os
import re
import time
from math import factorial

from cypari2 import Pari
from mpmath import (mp, mpf, mpc, pi, gamma, log, exp, binomial, nstr,
                    polygamma, quad, arg, diff, cos)

HERE = os.path.dirname(os.path.abspath(__file__))
ZERO_CACHE = os.path.join(HERE, "liE_zeros_cache.json")
OUT_JSON = os.path.join(HERE, "liE_probe_output.json")

NMAX = 5
ZERO_T = 600
CUT_HEIGHTS = (100, 300, 600)
COND = 389


# --------------------------------------------------------------------------
# PARI plumbing
# --------------------------------------------------------------------------
pari = Pari()
E = None  # set in main (string form used inside GP expressions)


def _mpf_pari(tok):
    """mpf() for PARI-printed tokens (PARI emits e.g. '0.E-77', which
    mpmath's parser rejects; normalize the bare '.' before an exponent)."""
    tok = tok.strip().replace(".E", ".0E").replace(".e", ".0e")
    if tok.endswith("."):
        tok += "0"
    return mpf(tok)


def pari_complex(s):
    """Evaluate a PARI expression returning a complex number -> mpc via str."""
    val = pari(s)
    txt = str(val)
    m = re.match(r"^\s*(.+?)\s+([+-])\s+(.+?)\*I\s*$", txt)
    if m:
        re_part = _mpf_pari(m.group(1))
        im_part = _mpf_pari(m.group(3)) * (1 if m.group(2) == "+" else -1)
        return mpc(re_part, im_part)
    return mpc(_mpf_pari(txt), 0)


def lfun_E(s):
    """L(E, s) at an mpc point s, via PARI (caller sets realprecision).
    Arguments formatted at 110 digits (post-run fix: at 40 digits,
    mpmath.diff's finest steps fell below the formatting floor and the
    L-factor appeared locally constant -- see docstring, defect D3)."""
    re_s = nstr(mp.re(s), 110)
    im_s = nstr(mp.im(s), 110)
    return pari_complex(f"lfun({E}, ({re_s}) + ({im_s})*I)")


def xi_E(z):
    """xi_E(z) = Lambda(E, z + 1/2); archimedean factor in mpmath, L in PARI."""
    s = z + mpf(1) / 2
    fac = (mpf(COND) ** (s / 2)) * (2 * pi) ** (-s) * gamma(s)
    return fac * lfun_E(s)


def logxi_E(z):
    return log(xi_E(z))


# --------------------------------------------------------------------------
# Verification artifacts (methods note sec. 0(i), sec. 2)
# --------------------------------------------------------------------------
def verify_artifacts():
    pari.set_real_precision(60)
    out = {}
    out["root_number"] = int(pari(f"ellrootno({E})"))
    ar = pari(f"ellanalyticrank({E})")
    out["analytic_rank"] = int(pari(f"({ar})[1]"))
    out["L_deriv_at_1"] = str(pari(f"({ar})[2]"))
    mp.dps = 80
    lam_half = xi_E(mpf(0))          # xi_E(0) = Lambda(E, 1/2)
    lam_3half = xi_E(mpf(1))         # xi_E(1) = Lambda(E, 3/2)
    out["Lambda_E_half"] = nstr(lam_half, 30)
    out["Lambda_E_3half"] = nstr(lam_3half, 30)
    out["xi_E_1_over_xi_E_0"] = nstr(lam_3half / lam_half, 30)  # w=+1 -> ~1
    return out


# --------------------------------------------------------------------------
# Zeros (route A input only)
# --------------------------------------------------------------------------
def get_zeros():
    if os.path.exists(ZERO_CACHE):
        with open(ZERO_CACHE) as f:
            data = json.load(f)
        if data["T"] == ZERO_T:
            return [mpf(s) for s in data["gammas"]], 0.0
    pari.set_real_precision(50)
    t0 = time.time()
    z = pari(f"lfunzeros({E}, {ZERO_T})")
    dt = time.time() - t0
    strs = [str(z[i]) for i in range(len(z))]
    with open(ZERO_CACHE, "w") as f:
        json.dump({"T": ZERO_T, "gammas": strs}, f)
    return [mpf(s) for s in strs], dt


# --------------------------------------------------------------------------
# Route A -- zero sum with cutoffs
# --------------------------------------------------------------------------
def routeA(gammas):
    """Return (partials {height: [lam_1..lam_5]}, offcenter_full, central_count)."""
    counts = {H: sum(1 for g in gammas if g <= H) for H in CUT_HEIGHTS}
    partials = {}
    running = [mpf(0)] * (NMAX + 1)
    offcenter = [mpf(0)] * (NMAX + 1)
    central = 0
    half = mpf(1) / 2
    for gi, g in enumerate(gammas, start=1):
        if g < mpf("1e-30"):
            central += 1
            for n in range(1, NMAX + 1):
                running[n] += 1 - (-1) ** n
        else:
            rho = mpc(half, g)
            w = 1 - 1 / rho
            wpow = mpc(1)
            for n in range(1, NMAX + 1):
                wpow *= w
                term = 2 * (1 - wpow).real
                running[n] += term
                offcenter[n] += term
        for H in CUT_HEIGHTS:
            if gi == counts[H]:
                partials[H] = running[:]
    partials[ZERO_T] = running[:]
    return partials, offcenter, central


def tail_estimate(n, T):
    """Integral of exact paired summand against smooth RvM density (sec. 6)."""
    def integrand(t):
        rho = mpc(mpf(1) / 2, t)
        theta = arg(1 - 1 / rho)
        dens = log(mpf(COND) ** mpf("0.5") * t / (2 * pi)) / pi
        return dens * 2 * (1 - cos(n * theta))
    return quad(integrand, [T, mp.inf])


# --------------------------------------------------------------------------
# Route B machinery -- Cauchy/DFT coefficient extraction with unwrapped log
# --------------------------------------------------------------------------
def cauchy_coeffs(func, center, R, M, kmax):
    """Taylor coefficients of log(func) about `center` on |z-center| = R.
    Returns (coeffs, winding) -- winding = net 2pi*i turns of the unwrapped
    log around the circle (must be ~0 for a zero-free disk)."""
    logs = []
    prev_val = None
    acc = mpf(0)
    for j in range(M):
        theta = 2 * pi * j / M
        z = center + R * exp(mpc(0, theta))
        val = func(z)
        if prev_val is None:
            lv = log(val)
        else:
            lv = acc + log(val / prev_val)
        logs.append(lv)
        acc = lv
        prev_val = val
    # closure: one more step back to the start point
    z0 = center + R
    winding = (acc + log(func(z0) / prev_val) - logs[0]) / (2 * pi)
    coeffs = []
    for k in range(kmax + 1):
        tot = mpc(0)
        for j in range(M):
            theta = 2 * pi * j / M
            tot += logs[j] * exp(mpc(0, -k * theta))
        coeffs.append(tot / M / R ** k)
    return coeffs, winding


def lam_from_coeffs(coeffs, nmax):
    lam = [None] * (nmax + 1)
    for n in range(1, nmax + 1):
        s_ = mpf(0)
        for k in range(1, n + 1):
            s_ += binomial(n - 1, n - k) * coeffs[k]
        lam[n] = n * s_
    return lam


# --------------------------------------------------------------------------
def main():
    global E
    t0 = time.time()
    report = {}
    E = pari("ellinit([0,1,1,-2,0])")

    # ---- verification artifacts ------------------------------------------
    va = verify_artifacts()
    report["verification"] = va
    print(f"root number w = {va['root_number']}  (expected +1)")
    print(f"analytic rank   = {va['analytic_rank']}  (expected 2)")
    print(f"Lambda(E,1/2)   = {va['Lambda_E_half']}")
    print(f"Lambda(E,3/2)   = {va['Lambda_E_3half']}")
    print(f"xi_E(1)/xi_E(0) = {va['xi_E_1_over_xi_E_0']}  (functional-eq check)")

    # ---- zeros ------------------------------------------------------------
    gammas, zt = get_zeros()
    report["zeros"] = {"count": len(gammas), "T": ZERO_T,
                       "top_gamma": nstr(gammas[-1], 12),
                       "compute_seconds": round(zt, 1),
                       "counts_by_height": {
                           str(H): sum(1 for g in gammas if g <= H)
                           for H in CUT_HEIGHTS}}
    print(f"zeros: {len(gammas)} ordinates to T={ZERO_T} "
          f"(top gamma {nstr(gammas[-1], 10)}), {zt:.1f}s")

    # ---- route A -----------------------------------------------------------
    mp.dps = 80
    t1 = time.time()
    partials, offcenter, central = routeA(gammas)
    report["routeA_seconds"] = round(time.time() - t1, 2)
    report["central_zero_count"] = central
    print(f"route A done; central zeros counted: {central}")

    mp.dps = 50
    tails = {n: tail_estimate(n, mpf(ZERO_T)) for n in range(1, NMAX + 1)}
    report["tail_estimates"] = {str(n): nstr(tails[n], 6)
                                for n in range(1, NMAX + 1)}

    # ---- route B1 ----------------------------------------------------------
    pari.set_real_precision(60)
    mp.dps = 100
    t2 = time.time()
    coeffsB1, windB1 = cauchy_coeffs(xi_E, mpf(1), mpf("0.4"), 512, NMAX + 15)
    lamB1 = lam_from_coeffs(coeffsB1, NMAX)
    report["routeB1_seconds"] = round(time.time() - t2, 2)
    report["routeB1_winding"] = nstr(windB1, 3)
    report["routeB1_max_imag_c"] = nstr(
        max(abs(mp.im(coeffsB1[k])) for k in range(1, NMAX + 1)), 3)
    print(f"route B1 done in {report['routeB1_seconds']}s; "
          f"winding = {nstr(windB1, 3)}")

    # route B1 internal cross-check: c_1..c_3 by mpmath.diff (callable log xi)
    mp.dps = 60
    diffs = {}
    for k in (1, 2, 3):
        d = diff(logxi_E, mpf(1), k) / factorial(k)
        diffs[k] = {"cauchy": nstr(coeffsB1[k], 25), "diff": nstr(d, 25),
                    "absdiff": nstr(abs(coeffsB1[k] - d), 3)}
    report["routeB1_c_diffcheck"] = diffs
    mp.dps = 100

    # ---- route B2 (sigma form; adjudication) -------------------------------
    pari.set_real_precision(60)
    t3 = time.time()

    def F_of_sigma(sig):
        return xi_E(1 / (1 - sig))

    coeffsF, windF = cauchy_coeffs(F_of_sigma, mpf(0), mpf("0.5"), 256, NMAX + 3)
    lamB2 = [None] + [n * mp.re(coeffsF[n]) for n in range(1, NMAX + 1)]
    lam_literal = [None] + [n * mp.re(coeffsF[1]) for n in range(1, NMAX + 1)]
    report["routeB2_seconds"] = round(time.time() - t3, 2)
    report["routeB2_winding"] = nstr(windF, 3)
    print(f"route B2 done in {report['routeB2_seconds']}s; "
          f"winding = {nstr(windF, 3)}")

    # ---- archimedean split ---------------------------------------------------
    a = [None] * (NMAX + 16)
    a[1] = log(mpf(COND)) / 2 - log(2 * pi) + polygamma(0, mpf(3) / 2)
    for k in range(2, NMAX + 16):
        a[k] = polygamma(k - 1, mpf(3) / 2) / factorial(k)
    lam_arch = lam_from_coeffs([mpf(0)] + [mp.re(x) for x in a[1:]], NMAX)

    # ---- table + checkpoint --------------------------------------------------
    rows = []
    for n in range(1, NMAX + 1):
        rA = partials[ZERO_T][n]
        rB = mp.re(lamB1[n])
        drift = abs(partials[ZERO_T][n] - partials[300][n])
        scale = tails[n] + drift
        rows.append({
            "n": n,
            "routeA_H100": nstr(partials[100][n], 15),
            "routeA_H300": nstr(partials[300][n], 15),
            "routeA_H600": nstr(rA, 15),
            "routeB1": nstr(rB, 15),
            "routeB2_corrected_sigma": nstr(lamB2[n], 15),
            "literal_brief_form_n_times_f1": nstr(lam_literal[n], 15),
            "gap_A_vs_B1": nstr(abs(rA - rB), 3),
            "tail_estimate": nstr(tails[n], 3),
            "drift_300_600": nstr(drift, 3),
            "truncation_scale": nstr(scale, 3),
            "checkpoint_pass_within_scale": bool(abs(rA - rB) <= scale),
            "B2_vs_B1": nstr(abs(lamB2[n] - rB), 3),
            "decomp_central_a": (4 if n % 2 == 1 else 0),
            "decomp_offcenter_c_partial": nstr(offcenter[n], 15),
            "decomp_a_plus_c_plus_tail": nstr(
                (4 if n % 2 == 1 else 0) + offcenter[n] + tails[n], 15),
            "archimedean_A_n": nstr(mp.re(lam_arch[n]), 15),
            "residual_R_n_B1_minus_A": nstr(rB - mp.re(lam_arch[n]), 15),
        })
        print(f"n={n}: A(600)={nstr(rA, 12)}  B1={nstr(rB, 12)}  "
              f"gap={nstr(abs(rA - rB), 3)}  scale={nstr(scale, 3)}  "
              f"{'PASS' if rows[-1]['checkpoint_pass_within_scale'] else 'FAIL'}")
    report["table"] = rows

    negatives = [n for n in range(1, NMAX + 1)
                 if mp.re(lamB1[n]) < 0 or partials[ZERO_T][n] < 0]
    report["negatives_either_route"] = negatives
    report["total_seconds"] = round(time.time() - t0, 2)

    with open(OUT_JSON, "w") as f:
        json.dump(report, f, indent=1)
    print(f"\nnegatives on either route: {negatives}")
    print(f"total {report['total_seconds']}s -> {OUT_JSON}")


if __name__ == "__main__":
    main()
