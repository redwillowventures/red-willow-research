#!/usr/bin/env python
"""
Riemann Panel — Test R1 extension to 10^9 (2026-10-31).

Instrument (reproducing Test R1, 2026-10-30, exactly):
  Schoenfeld (1976): RH implies |pi(x) - li(x)| < (1/(8*pi)) * sqrt(x) * ln(x)
  for x >= 2657.  Ratio r(x) = |pi(x) - li(x)| / envelope(x); RH requires r < 1.
  pi(x) exact (segmented sieve).  li(x) = Ei(ln x) at 30-digit precision (mpmath).

Protocol:
  Phase A validates the instrument against the recorded R1 values; if any
  recorded grid value disagrees beyond rounding in the third decimal, the run
  STOPS and reports a panel defect (Phase B does not proceed).
  Phase B extends to 10^9 and must reproduce pi(10^9) = 50847534 exactly.
  Any r >= 1 is presumed a computational defect until independently rechecked.
"""
import json
import math
import sys
import time

from mpmath import mp, mpf, ei, log as mlog, sqrt as msqrt, pi as mpi

mp.dps = 30

# ---------------------------------------------------------------- sieve ----
def base_primes(limit):
    sieve = bytearray(b"\x01") * (limit + 1)
    sieve[0:2] = b"\x00\x00"
    for i in range(2, int(limit ** 0.5) + 1):
        if sieve[i]:
            sieve[i * i::i] = b"\x00" * ((limit - i * i) // i + 1)
    return [i for i in range(2, limit + 1) if sieve[i]]


def segmented_pi(grid, N, span_odds=25_000_000):
    """Exact pi(g) for each g in grid (all <= N), via odd-only segmented sieve.

    Each segment covers odd values seg_lo .. seg_hi inclusive (arr[i] is the
    primality flag for seg_lo + 2i). `count` tracks odd primes below seg_lo;
    pi(g) adds 1 for the prime 2 (all grid points are >= 3). An even grid
    point equal to seg_hi + 1 is resolved inside the same segment (all of the
    segment's odds are <= g), which is what lets pi(10^9) be read exactly.
    """
    primes = base_primes(int(N ** 0.5) + 1)
    odd_primes = [p for p in primes if p > 2]
    want = sorted(set(grid))
    out = {}
    wi = 0
    count = 0  # odd primes strictly below seg_lo
    max_odd = N if N % 2 == 1 else N - 1
    seg_lo = 1
    t0 = time.time()
    while seg_lo <= max_odd:
        seg_hi = min(seg_lo + 2 * (span_odds - 1), max_odd)
        size = (seg_hi - seg_lo) // 2 + 1
        arr = bytearray(b"\x01") * size
        if seg_lo == 1:
            arr[0] = 0  # the number 1 is not prime
        for p in odd_primes:
            pp = p * p
            m = -(-seg_lo // p) * p  # smallest multiple of p >= seg_lo
            if m < pp:
                m = pp
            if m % 2 == 0:
                m += p
            if m > seg_hi:
                continue
            i0 = (m - seg_lo) // 2
            arr[i0::p] = b"\x00" * ((size - 1 - i0) // p + 1)
        while wi < len(want) and want[wi] <= seg_hi + 1:
            g = want[wi]
            j = min((g - seg_lo) // 2 + 1, size)  # odd slots with value <= g
            out[g] = count + sum(arr[:j]) + 1  # +1 for the prime 2
            wi += 1
        count += sum(arr)
        print(f"  sieve: odds to {seg_hi}, odd-prime cumulative={count}, "
              f"{time.time() - t0:.1f}s", file=sys.stderr)
        seg_lo = seg_hi + 2
    assert wi == len(want), f"grid points missed: {want[wi:]}"
    return out


# ------------------------------------------------------------------ li -----
def li(x):
    """li(x) = Ei(ln x), 30-digit precision, standard real branch."""
    return ei(mlog(mpf(x)))


def envelope(x):
    return msqrt(mpf(x)) * mlog(mpf(x)) / (8 * mpi)


def ratio(x, pi_x, li_x):
    err = abs(mpf(pi_x) - li_x)
    env = envelope(x)
    return err, env, err / env


# ----------------------------------------------------------------- main ----
RECORDED = {  # Test R1 recorded r values (run-log, 2026-10-30), 3 decimals
    10 ** 4: 0.468, 5 * 10 ** 4: 0.348, 10 ** 5: 0.261, 5 * 10 ** 5: 0.185,
    10 ** 6: 0.236, 2 * 10 ** 6: 0.149, 5 * 10 ** 6: 0.091, 10 ** 7: 0.167,
    10 ** 8: 0.103,
}
KNOWN_PI = {10 ** 6: 78498, 10 ** 7: 664579, 10 ** 8: 5761455,
            10 ** 9: 50847534}

VALIDATION_GRID = [10 ** 4, 5 * 10 ** 4, 10 ** 5, 5 * 10 ** 5, 10 ** 6,
                   2 * 10 ** 6, 5 * 10 ** 6, 10 ** 7,
                   2 * 10 ** 7, 3 * 10 ** 7, 5 * 10 ** 7, 10 ** 8]

EXTENSION_GRID = sorted(set(
    [10 ** 4, 5 * 10 ** 4, 10 ** 5, 5 * 10 ** 5, 10 ** 6, 2 * 10 ** 6,
     5 * 10 ** 6, 10 ** 7, 2 * 10 ** 7, 3 * 10 ** 7, 5 * 10 ** 7, 10 ** 8,
     3 * 10 ** 8, 10 ** 9, 990_000_000, 995_000_000, 999_000_000]
    + [k * 20_000_000 for k in range(6, 50)]  # every 2e7: 1.2e8 .. 9.8e8
))


def run_phase(name, grid, N):
    print(f"[{name}] segmented sieve to {N} over {len(grid)} grid points...")
    pis = segmented_pi(grid, N)
    rows = []
    for g in grid:
        li_g = li(g)
        err, env, r = ratio(g, pis[g], li_g)
        rows.append({"x": g, "pi": pis[g], "li": float(li_g),
                     "err": float(err), "envelope": float(env),
                     "r": float(r)})
        print(f"  x={g:>12}  pi={pis[g]:>10}  li={float(li_g):>18.6f}  "
              f"err={float(err):>12.4f}  env={float(env):>12.2f}  "
              f"r={float(r):.6f}")
    return rows


def main():
    # li pipeline self-check: li(10^4) tabulated = 1246.1372158992...
    li_check = float(li(10 ** 4))
    print(f"li(10^4) = {li_check:.10f}  (tabulated 1246.1372158992)")
    assert abs(li_check - 1246.1372158992) < 1e-6, "li pipeline defect"

    rows_a = run_phase("A: validation", VALIDATION_GRID, 10 ** 8)
    print("\n[Phase A] comparison vs recorded R1 values:")
    defect = False
    for row in rows_a:
        g = row["x"]
        if g in KNOWN_PI:
            ok = row["pi"] == KNOWN_PI[g]
            print(f"  pi({g}) = {row['pi']}  known {KNOWN_PI[g]}  "
                  f"{'OK' if ok else 'MISMATCH'}")
            defect |= not ok
        if g in RECORDED:
            d = abs(row["r"] - RECORDED[g])
            ok = d <= 0.0005
            print(f"  r({g}) computed {row['r']:.6f}  recorded "
                  f"{RECORDED[g]:.3f}  diff {d:.6f}  "
                  f"{'OK' if ok else 'DEFECT'}")
            defect |= not ok
    if defect:
        print("\nPANEL DEFECT: validation failed — extension NOT run.")
        with open("/tmp/r1_phaseA.json", "w") as f:
            json.dump(rows_a, f, indent=1)
        return 1
    print("\n[Phase A] VALIDATION PASSED — proceeding to 10^9.")

    rows_b = run_phase("B: extension", EXTENSION_GRID, 10 ** 9)
    pi9 = [r for r in rows_b if r["x"] == 10 ** 9][0]["pi"]
    print(f"\npi(10^9) = {pi9}  (known 50847534)  "
          f"{'OK' if pi9 == 50847534 else 'DEFECT'}")
    new = [r for r in rows_b if r["x"] > 10 ** 8]
    worst = max(new, key=lambda r: r["r"])
    print(f"worst r above 1e8: r={worst['r']:.6f} at x={worst['x']}")
    with open("/tmp/r1_all.json", "w") as f:
        json.dump({"phaseA": rows_a, "phaseB": rows_b}, f, indent=1)
    return 0 if pi9 == 50847534 else 2


if __name__ == "__main__":
    sys.exit(main())
