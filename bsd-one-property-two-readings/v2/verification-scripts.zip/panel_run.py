#!/usr/bin/env python3
"""
BSD failure-hunt panel runner -- Slice 1
========================================
Two columns per curve, per the pre-registered panel design:

Column 1 (identity):
    Q = [ Omega * R * Sha_tab * prod(c_p) ] / [ L*(E,1) * |tors|^2 ]
  and, inversely, Sha_solved = L*(E,1) * |tors|^2 / (Omega * R * prod(c_p)),
  which must come out equal to the tabulated analytic Sha (a perfect square).
  Factors:
    * L*(E,1) = L^(r)(E,1)/r! by TWO routes:
        Route A: PARI. ellanalyticrank(E) supplies the analytic rank r and
                 the RAW r-th derivative; the primary value used is
                 lfun(E, 1, r) / r!, and the two are printed side by side
                 (they agreed to all 50 digits on 5 of the first 6 curves,
                 and to the last-digit rounding on the sixth).
                 (Trap avoided: ellanalyticrank returns the RAW derivative,
                 NOT divided by r!. Note: called through cypari2 BEFORE the
                 GP-level realprecision is set, ellanalyticrank returned only
                 ~19 digits in an early probe; with default(realprecision,50)
                 set first, as here, it returns the full 50 digits.)
        Route B: the LMFDB-tabulated special value (independent provenance),
                 embedded per curve below from the curve's LMFDB page.
    * Regulator R: computed TWO ways from the LMFDB-published generators:
        (i)  our own height-pairing matrix: pairing(P,Q) =
             ( h(P+Q) - h(P) - h(Q) ) / 2 with canonical heights from
             ellheight, determinant via PARI matdet;
        (ii) PARI ellheightmatrix determinant.
      Rank 0: R = 1 by convention (empty matrix), both routes.
    * Omega: real period = (2 if Delta > 0 else 1) * E.omega[1], where
             E.omega[1] is the ellinit-stored first period (this is LMFDB's
             own GP formula, printed on each curve page).
             (Trap found in Slice 1 and fixed: a fresh ellperiods(E)[1] call
             returns a COMPLEX lattice-basis period when Delta < 0 -- its
             real-period entry is the second component. Using it made Omega,
             Sha_solved and Q complex for 11.a2 in the first run. E.omega[1]
             is the true real w1 for both signs of Delta; verified against
             LMFDB for 11.a2, 571.b1 (Delta < 0) and 37.a1 (Delta > 0).)
    * prod(c_p): product over bad primes of the 4th component of
             elllocalred(E, p). (Trap avoided: elltamagawa folds in the
             real-component factor -- for 389a1 it returns 2 where c_389 = 1 --
             so elltamagawa is never used.)
    * |tors|: elltors(E)[1] (first component).

Column 2 (synchronization):
    PARI lfunzeros(E, H) lists zeros ON the critical line s = 1 + i*gamma,
    0 <= gamma <= H (arithmetic normalization; the central zeros of
    multiplicity r appear as r entries gamma = 0). lfunzeros searches along
    the line: by construction it can only report zeros it finds on the line,
    so this column records WHERE the on-line zeros are and how many were
    found; it does not by itself exclude off-line zeros.
    Consistency check actually run: an independent scan of the Hardy
    Z-function (lfunhardy) on a grid of step 0.05 over (0, H], counting sign
    changes; each simple on-line zero forces a sign change, so the scan
    count must be >= the number of positive gammas returned by lfunzeros
    (a strict deficit would flag a panel problem; an excess can come from
    grid pairs closer than the step -- reported as-is, not resolved by hand).

Pre-registered protocol (binding): any Q != 1 (to the working precision) or
solved-Sha mismatch is reported as an UNRESOLVED DEFECT IN THIS PANEL with
diagnostics -- never as a statement about the curve.

Labels: LMFDB labels throughout; Cremona label and conductor recorded per
curve to disambiguate collisions (e.g. Cremona 571a1 = LMFDB 571.b1).

Precision: GP default realprecision 50 digits; cypari2 real precision 50.
"""

import json
import sys
from math import factorial

from cypari2 import Pari

pari = Pari()
pari("default(realprecision, 50)")
pari.set_real_precision(50)

# ---------------------------------------------------------------------------
# Curve data. Every LMFDB-tabulated value below was read off the curve's own
# LMFDB page on 2026-11-01; the page URL is in "source". Values are stored as
# strings exactly as printed on the page (page prints 29 significant digits).
# gens: LMFDB "Mordell-Weil generators", affine (x, y) on the minimal model.
# ---------------------------------------------------------------------------
CURVES = {
    "11.a2": dict(
        cremona="11a1", conductor=11, ainv=[0, -1, 1, -10, -20],
        rank=0, tors=5, tors_structure="Z/5",
        sha_tab=1, tam_tab=5,
        Lstar_tab="0.25384186085591068433775892335",
        reg_tab="1",
        omega_tab="1.2692093042795534216887946168",
        gens=[],
        source="https://www.lmfdb.org/EllipticCurve/Q/11a1/",
    ),
    "37.a1": dict(
        cremona="37a1", conductor=37, ainv=[0, 0, 1, -1, 0],
        rank=1, tors=1, tors_structure="trivial",
        sha_tab=1, tam_tab=1,
        Lstar_tab="0.30599977383405230182048368332",
        reg_tab="0.051111408239968840235886099757",
        omega_tab="5.9869172924639192596640199589",
        gens=[[0, 0]],
        source="https://www.lmfdb.org/EllipticCurve/Q/37a1/",
    ),
    "389.a1": dict(
        cremona="389a1", conductor=389, ainv=[0, 1, 1, -2, 0],
        rank=2, tors=1, tors_structure="trivial",
        sha_tab=1, tam_tab=1,
        Lstar_tab="0.75931650028842677023019260790",
        reg_tab="0.15246017794314375162432475705",
        omega_tab="4.9804251217101101506427155839",
        gens=[[0, 0], [1, 0]],
        source="https://www.lmfdb.org/EllipticCurve/Q/389a1/",
    ),
    "571.b1": dict(
        cremona="571a1", conductor=571, ainv=[0, -1, 1, -929, -10595],
        rank=0, tors=1, tors_structure="trivial",
        sha_tab=4, tam_tab=1,
        Lstar_tab="1.7293650250874438809412704044",
        reg_tab="1",
        omega_tab="0.43234125627186097023531760110",
        gens=[],
        source="https://www.lmfdb.org/EllipticCurve/Q/571a1/",
    ),
    "571.a1": dict(
        cremona="571b1", conductor=571, ainv=[0, 1, 1, -4, 2],
        rank=2, tors=1, tors_structure="trivial",
        sha_tab=1, tam_tab=1,
        Lstar_tab="0.90316051697166446993114862526",
        reg_tab="0.17725314026200493174409109973",
        omega_tab="5.0953146197391307751824772732",
        gens=[[1, 0], [0, 1]],
        source="https://www.lmfdb.org/EllipticCurve/Q/571b1/",
    ),
    "5077.a1": dict(
        cremona="5077a1", conductor=5077, ainv=[0, 0, 1, -7, 6],
        rank=3, tors=1, tors_structure="trivial",
        sha_tab=1, tam_tab=1,
        Lstar_tab="1.7318499001193006897919750851",
        reg_tab="0.41714355875838396981711954462",
        omega_tab="4.1516879830869330498841756835",
        gens=[[1, 0], [2, 0], [0, 2]],
        source="https://www.lmfdb.org/EllipticCurve/Q/5077a1/",
    ),
    # -----------------------------------------------------------------------
    # Slice 2 additions (2026-11-01). Every tabulated value below was read
    # this session from the LMFDB API: ec_curvedata (ainvs, rank, torsion,
    # torsion_structure, sha as integer, regulator) and ec_mwbsd (gens as
    # projective triples [x,y,z] -- converted below to affine (x/z, y/z);
    # real_period -> omega_tab; special_value -> Lstar_tab, a RealLiteral at
    # prec 127 bits, ~38 significant digits, MORE than the 29 digits the web
    # pages print; sha_an cross-checked against curvedata's integer sha;
    # tamagawa_product -> tam_tab). The two API query URLs used per curve
    # are recorded in "source" (ec_mwbsd) and "source_curvedata".
    # API field URLs have the form:
    #   https://www.lmfdb.org/api/ec_mwbsd/?lmfdb_label=s<LABEL>&_format=json
    #     &_fields=lmfdb_label,gens,heights,real_period,sha_an,special_value,
    #              tamagawa_product,rank_bounds
    #   https://www.lmfdb.org/api/ec_curvedata/?lmfdb_label=s<LABEL>
    #     &_format=json&_fields=lmfdb_label,Clabel,conductor,ainvs,rank,
    #              analytic_rank,torsion,torsion_structure,sha,regulator
    # (full URLs in the manifest). Note 19047851.b1: one LMFDB generator is
    # the projective triple [87,415,2], i.e. the RATIONAL point (87/4,415/8)
    # -- stored below with string coordinates "87/4","415/8"; PARI parses
    # the formatted "[87/4,415/8]" as a rational point, and the point was
    # verified on the curve by hand (both sides 247755/64).
    # -----------------------------------------------------------------------
    "12480.bf1": dict(
        cremona="12480k1", conductor=12480, ainv=[0, -1, 0, 38875, 1928445],
        rank=0, tors=1, tors_structure="trivial",
        sha_tab=9, tam_tab=1,
        Lstar_tab="2.4985032122601646076217085617544079577",
        reg_tab="1",
        omega_tab="0.27761146802890717862463428464",
        gens=[],
        source="https://www.lmfdb.org/api/ec_mwbsd/?lmfdb_label=s12480.bf1&_format=json&_fields=lmfdb_label,gens,heights,real_period,sha_an,special_value,tamagawa_product,rank_bounds",
        source_curvedata="https://www.lmfdb.org/api/ec_curvedata/?lmfdb_label=s12480.bf1&_format=json&_fields=lmfdb_label,Clabel,conductor,ainvs,rank,analytic_rank,torsion,torsion_structure,sha,regulator",
    ),
    "133584.bt1": dict(
        cremona="133584cn1", conductor=133584, ainv=[0, -1, 0, -36824, -3515664],
        rank=0, tors=1, tors_structure="trivial",
        sha_tab=9, tam_tab=2,
        Lstar_tab="3.0423874420381932558710304826865306025",
        reg_tab="1",
        omega_tab="0.16902152455767740310394613793",
        gens=[],
        source="https://www.lmfdb.org/api/ec_mwbsd/?lmfdb_label=s133584.bt1&_format=json&_fields=lmfdb_label,gens,heights,real_period,sha_an,special_value,tamagawa_product,rank_bounds",
        source_curvedata="https://www.lmfdb.org/api/ec_curvedata/?lmfdb_label=s133584.bt1&_format=json&_fields=lmfdb_label,Clabel,conductor,ainvs,rank,analytic_rank,torsion,torsion_structure,sha,regulator",
    ),
    "234446.a1": dict(
        cremona="234446a1", conductor=234446, ainv=[1, -1, 0, -79, 289],
        rank=4, tors=1, tors_structure="trivial",
        sha_tab=1, tam_tab=2,
        Lstar_tab="8.9438473959008890464175916832904152377",
        reg_tab="1.5043448882752839740952712523",
        omega_tab="2.9726718472633355360017773008",
        gens=[[6, -1], [4, 3], [5, -2], [8, 7]],
        source="https://www.lmfdb.org/api/ec_mwbsd/?lmfdb_label=s234446.a1&_format=json&_fields=lmfdb_label,gens,heights,real_period,sha_an,special_value,tamagawa_product,rank_bounds",
        source_curvedata="https://www.lmfdb.org/api/ec_curvedata/?lmfdb_label=s234446.a1&_format=json&_fields=lmfdb_label,Clabel,conductor,ainvs,rank,analytic_rank,torsion,torsion_structure,sha,regulator",
    ),
    "234446.b1": dict(
        cremona="234446b1", conductor=234446, ainv=[1, 1, 0, -696, 6784],
        rank=3, tors=1, tors_structure="trivial",
        sha_tab=1, tam_tab=2,
        Lstar_tab="9.8489432634400275742255163015220200809",
        reg_tab="2.1590110199745520393081546141",
        omega_tab="2.2808923095622077208984462018",
        gens=[[16, 0], [15, -7], [19, 20]],
        source="https://www.lmfdb.org/api/ec_mwbsd/?lmfdb_label=s234446.b1&_format=json&_fields=lmfdb_label,gens,heights,real_period,sha_an,special_value,tamagawa_product,rank_bounds",
        source_curvedata="https://www.lmfdb.org/api/ec_curvedata/?lmfdb_label=s234446.b1&_format=json&_fields=lmfdb_label,Clabel,conductor,ainvs,rank,analytic_rank,torsion,torsion_structure,sha,regulator",
    ),
    "234446.c1": dict(
        cremona="234446c1", conductor=234446, ainv=[1, 1, 1, -949, -7845],
        rank=3, tors=1, tors_structure="trivial",
        sha_tab=1, tam_tab=18,
        Lstar_tab="19.244916664503767715999417351100863886",
        reg_tab="1.2116268247276632962599537877",
        omega_tab="0.88241859217436107436288189295",
        gens=[[-25, 44], [39, 108], [-21, 68]],
        source="https://www.lmfdb.org/api/ec_mwbsd/?lmfdb_label=s234446.c1&_format=json&_fields=lmfdb_label,gens,heights,real_period,sha_an,special_value,tamagawa_product,rank_bounds",
        source_curvedata="https://www.lmfdb.org/api/ec_curvedata/?lmfdb_label=s234446.c1&_format=json&_fields=lmfdb_label,Clabel,conductor,ainvs,rank,analytic_rank,torsion,torsion_structure,sha,regulator",
    ),
    "19047851.a1": dict(
        cremona="", conductor=19047851, ainv=[0, 0, 1, -79, 342],
        rank=5, tors=1, tors_structure="trivial",
        sha_tab=1, tam_tab=1,
        Lstar_tab="30.285687553864516827653775999631857179",
        reg_tab="14.790527570131128481500792169",
        omega_tab="2.0476407897055164206181597836",
        gens=[[3, 11], [7, 11], [10, 23], [-6, 24], [4, 9]],
        source="https://www.lmfdb.org/api/ec_mwbsd/?lmfdb_label=s19047851.a1&_format=json&_fields=lmfdb_label,gens,heights,real_period,sha_an,special_value,tamagawa_product,rank_bounds",
        source_curvedata="https://www.lmfdb.org/api/ec_curvedata/?lmfdb_label=s19047851.a1&_format=json&_fields=lmfdb_label,Clabel,conductor,ainvs,rank,analytic_rank,torsion,torsion_structure,sha,regulator",
    ),
    "19047851.b1": dict(
        cremona="", conductor=19047851, ainv=[1, 1, 1, -244, -1584],
        rank=2, tors=1, tors_structure="trivial",
        sha_tab=1, tam_tab=1,
        Lstar_tab="10.214403054075326795096625366593971955",
        reg_tab="16.924145001099766774652517289",
        omega_tab="0.60354027062587641847180450392",
        gens=[[26, 89], ["87/4", "415/8"]],
        source="https://www.lmfdb.org/api/ec_mwbsd/?lmfdb_label=s19047851.b1&_format=json&_fields=lmfdb_label,gens,heights,real_period,sha_an,special_value,tamagawa_product,rank_bounds",
        source_curvedata="https://www.lmfdb.org/api/ec_curvedata/?lmfdb_label=s19047851.b1&_format=json&_fields=lmfdb_label,Clabel,conductor,ainvs,rank,analytic_rank,torsion,torsion_structure,sha,regulator",
    ),
    "57.a1": dict(
        cremona="57a1", conductor=57, ainv=[0, -1, 1, -2, 2],
        rank=1, tors=1, tors_structure="trivial",
        sha_tab=1, tam_tab=2,
        Lstar_tab="0.41749163967630964038932049159583966692",
        reg_tab="0.037574592736823752824805111217",
        omega_tab="5.5555045213725043221174270349",
        gens=[[2, 1]],
        source="https://www.lmfdb.org/api/ec_mwbsd/?lmfdb_label=s57.a1&_format=json&_fields=lmfdb_label,gens,heights,real_period,sha_an,special_value,tamagawa_product,rank_bounds",
        source_curvedata="https://www.lmfdb.org/api/ec_curvedata/?lmfdb_label=s57.a1&_format=json&_fields=lmfdb_label,Clabel,conductor,ainvs,rank,analytic_rank,torsion,torsion_structure,sha,regulator",
    ),
    "44.a1": dict(
        cremona="44a2", conductor=44, ainv=[0, 1, 0, -77, -289],
        rank=0, tors=1, tors_structure="trivial",
        sha_tab=1, tam_tab=1,
        Lstar_tab="0.80464628757465185995669379232551592659",
        reg_tab="1",
        omega_tab="0.80464628757465185995669379233",
        gens=[],
        source="https://www.lmfdb.org/api/ec_mwbsd/?lmfdb_label=s44.a1&_format=json&_fields=lmfdb_label,gens,heights,real_period,sha_an,special_value,tamagawa_product,rank_bounds",
        source_curvedata="https://www.lmfdb.org/api/ec_curvedata/?lmfdb_label=s44.a1&_format=json&_fields=lmfdb_label,Clabel,conductor,ainvs,rank,analytic_rank,torsion,torsion_structure,sha,regulator",
    ),
    "12144.a1": dict(
        cremona="12144r2", conductor=12144, ainv=[0, -1, 0, -1380, -19044],
        rank=0, tors=2, tors_structure="Z/2",
        sha_tab=1, tam_tab=4,
        Lstar_tab="0.78390499057876896961622954500558928447",
        reg_tab="1",
        omega_tab="0.78390499057876896961622954500",
        gens=[],
        source="https://www.lmfdb.org/api/ec_mwbsd/?lmfdb_label=s12144.a1&_format=json&_fields=lmfdb_label,gens,heights,real_period,sha_an,special_value,tamagawa_product,rank_bounds",
        source_curvedata="https://www.lmfdb.org/api/ec_curvedata/?lmfdb_label=s12144.a1&_format=json&_fields=lmfdb_label,Clabel,conductor,ainvs,rank,analytic_rank,torsion,torsion_structure,sha,regulator",
    ),
    "697691.a1": dict(
        # Slot-(b) curve: rank 2 with analytic Sha 4. Curvedata fields were
        # read from the API search response rank=i2&sha=i4&_sort=conductor
        # (2026-11-01); mwbsd fields from the by-label query in "source".
        cremona="", conductor=697691, ainv=[0, -1, 1, -7117, 233485],
        rank=2, tors=1, tors_structure="trivial",
        sha_tab=4, tam_tab=1,
        Lstar_tab="9.6678206520244397615647997406093226324",
        reg_tab="1.1795622682498690697888234673",
        omega_tab="2.0490271925976199688042481597",
        gens=[[49, 0], [53, 48]],
        source="https://www.lmfdb.org/api/ec_mwbsd/?lmfdb_label=s697691.a1&_format=json&_fields=lmfdb_label,gens,heights,real_period,sha_an,special_value,tamagawa_product,rank_bounds",
        source_curvedata="https://www.lmfdb.org/api/ec_curvedata/?rank=i2&sha=i4&_format=json&_fields=lmfdb_label,Clabel,conductor,ainvs,rank,analytic_rank,torsion,torsion_structure,sha,regulator&_sort=conductor",
    ),
}

ZEROS_HEIGHT = 20  # Column-2 stated height H (gamma <= 20), all Slice-1 curves
HARDY_STEP = "0.05"


def gp(s):
    return pari(s)


def own_regulator(E, gens):
    """Regulator from our own height-pairing matrix (canonical heights via
    ellheight; pairing by polarization; determinant by PARI matdet)."""
    if not gens:
        return pari(1)
    n = len(gens)
    P = [gp(f"[{x},{y}]") for x, y in gens]
    h = [gp(f"ellheight(E, {p})") for p in
         [f"[{x},{y}]" for x, y in gens]]
    rows = []
    for i in range(n):
        row = []
        for j in range(n):
            if i == j:
                row.append(h[i])
            else:
                s = gp(f"elladd(E, [{gens[i][0]},{gens[i][1]}], "
                       f"[{gens[j][0]},{gens[j][1]}])")
                hs = gp(f"ellheight(E, {s})")
                row.append((hs - h[i] - h[j]) / 2)
        rows.append(row)
    M = pari.matrix(n, n, [rows[i][j] for i in range(n) for j in range(n)])
    return gp(f"matdet({M})")


def run_curve(label, d):
    gp(f"E = ellinit({d['ainv']})")
    out = {"label": label, "cremona": d["cremona"], "conductor": d["conductor"]}
    out["disc_sign"] = "+" if int(gp("E.disc")) > 0 else "-"

    # --- Column 1 factors -------------------------------------------------
    N = int(gp("ellglobalred(E)[1]"))
    out["conductor_check"] = N
    bad = [int(p) for p in gp(f"factor({N})[,1]")]  # primes dividing N
    cp = {}
    tam = 1
    for p in bad:
        c = int(gp(f"elllocalred(E, {p})[4]"))
        cp[p] = c
        tam *= c
    out["tamagawa_local"] = cp
    out["tam"] = tam
    out["tors"] = int(gp("elltors(E)[1]"))

    omega = gp("if(E.disc>0, 2, 1) * E.omega[1]")
    out["omega"] = str(omega)

    r_an, Lraw_ar = gp("ellanalyticrank(E)")
    r_an = int(r_an)
    out["analytic_rank"] = r_an
    out["Lraw_ellanalyticrank"] = str(Lraw_ar)
    Lraw = gp(f"lfun(E, 1, {r_an})") if r_an > 0 else gp("lfun(E, 1)")
    out["Lraw_lfun"] = str(Lraw)
    LstarA = Lraw / factorial(r_an)
    out["Lstar_routeA"] = str(LstarA)
    LstarB = pari(d["Lstar_tab"])
    out["Lstar_routeB_lmfdb"] = d["Lstar_tab"]

    reg_own = own_regulator(None, d["gens"])
    out["reg_own_pairing"] = str(reg_own)
    if d["gens"]:
        G = "[" + ",".join(f"[{x},{y}]" for x, y in d["gens"]) + "]"
        reg_pari = gp(f"matdet(ellheightmatrix(E, {G}))")
    else:
        reg_pari = pari(1)
    out["reg_ellheightmatrix"] = str(reg_pari)
    out["reg_tab_lmfdb"] = d["reg_tab"]

    tors2 = out["tors"] ** 2
    sha_solved = LstarA * tors2 / (omega * reg_own * tam)
    out["sha_solved_routeA"] = str(sha_solved)
    sha_solved_B = LstarB * tors2 / (omega * reg_own * tam)
    out["sha_solved_routeB"] = str(sha_solved_B)
    out["sha_tab"] = d["sha_tab"]
    Q_A = omega * reg_own * d["sha_tab"] * tam / (LstarA * tors2)
    Q_B = omega * reg_own * d["sha_tab"] * tam / (LstarB * tors2)
    out["Q_routeA"] = str(Q_A)
    out["Q_routeB"] = str(Q_B)

    # --- Column 2: zeros on the line --------------------------------------
    zeros = gp(f"lfunzeros(E, {ZEROS_HEIGHT})")
    gammas = [str(z) for z in zeros]
    out["zeros_height"] = ZEROS_HEIGHT
    out["zeros_count_total"] = len(gammas)
    out["zeros_at_center"] = sum(1 for z in zeros if abs(float(z)) < 1e-30)
    out["gammas"] = gammas
    # Hardy Z sign-change scan on (0, H]
    scan = gp(
        f"n=0; prev=lfunhardy(E, {HARDY_STEP}/2); "
        f"forstep(t=3*{HARDY_STEP}/2, {ZEROS_HEIGHT}, {HARDY_STEP}, "
        f"cur=lfunhardy(E, t); if(prev*cur<0, n++); prev=cur); n")
    out["hardy_sign_changes"] = int(scan)
    out["hardy_step"] = HARDY_STEP
    return out


def main():
    labels = sys.argv[1:] or list(CURVES)
    results = []
    for label in labels:
        print(f"=== {label} ===", flush=True)
        r = run_curve(label, CURVES[label])
        results.append(r)
        print(json.dumps(r, indent=1), flush=True)
    with open("panel_raw_output.json", "a") as f:
        for r in results:
            f.write(json.dumps(r) + "\n")


if __name__ == "__main__":
    main()
